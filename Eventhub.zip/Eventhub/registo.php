<?php
// registo.php — Registo de novos utilizadores
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Se já está logado, redireciona para o dashboard
if (isset($_SESSION['id_utilizador'])) {
    $role = $_SESSION['role'] ?? '';
    if ($role === 'organizador')     { header('Location: dashboard.php'); exit; }
    elseif ($role === 'staff')       { header('Location: staff-dashboard.php'); exit; }
    else                             { header('Location: guest.php'); exit; }
}

$erro    = '';
$sucesso = false;

// Mapeamento: nome do role → id na tabela role
// Conforme scripts_bd.sql: 1=administrador, 2=organizador, 3=staff, 4=convidado
$mapa_roles = [
    'organizador' => 2,
    'staff'       => 3,
    'convidado'   => 4,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role_str = 'organizador'; // Forçar sempre organizador no registo público

    if (!$nome || !$email || !$password || !$role_str) {
        $erro = 'Preencha todos os campos.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Email inválido.';
    } elseif (strlen($password) < 6) {
        $erro = 'A palavra-passe deve ter pelo menos 6 caracteres.';
    } else {
        try {
            $pdo = getDB();

            // Verifica se email já existe
            $check = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE email = ?");
            $check->execute([$email]);
            if ($check->fetch()) {
                $erro = 'Este email já está registado.';
            } else {
                // Busca o id_role a partir do nome
                $stmtRole = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = ?");
                $stmtRole->execute([$role_str]);
                $roleRow = $stmtRole->fetch();
                if (!$roleRow) {
                    $erro = 'Perfil inválido.';
                } else {
                    $id_role = $roleRow['id_role'];
                    $hash = hash('sha256', $password);

                    $stmt = $pdo->prepare("
                        INSERT INTO utilizador (nome, email, password, id_role, estado_conta, data_registo)
                        VALUES (?, ?, ?, ?, 'ativo', NOW())
                    ");
                    $stmt->execute([$nome, $email, $hash, $id_role]);
                    $sucesso = true;
                }
            }
        } catch (PDOException $e) {
            error_log('Registo falhou: ' . $e->getMessage());
            $erro = 'Erro interno ao criar conta. Tente novamente.';
        }
    }
}

// Valores a repor no formulário em caso de erro
$v_nome     = htmlspecialchars($_POST['nome']  ?? '');
$v_email    = htmlspecialchars($_POST['email'] ?? '');
$v_role     = $_POST['role'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta — Event Hub</title>
    <meta name="description" content="Crie a sua conta no Event Hub e comece a organizar o seu evento em minutos.">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%230d9488'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' fill='white' font-size='18' font-weight='700' font-family='sans-serif'%3EEH%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <script src="lang.js" defer></script>
    <style>
        .alert {
            display: flex; align-items: flex-start; gap: 10px;
            padding: 13px 16px; border-radius: 10px;
            font-size: 14px; line-height: 1.5; margin-bottom: 18px;
        }
        .alert i { font-size: 18px; flex-shrink: 0; margin-top: 1px; }
        .alert-error   { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
        .alert-success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
        .alert-success a { color: #166534; font-weight: 700; text-decoration: underline; }
        .input-wrapper select {
            width: 100%; padding: 12px 12px 12px 42px;
            border: 1px solid #e2e8f0; border-radius: 8px;
            font-size: 15px; background: white; appearance: none;
            font-family: 'Inter', sans-serif; color: #0f172a; outline: none;
        }
        .input-wrapper select:focus { border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124,58,237,.1); }
    </style>
</head>
<body class="auth-page">

    <!-- Floating language switcher -->
    <div class="lang-switcher lang-switcher-float" role="group">
        <button class="lang-btn" data-lang="pt" onclick="setLang('pt')">🇵🇹 PT</button>
        <button class="lang-btn" data-lang="en" onclick="setLang('en')">🇺🇸 EN</button>
    </div>

<div class="login-container">

    <div class="auth-logo" style="margin-bottom:24px">
        <i class="ph-fill ph-calendar-check" style="color:#7c3aed;font-size:32px"></i>
        <span style="font-weight:700;font-size:24px;margin-left:8px">Event Hub</span>
    </div>

    <div class="auth-card">
        <div class="auth-header" style="text-align:center;margin-bottom:24px">
            <h2 style="font-size:22px;margin-bottom:6px" data-i18n="reg.title">Criar conta</h2>
            <p style="color:#64748b;font-size:14px" data-i18n="reg.subtitle">Preencha os dados abaixo para começar</p>
        </div>

        <?php if ($erro): ?>
        <div class="alert alert-error">
            <i class="ph ph-warning-circle"></i>
            <span><?= htmlspecialchars($erro) ?></span>
        </div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
        <div class="alert alert-success">
            <i class="ph ph-check-circle"></i>
            <span>
                Conta criada com sucesso! 🎉<br>
                <a href="login.php">→ Clique aqui para iniciar sessão</a>
            </span>
        </div>
        <?php else: ?>

        <form method="POST" action="registo.php" class="auth-form">

            <div class="input-group" style="margin-bottom:16px">
                <label style="display:block;font-size:14px;margin-bottom:6px;font-weight:600">
                    Eu sou...
                </label>
                <div class="input-wrapper" style="position:relative;display:flex;align-items:center">
                    <i class="ph ph-identification-card"
                       style="position:absolute;left:12px;color:#64748b;font-size:20px;pointer-events:none"></i>
                    <select name="role" required>
                        <option value="organizador" selected>Organizador (Crio eventos)</option>
                    </select>
                </div>
            </div>

            <div class="input-group" style="margin-bottom:16px">
                <label style="display:block;font-size:14px;margin-bottom:6px;font-weight:600" data-i18n="reg.name">
                    Nome Completo
                </label>
                <div class="input-wrapper">
                    <i class="ph ph-user"></i>
                    <input type="text" name="nome" placeholder="O seu nome completo"
                           required value="<?= $v_nome ?>">
                </div>
            </div>

            <div class="input-group" style="margin-bottom:16px">
                <label style="display:block;font-size:14px;margin-bottom:6px;font-weight:600" data-i18n="reg.email">
                    Email
                </label>
                <div class="input-wrapper">
                    <i class="ph ph-envelope"></i>
                    <input type="email" name="email" placeholder="email@exemplo.com"
                           required value="<?= $v_email ?>">
                </div>
            </div>

            <div class="input-group" style="margin-bottom:24px">
                <label style="display:block;font-size:14px;margin-bottom:6px;font-weight:600" data-i18n="reg.password">
                    Palavra-passe <small style="color:#94a3b8;font-weight:400">(mín. 6 caracteres)</small>
                </label>
                <div class="input-wrapper">
                    <i class="ph ph-lock"></i>
                    <input type="password" name="password" placeholder="••••••••"
                           required minlength="6">
                </div>
            </div>

            <button type="submit" class="btn-primary-full" data-i18n="reg.btn"
                    style="width:100%;background:#7c3aed;color:white;border:none;
                           padding:14px;border-radius:8px;font-weight:600;cursor:pointer;
                           font-size:15px;font-family:'Inter',sans-serif">
                Criar Conta
            </button>
        </form>

        <?php endif; ?>

        <div class="auth-footer" style="text-align:center;margin-top:24px;font-size:14px;color:#64748b">
            <p><span data-i18n="reg.hasAccount">Já tem conta?</span> <a href="login.php" style="color:#7c3aed;text-decoration:none;font-weight:700" data-i18n="reg.loginLink">Entrar</a></p>
        </div>
    </div>

    <a href="index.html" class="back-to-site">
        <i class="ph ph-arrow-left"></i> <span data-i18n="reg.back">Voltar ao início</span>
    </a>
</div>

</body>
</html>
