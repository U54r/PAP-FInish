<?php
// admin_stats.php — Estatísticas globais do sistema (admin)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireRole(['administrador']);

$pdo = getDB();

$porRole = $pdo->query("
    SELECT r.nome_role, COUNT(u.id_utilizador) AS total
    FROM role r
    LEFT JOIN utilizador u ON u.id_role = r.id_role
    GROUP BY r.id_role, r.nome_role
")->fetchAll();

$totalEventos    = (int)$pdo->query("SELECT COUNT(*) FROM evento")->fetchColumn();
$eventosProximos  = (int)$pdo->query("SELECT COUNT(*) FROM evento WHERE data >= CURDATE()")->fetchColumn();
$totalUtilizadores = (int)$pdo->query("SELECT COUNT(*) FROM utilizador")->fetchColumn();
$contasInativas   = (int)$pdo->query("SELECT COUNT(*) FROM utilizador WHERE estado_conta != 'ativo'")->fetchColumn();

jsonOk([
    'total_utilizadores' => $totalUtilizadores,
    'contas_inativas'    => $contasInativas,
    'total_eventos'      => $totalEventos,
    'eventos_proximos'   => $eventosProximos,
    'por_role'           => $porRole,
]);
