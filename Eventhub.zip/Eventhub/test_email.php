<?php
// test_email.php — Testa a ligação SMTP e mostra o erro exacto
// Aceder em: http://localhost/Eventhub/test_email.php
// APAGAR este ficheiro depois de diagnosticar o problema
require_once __DIR__ . '/auth.php';
requireRole(['organizador']);
require_once __DIR__ . '/PHPMailer-7.1.1/src/Exception.php';
require_once __DIR__ . '/PHPMailer-7.1.1/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-7.1.1/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as MailerException;

$result  = null;
$error   = null;
$debug   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $toEmail = trim($_POST['to_email'] ?? '');
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email de destino inválido.';
    } else {
        $mail = new PHPMailer(true);
        $mail->SMTPDebug  = SMTP::DEBUG_SERVER;
        $mail->Debugoutput = function($str, $level) use (&$debug) {
            $debug .= htmlspecialchars($str) . "\n";
        };
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'gabrielrooliveira12@gmail.com';
            $mail->Password   = 'tsah ozjt qvnv fqxs';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            $mail->CharSet    = 'UTF-8';
            $mail->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];

            $mail->setFrom('gabrielrooliveira12@gmail.com', 'EventHub');
            $mail->addAddress($toEmail);
            $mail->isHTML(false);
            $mail->Subject = 'Teste SMTP — EventHub';
            $mail->Body    = 'Se recebeu este email, o SMTP está a funcionar correctamente.';

            $mail->send();
            $result = 'sucesso';
        } catch (MailerException $e) {
            $error = $mail->ErrorInfo;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Teste de Email — EventHub</title>
<style>
body{font-family:Arial,sans-serif;max-width:700px;margin:40px auto;padding:0 20px;background:#f4f4f4}
.card{background:#fff;border-radius:8px;padding:32px;box-shadow:0 2px 8px rgba(0,0,0,.1)}
h2{margin:0 0 24px;color:#1f2937}
label{display:block;margin-bottom:6px;font-weight:600;font-size:14px}
input[type=email]{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;box-sizing:border-box}
button{margin-top:16px;background:#4f46e5;color:#fff;border:none;padding:12px 24px;border-radius:6px;cursor:pointer;font-size:15px;font-weight:600}
.ok{background:#dcfce7;color:#166534;padding:16px;border-radius:6px;margin-top:20px;font-weight:600}
.err{background:#fee2e2;color:#991b1b;padding:16px;border-radius:6px;margin-top:20px}
pre{background:#1e293b;color:#94a3b8;padding:16px;border-radius:6px;font-size:12px;overflow-x:auto;margin-top:16px;white-space:pre-wrap;word-break:break-all}
.back{display:inline-block;margin-top:20px;color:#4f46e5;text-decoration:none;font-size:14px}
</style></head>
<body>
<div class="card">
    <h2>🔧 Teste de Email SMTP</h2>
    <form method="POST">
        <label>Enviar email de teste para:</label>
        <input type="email" name="to_email" required placeholder="o-seu-email@gmail.com"
               value="<?= htmlspecialchars($_POST['to_email'] ?? '') ?>">
        <button type="submit">Enviar Teste</button>
    </form>

    <?php if ($result === 'sucesso'): ?>
        <div class="ok">✅ Email enviado com sucesso! Verifique a caixa de entrada.</div>
    <?php elseif ($error): ?>
        <div class="err"><strong>❌ Erro SMTP:</strong><br><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($debug): ?>
        <p style="margin-top:20px;font-size:13px;font-weight:600;color:#374151">Log de ligação SMTP:</p>
        <pre><?= $debug ?></pre>
    <?php endif; ?>

    <a href="dashboard.php" class="back">← Voltar ao Dashboard</a>
</div>
</body>
</html>
