/* =================================================================
   lang.js — EventHub i18n  (European Portuguese ↔ American English)
   "EventHub" brand name is NEVER translated.
   ================================================================= */
'use strict';

const LANG_TRANSLATIONS = {
  pt: {
    /* ── Navigation ── */
    'nav.home':'Início','nav.features':'Funcionalidades','nav.about':'Sobre',
    'nav.signin':'Entrar','nav.register':'Registar','nav.logout':'Sair',
    'nav.openMenu':'Abrir menu','nav.closeMenu':'Fechar menu',

    /* ── Hero ── */
    'hero.title1':'Simplifique a Organização do',
    'hero.title2':'seu Evento Especial',
    'hero.subtitle':'A plataforma completa para gerir convidados, mesas, presentes e staff do seu casamento ou aniversário. Tudo num só lugar.',
    'hero.cta':'Começar Agora',

    /* ── Mockup ── */
    'mockup.eventTag':'Casamento','mockup.active':'Ativo',
    'mockup.weddingName':'Casamento Silva & Costa',
    'mockup.guests':'Convidados','mockup.confirmedGuests':'Convidados confirmados',
    'mockup.qrGenerated':'QR Codes gerados','mockup.location':'Quinta da Serra',

    /* ── Features ── */
    'feature.events.title':'Gestão de Eventos',
    'feature.events.desc':'Crie e edite eventos com informações completas.',
    'feature.guests.title':'Gestão de Convidados',
    'feature.guests.desc':'Adicione convidados e envie convites digitais.',
    'feature.gifts.title':'Lista de Presentes',
    'feature.gifts.desc':'Crie listas e permita reservas.',
    'feature.staff.title':'Gestão de Staff',
    'feature.staff.desc':'Organize tarefas da equipa.',
    'feature.resources.title':'Recursos do Evento',
    'feature.resources.desc':'Controle equipamentos e materiais.',
    'feature.qr.title':'QR Codes de Acesso',
    'feature.qr.desc':'Sistema de entrada com QR codes únicos.',

    /* ── Feature preview chips ── */
    'fp.reserved':'Reservado','fp.free':'Livre','fp.confirmed':'Confirmado',
    'fp.pending':'Pendente','fp.done':'Concluída','fp.uniqueQr':'QR Único',
    'fp.perGuest':'por convidado','fp.task1':'Montar decoração',
    'fp.task2':'Verificar catering','fp.task3':'Briefing ao staff',
    'fp.gift1':'Jantar para 8','fp.gift2':'Viagem de lua de mel',
    'fp.gift3':'Robot de cozinha','fp.chairs':'Cadeiras','fp.tables':'Mesas',
    'fp.projectors':'Projetores',

    /* ── About ── */
    'about.badge':'Sobre Nós',
    'about.title1':'Transformamos a gestão de eventos em algo',
    'about.title2':'simples',
    'about.subtitle':'O EventHub centraliza tudo o que um organizador precisa num só lugar.',
    'about.stat1.label':'Tipos de utilizador','about.stat2.label':'Módulos integrados',
    'about.card1':'Convidados geridos','about.card2':'Evento confirmado',
    'about.card3':'Presentes reservados',

    /* ── CTA ── */
    'cta.title1':'Pronto para simplificar o','cta.title2':'seu próximo evento?',
    'cta.subtitle':'Crie a sua conta gratuitamente e comece a organizar em minutos. Sem cartão de crédito.',
    'cta.btn':'Criar conta grátis','cta.link':'Já tenho conta',

    /* ── Footer ── */
    'footer.tagline':'Organização de eventos de forma inteligente.',
    'footer.platform':'Plataforma','footer.features':'Funcionalidades',
    'footer.dashboard':'Dashboard','footer.support':'Suporte',
    'footer.help':'Ajuda','footer.contact':'Contacto','footer.legal':'Legal',
    'footer.terms':'Termos de Uso','footer.privacy':'Privacidade',
    'footer.cookies':'Cookies',
    'footer.copyright':'© 2026 EventHub. Todos os direitos reservados.',

    /* ── Login ── */
    'login.title':'Bem-vindo de volta',
    'login.subtitle':'Entre na sua conta para gerir o seu evento',
    'login.email':'Email','login.password':'Palavra-passe',
    'login.forgot':'Esqueceu-se?','login.btn':'Entrar','login.or':'ou',
    'login.google':'Entrar com Google',
    'login.noAccount':'Não tem uma conta?','login.registerLink':'Registe-se',
    'login.back':'Voltar ao início',
    'login.togglePw':'Mostrar/ocultar palavra-passe',

    /* ── Register ── */
    'reg.title':'Criar conta','reg.subtitle':'Preencha os dados abaixo',
    'reg.role':'Eu sou...','reg.role.select':'Selecione uma opção',
    'reg.role.organizer':'Organizador (Crio eventos)',
    'reg.role.staff':'Staff (Trabalho em eventos)',
    'reg.role.guest':'Convidado (Vou a um evento)',
    'reg.name':'Nome Completo','reg.email':'Email',
    'reg.password':'Palavra-passe','reg.confirmPw':'Confirmar palavra-passe',
    'reg.btn':'Registar','reg.hasAccount':'Já tem conta?',
    'reg.loginLink':'Entrar','reg.back':'Voltar ao início',
    'reg.match':'As palavras-passe coincidem',
    'reg.noMatch':'As palavras-passe não coincidem',
    'reg.namePH':'Seu nome','reg.emailPH':'email@exemplo.com',

    /* ── Dashboard sidebar ── */
    'dash.inicio':'Início','dash.eventos':'Meus Eventos',
    'dash.convidados':'Convidados & Mesas','dash.decoracao':'Decoração',
    'dash.staff':'Staff & Tarefas','dash.presentes':'Lista de Presentes',
    'dash.recursos':'Recursos do Evento','dash.qrcodes':'QR Codes de Acesso',
    'dash.clientes':'Contratantes','dash.perfil':'Perfil',
    'dash.definicoes':'Definições','dash.logout':'Sair',
    'dash.role.organizer':'Organizador',

    /* ── Dashboard header ── */
    'dash.search':'Pesquisar...',
    'notif.title':'Notificações','notif.clearAll':'Limpar todas',
    'notif.empty':'Sem notificações',

    /* ── Stats ── */
    'stat.eventos':'Eventos Ativos','stat.convidados':'Total de Convidados',
    'stat.tarefas':'Tarefas Pendentes',

    /* ── Inicio section ── */
    'inicio.nextEvents':'Próximos Eventos','inicio.viewAll':'Ver todos',
    'inicio.pendingTasks':'Tarefas de Staff Pendentes',

    /* ── Table headers ── */
    'th.event':'Evento','th.date':'Data','th.location':'Local',
    'th.status':'Estado','th.actions':'Ações','th.name':'Nome',
    'th.email':'Email','th.phone':'Telefone','th.table':'Mesa',
    'th.rsvp':'RSVP','th.qrcode':'QR Code','th.capacity':'Capacidade',
    'th.shape':'Forma','th.category':'Categoria','th.qty':'Qtd.',
    'th.supplier':'Fornecedor','th.delivery':'Entrega',
    'th.confDeadline':'Prazo Conf.','th.item':'Item','th.contact':'Contacto',
    'th.estPrice':'Preço Est.','th.responsible':'Responsável',
    'th.description':'Descrição','th.start':'Início','th.end':'Fim',
    'th.priority':'Prioridade','th.assocEvent':'Evento Associado',

    /* ── Section titles ── */
    'section.eventos.title':'Meus Eventos',
    'section.eventos.sub':'Gerencie todos os seus eventos',
    'section.convidados.title':'Convidados & Mesas',
    'section.decor.title':'Decoração',
    'section.decor.sub':'Flores, centros de mesa, iluminação e mais',
    'section.staff.title':'Staff & Tarefas',
    'section.presentes.title':'Lista de Presentes',
    'section.recursos.title':'Recursos do Evento',
    'section.recursos.sub':'Equipamentos, materiais e logística',
    'section.qr.title':'QR Codes de Acesso',
    'section.clientes.title':'Clientes',
    'section.clientes.sub':'Gerencie os clientes e os seus eventos',

    /* ── Sub-tabs ── */
    'tab.guests':'Convidados','tab.tables':'Lista de Mesas',
    'tab.floor':'Planta da Sala','tab.staff':'Staff','tab.tasks':'Tarefas',

    /* ── Filters ── */
    'filter.all':'Todos','filter.active':'Ativos','filter.past':'Passados',

    /* ── Floor plan ── */
    'floor.theme':'Tema',
    'floor.hint':'Clique numa mesa para editar · Arraste para reposicionar',
    'floor.empty':'Selecione um evento para ver a planta da sala',
    'floor.noTables':'Nenhuma mesa neste evento. Adicione mesas primeiro.',
    'floor.newTable':'Nova Mesa',

    /* ── Perfil ── */
    'perfil.title':'O meu Perfil','perfil.sub':'Atualize os seus dados pessoais',
    'perfil.avatarNote':'Avatar gerado automaticamente',
    'perfil.fullName':'Nome Completo','perfil.email':'Email',
    'perfil.phone':'Telefone','perfil.role':'Função',
    'perfil.changePw':'Alterar Palavra-passe',
    'perfil.currentPw':'Atual','perfil.newPw':'Nova',
    'perfil.phonePH':'+351 9xx xxx xxx',
    'perfil.currentPwPH':'Atual','perfil.newPwPH':'Nova (mín. 6 caracteres)',
    'perfil.saveBtn':'Guardar Alterações',

    /* ── Settings section ── */
    'def.title':'Definições','def.sub':'Personalize a sua experiência',
    'def.langSection':'Idioma da Plataforma',
    'def.langDesc':'Escolha o idioma em que pretende usar o EventHub.',
    'def.langPt':'Português (Europa)','def.langEn':'English (US)',
    'def.tutorialSection':'Tutorial',
    'def.tutorialDesc':'Reveja o guia de introdução à plataforma a qualquer momento.',
    'def.tutorialBtn':'Iniciar Tutorial',

    /* ── Buttons ── */
    'btn.newEvent':'Novo Evento','btn.addGuest':'Adicionar',
    'btn.addTable':'Adicionar Mesa','btn.newTable':'Nova Mesa',
    'btn.addDecor':'Adicionar Item','btn.addStaff':'Adicionar Staff',
    'btn.addFornecedor':'Adicionar Fornecedor',
    'btn.newTask':'Nova Tarefa','btn.addGift':'Adicionar Presente',
    'btn.addResource':'Adicionar Recurso','btn.generateQR':'Gerar QR Code',
    'btn.newClient':'Novo Contratante','btn.saveEvent':'Guardar Evento',
    'btn.saveGuest':'Guardar','btn.saveTable':'Guardar Mesa',
    'btn.saveTask':'Guardar Tarefa','btn.saveGift':'Guardar Presente',
    'btn.saveResource':'Guardar Recurso','btn.saveDecor':'Guardar',
    'btn.saveClient':'Criar Cliente','btn.saveChanges':'Guardar Alterações',
    'btn.cancel':'Cancelar','btn.close':'Fechar','btn.preview':'Pré-visualizar',
    'btn.confirm':'Confirmar','btn.copy':'Copiar',
    'btn.createStaff':'Criar Staff','btn.generate':'Gerar',
    'btn.edit':'Editar','btn.delete':'Eliminar','btn.remove':'Remover',
    'btn.viewGuestPage':'Ver Página do Convidado','btn.genQRShort':'Gerar QR',
    'btn.download':'Descarregar','btn.viewClient':'Ver painel do contratante',
    'btn.viewStaff':'Ver painel do staff',
    'btn.sendAccess':'Enviar acesso por email',

    /* ── Modal titles ── */
    'modal.newEvent':'Novo Evento','modal.editEvent':'Editar Evento',
    'modal.addGuest':'Adicionar Convidado','modal.editGuest':'Editar Convidado',
    'modal.addTable':'Adicionar Mesa','modal.editTable':'Editar Mesa',
    'modal.newTask':'Nova Tarefa','modal.editTask':'Editar Tarefa',
    'modal.addGift':'Adicionar Presente','modal.editGift':'Editar Presente',
    'modal.addResource':'Adicionar Recurso','modal.editResource':'Editar Recurso',
    'modal.addDecor':'Adicionar Decoração','modal.editDecor':'Editar Decoração',
    'modal.addFornecedor':'Adicionar Fornecedor','modal.editFornecedor':'Editar Fornecedor',
    'modal.fornecedorName':'Nome do Fornecedor *','modal.fornecedorNamePH':'Ex: Flores & Arte',
    'modal.contactPH':'Nome do contacto',
    'modal.addStaff':'Adicionar Staff','modal.newClient':'Novo Contratante',
    'modal.editClient':'Editar Contratante','modal.generateQR':'Gerar QR Code',
    'modal.editStaff':'Editar Staff',

    /* ── Form labels ── */
    'form.eventName':'Nome do Evento *','form.date':'Data *','form.time':'Hora *',
    'form.eventType':'Tipo de Evento','form.location':'Local',
    'form.dresscode':'Dresscode','form.client':'Cliente',
    'form.description':'Descrição','form.fullName':'Nome *',
    'form.email':'Email','form.phone':'Telefone','form.event':'Evento *',
    'form.table':'Mesa','form.rsvpStatus':'Estado RSVP',
    'form.tableName':'Nome da Mesa','form.tableNum':'Número *',
    'form.tableCapacity':'Capacidade *','form.tableShape':'Forma',
    'form.tableLocation':'Localização','form.taskDesc':'Descrição *',
    'form.staffResponsible':'Staff Responsável','form.startDate':'Data de Início',
    'form.endDate':'Data de Fim','form.priority':'Prioridade',
    'form.status':'Estado','form.giftName':'Nome do Item *',
    'form.category':'Categoria','form.estPrice':'Preço Estimado (€)',
    'form.resourceName':'Nome do Recurso *','form.totalQty':'Quantidade Total',
    'form.usedQty':'Quantidade Usada','form.supplier':'Fornecedor',
    'form.deliveryDate':'Data de Entrega','form.confDeadline':'Prazo de Confirmação',
    'form.deliveryStatus':'Estado de Entrega','form.decorType':'Tipo / Descrição *',
    'form.theme':'Tema','form.unitPrice':'Preço Unitário (€)',
    'form.quantity':'Quantidade','form.notes':'Notas',
    'form.clientName':'Nome Completo *','form.clientEmail':'Email *',
    'form.clientPhone':'Telefone','form.clientPw':'Palavra-passe',
    'form.clientPwPH':'Deixar vazio para gerar automática',
    'form.clientNote':'O cliente receberá acesso ao painel do cliente para gerir convidados e presentes do seu evento.',
    'form.staffPwNote':'Se não preencher a palavra-passe, será gerada uma aleatória e mostrada após criação.',
    'form.staffPw':'Palavra-passe','form.staffPwPH':'Deixar vazio para gerar automática',

    /* ── Placeholders ── */
    'ph.eventName':'Ex: Casamento João & Maria',
    'ph.eventLocation':'Ex: Quinta das Flores, Sintra',
    'ph.eventDesc':'Descrição do evento...',
    'ph.guestName':'Nome completo','ph.guestEmail':'email@exemplo.com',
    'ph.guestPhone':'+351 9xx xxx xxx',
    'ph.tableName':'Ex: Mesa dos Padrinhos, Família da Noiva...',
    'ph.tableNum':'1','ph.tableCapacity':'Nº de pessoas',
    'ph.tableLocation':'Ex: Jardim, Salão Principal',
    'ph.taskDesc':'Descreva a tarefa...',
    'ph.giftName':'Ex: Jogo de Louça',
    'ph.resourceName':'Ex: Cadeiras, Projetor...',
    'ph.resourceSupplier':'Nome do fornecedor',
    'ph.decorType':'Ex: Arranjo floral, Centro de mesa, Iluminação...',
    'ph.decorNotes':'Detalhes adicionais...',
    'ph.decorSupplier':'Ex: Flores & Arte',
    'ph.clientName':'Nome do cliente','ph.clientEmail':'email@exemplo.com',
    'ph.clientPhone':'+351 9xx xxx xxx',
    'ph.staffName':'Nome do colaborador','ph.staffEmail':'email@exemplo.com',
    'ph.staffPhone':'+351 9xx xxx xxx','ph.staffRole':'Ex: Fotógrafo, DJ...',
    'ph.mesaName':'Ex: Mesa dos Noivos',
    'ph.search':'Pesquisar...',

    /* ── Select options ── */
    'opt.selectOption':'Selecionar...','opt.selectEvent':'Selecionar evento...',
    'opt.selectStaff':'Selecionar staff...','opt.noClient':'Sem cliente',
    'opt.noTable':'Sem mesa','opt.allEvents':'Todos os eventos',
    'opt.general':'Geral','opt.noGuests':'Sem convidados neste evento',
    'opt.selectEventFirst':'Selecione primeiro o evento',

    /* ── Event types ── */
    'etype.wedding':'💒 Casamento','etype.baby':'🍼 Baby Shower',
    'etype.birthday':'🎂 Aniversário','etype.christening':'⛪ Batizado',
    'etype.compDinner':'🏢 Jantar de Empresa','etype.conference':'📊 Conferência',
    'etype.other':'✨ Outro',

    /* ── Table shapes ── */
    'shape.round':'⭕ Redonda','shape.rect':'⬜ Rectangular',

    /* ── RSVP ── */
    'rsvp.pending':'Pendente','rsvp.confirmed':'Confirmado','rsvp.declined':'Recusado',

    /* ── Priority ── */
    'prio.alta':'Alta','prio.media':'Média','prio.baixa':'Baixa',

    /* ── Task state ── */
    'tstate.pending':'Pendente','tstate.inProgress':'Em Andamento','tstate.done':'Concluída',

    /* ── Delivery state ── */
    'dstate.pending':'Pendente','dstate.confirmed':'Confirmado',
    'dstate.delivered':'Entregue','dstate.cancelled':'Cancelado','dstate.delayed':'Atrasado',

    /* ── Present state ── */
    'gstate.pending':'Pendente','gstate.reserved':'Reservado','gstate.confirmed':'Confirmado',

    /* ── Gift categories ── */
    'gcat.appliances':'Eletrodomésticos','gcat.decor':'Decoração',
    'gcat.travel':'Viagem','gcat.money':'Dinheiro','gcat.other':'Outro',

    /* ── Resource categories ── */
    'rcat.furniture':'Mobiliário','rcat.av':'Audiovisual','rcat.catering':'Catering',
    'rcat.decor':'Decoração','rcat.transport':'Transporte','rcat.other':'Outro',

    /* ── Decor themes ── */
    'dtheme.wedding':'💒 Casamento','dtheme.baby':'🍼 Baby Shower',
    'dtheme.birthday':'🎂 Aniversário','dtheme.christening':'⛪ Batizado',

    /* ── Staff role label ── */
    'staffM.role':'Cargo','staffM.rolePH':'Ex: Fotógrafo, DJ...',

    /* ── QR modal ── */
    'qr.guestLabel':'Convidado *','qr.generateBtn':'Gerar',
    'qr.accessCode':'QR Code de Acesso','qr.close':'Fechar',

    /* ── Mesa panel ── */
    'msp.title':'Editar Mesa','msp.subtitle':'Clique em Guardar para confirmar',
    'msp.name':'Nome','msp.shape':'Forma','msp.size':'Tamanho',
    'msp.places':'Lugares','msp.cloth':'Cor da Toalha',
    'msp.round':'Redonda','msp.rect':'Retangular',
    'msp.small':'P','msp.med':'M','msp.large':'G',
    'msp.sizeSmall':'Pequeno','msp.sizeMed':'Médio','msp.sizeLarge':'Grande',
    'msp.save':'Guardar',

    /* ── Dynamic content ── */
    'dyn.loading':'A carregar...','dyn.noEvents':'Nenhum evento criado.',
    'dyn.noGuests':'Sem convidados.','dyn.noTasks':'Sem tarefas criadas.',
    'dyn.noGifts':'Sem presentes.','dyn.noResources':'Sem recursos.',
    'dyn.noFornecedores':'Sem fornecedores.',
    'dyn.noDecor':'Nenhum item de decoração. Adicione o primeiro!',
    'dyn.noStaff':'Nenhum staff encontrado','dyn.noClients':'Nenhum contratante registado. Crie o primeiro!',
    'dyn.noQR':'Nenhum QR Code gerado.','dyn.noTables':'Sem mesas.',
    'dyn.noPendingTasks':'Sem tarefas pendentes. 🎉',
    'dyn.noEvents2':'Sem eventos.',
    'dyn.tablePrefix':'Mesa ','dyn.tablePeople':' pessoas',
    'dyn.viewGuests':'Ver convidados',
    'dyn.active':'Ativo','dyn.past':'Passado',
    'dyn.staffMembers':'Membros da Equipa',
    'dyn.loadingTables':'A carregar mesas...',
    'dyn.noTablesForEvent':'Sem mesa (nenhuma mesa adicionada a este evento)',
    'dyn.delivery':'Entrega: ','dyn.qty':'Qtd: ',
    'dyn.activeStatus':'Ativo',
    'dyn.temaLabel.casamento':'💒 Casamento',
    'dyn.temaLabel.baby_shower':'🍼 Baby Shower',
    'dyn.temaLabel.aniversario':'🎂 Aniversário',
    'dyn.temaLabel.batizado':'⛪ Batizado',
    'dyn.temaLabel.outro':'✨ Outro',

    /* ── Toast messages ── */
    'toast.eventCreated':'🎉 Evento criado!','toast.eventUpdated':'✅ Evento atualizado!',
    'toast.eventDeleted':'Evento eliminado',
    'toast.clientDeleted':'Contratante eliminado','toast.staffDeleted':'Staff eliminado',
    'toast.guestAdded':'✅ Convidado adicionado!','toast.guestUpdated':'✅ Convidado atualizado!',
    'toast.guestEmailSent':'✓ Convidado adicionado e email enviado',
    'toast.guestEmailFail':'⚠ Convidado adicionado mas email não pôde ser enviado',
    'toast.guestDeleted':'Convidado removido',
    'toast.tableCreated':'✅ Mesa criada!','toast.tableUpdated':'✅ Mesa atualizada!',
    'toast.tableDeleted':'Mesa eliminada',
    'toast.tableUpdated2':'Mesa atualizada!',
    'toast.taskCreated':'✅ Tarefa criada!','toast.taskUpdated':'✅ Tarefa atualizada!',
    'toast.taskDeleted':'Tarefa eliminada',
    'toast.giftCreated':'✅ Presente adicionado!','toast.giftUpdated':'✅ Presente atualizado!',
    'toast.giftDeleted':'Presente eliminado',
    'toast.resourceCreated':'✅ Recurso criado!','toast.resourceUpdated':'✅ Recurso atualizado!',
    'toast.resourceDeleted':'Recurso eliminado',
    'toast.fornecedorCreated':'✅ Fornecedor criado!','toast.fornecedorUpdated':'✅ Fornecedor atualizado!',
    'toast.fornecedorDeleted':'Fornecedor eliminado',
    'toast.decorCreated':'✅ Item adicionado!','toast.decorUpdated':'✅ Decoração atualizada!',
    'toast.decorDeleted':'Item eliminado',
    'toast.copied':'Copiado!',
    'toast.staffCreated':'Staff criado com sucesso!',
    'toast.staffCreated2':'✅ Staff criado com sucesso!',
    'toast.staffUpdated':'✅ Staff atualizado!',
    'toast.clientCreated':'✅ Contratante criado!',
    'toast.clientUpdated':'✅ Contratante atualizado!',
    'toast.qrGenerated':'✅ QR Code gerado!','toast.qrDeleted':'QR Code eliminado',
    'toast.profileUpdated':'✅ Perfil atualizado!',
    'toast.notifsCleared':'Notificações limpas',
    'toast.errRequired':'Preencha todos os campos obrigatórios',
    'toast.errNameEvent':'Nome do evento é obrigatório',
    'toast.errNameGuest':'Nome e evento são obrigatórios',
    'toast.errDescEvent':'Descrição e evento são obrigatórios',
    'toast.errNameGift':'Nome do item e evento são obrigatórios',
    'toast.errNameResource':'Nome do recurso é obrigatório',
    'toast.errNameFornecedor':'Nome do fornecedor é obrigatório',
    'toast.errDecor':'Tipo e evento são obrigatórios',
    'toast.errClientName':'Nome e email são obrigatórios',
    'toast.errSelectQR':'Selecione evento e convidado',
    'toast.errEventUnknown':'Erro: evento desconhecido',
    'toast.err':'❌ Erro',

    /* ── Confirm dialogs ── */
    'confirm.deleteEvent':'Eliminar este evento? Esta ação é irreversível.',
    'confirm.deleteGuest':'Remover convidado?',
    'confirm.deleteTable':'Eliminar esta mesa?',
    'confirm.deleteClient':'Eliminar este contratante? A conta será removida e os eventos ficam sem contratante associado.',
    'confirm.deleteStaff':'Eliminar este staff? A conta e as suas tarefas serão removidas.',
    'confirm.deleteTask':'Eliminar esta tarefa?',
    'confirm.deleteGift':'Eliminar este presente?',
    'confirm.deleteResource':'Eliminar este recurso?',
    'confirm.deleteFornecedor':'Eliminar este fornecedor?',
    'confirm.deleteDecor':'Eliminar este item de decoração?',
    'confirm.deleteQR':'Eliminar QR Code?',
    'confirm.sendEmail':'Enviar email de acesso ao portal para {0}?\n\nSerá gerada uma nova password temporária e enviada por email.',
    'confirm.sendEmailGuest':'Reenviar convite/acesso a {0} por email?',

    /* ── Tutorial ── */
    'tut.welcome.title':'Bem-vindo ao EventHub!',
    'tut.welcome.body':'Vamos mostrar-lhe as principais funcionalidades da plataforma. Este tutorial pode ser saltado a qualquer momento e reiniciado nas <strong>Definições</strong>.',
    'tut.welcome.start':'Começar Tour',
    'tut.welcome.skip':'Saltar Tutorial',
    'tut.next':'Próximo','tut.prev':'Anterior','tut.finish':'Concluir',
    'tut.skip':'Saltar','tut.stepOf':'de',
    'tut.s1.title':'O seu Painel Principal',
    'tut.s1.body':'Este é o seu painel de controlo. Veja o resumo dos seus eventos ativos, convidados totais e tarefas pendentes em tempo real.',
    'tut.s2.title':'Menu de Navegação',
    'tut.s2.body':'Use o menu lateral para navegar entre as secções: Eventos, Convidados, Decoração, Staff, Presentes, Recursos, QR Codes e Clientes.',
    'tut.s3.title':'Gestão de Eventos',
    'tut.s3.body':'Crie e gira todos os seus eventos aqui. Adicione data, local, tipo de evento, dresscode e cliente associado.',
    'tut.s4.title':'Convidados & Mesas',
    'tut.s4.body':'Adicione convidados, atribua-os a mesas e use a Planta da Sala para visualizar a disposição com drag & drop.',
    'tut.s5.title':'QR Codes de Acesso',
    'tut.s5.body':'Gere QR codes únicos para cada convidado. Facilita o check-in no dia do evento — basta digitalizar o código à entrada.',
    'tut.s6.title':'Definições & Idioma',
    'tut.s6.body':'Nas Definições (último item do menu) altere o idioma entre Português e English, e reinicie este tutorial quando quiser.',

    /* ── Tooltips ── */
    'tip.rsvp':'RSVP (Répondez s\'il vous plaît) — Confirmação de presença do convidado no evento.',
    'tip.qrcode':'QR Code — Código único que permite o check-in rápido do convidado à entrada do evento.',
    'tip.checkin':'Check-in — Registo e confirmação da presença de um convidado à entrada do evento.',
    'tip.dresscode':'Dresscode — Código de vestimenta sugerido para os convidados do evento.',
    'tip.staff':'Staff — Equipa de profissionais que trabalham na organização e execução do evento.',
    'tip.dashboard':'Dashboard — Painel central de controlo com resumo de todas as atividades.',
    'tip.floorPlan':'Planta da Sala — Vista visual da disposição das mesas no espaço do evento.',
    'tip.catering':'Catering — Serviço de alimentação e bebidas fornecido no evento.',

    /* ── Lang switcher ── */
    'lang.choose':'Idioma / Language',
    'lang.pt':'Português (PT)','lang.en':'English (US)',
    'lang.ptDesc':'Português Europeu','lang.enDesc':'American English',

    /* ── Settings keys ── */
    'settings.subtitle':'Personalização e preferências',
    'settings.langTitle':'Idioma','settings.langSubtitle':'Escolha o idioma da interface',
    'settings.tutTitle':'Tutorial',
    'settings.tutSubtitle':'Relance o tutorial de introdução à plataforma',
    'btn.restartTutorial':'Reiniciar Tutorial',
    'btn.genQR':'Gerar QR Code','btn.save':'Guardar','btn.createClient':'Criar Contratante',

    /* ── Nav aliases ── */
    'nav.decoracao':'Decoração','nav.recursos':'Recursos do Evento',
    'nav.tarefas':'Tarefas','nav.staff':'Staff & Tarefas',
    'nav.clientes':'Contratantes','nav.perfil':'Perfil','nav.presentes':'Lista de Presentes',
    'nav.fornecedores':'Fornecedores',

    /* ── Section subtitles ── */
    'decor.subtitle':'Flores, centros de mesa, iluminação e mais',
    'clientes.subtitle':'Gerencie os contratantes e os seus eventos',
    'recursos.subtitle':'Equipamentos, materiais e logística',
    'fornecedores.subtitle':'Gerencie os fornecedores dos seus eventos',
    'perfil.subtitle':'Atualize os seus dados pessoais',
    'perfil.avatarAuto':'Avatar gerado automaticamente',
    'staff.teamTitle':'Membros da Equipa','qr.titleSuffix':'de Acesso',
    'evento.contratante':'Contratante',

    /* ── Select option aliases ── */
    'select.event':'Selecionar evento...','select.pick':'Selecionar...',
    'select.noClient':'Sem contratante','select.noTable':'Sem mesa',
    'select.noFornecedor':'Sem fornecedor',
    'select.staff':'Selecionar staff...','filter.allEvents':'Todos os eventos',

    /* ── Event type aliases ── */
    'evtype.casamento':'💒 Casamento','evtype.babyShower':'🍼 Baby Shower',
    'evtype.aniversario':'🎂 Aniversário','evtype.batizado':'⛪ Batizado',
    'evtype.jantarEmpresa':'🏢 Jantar de Empresa','evtype.conferencia':'📊 Conferência',
    'evtype.outro':'✨ Outro',

    /* ── RSVP / status aliases ── */
    'rsvp.pendente':'Pendente','rsvp.confirmado':'Confirmado','rsvp.recusado':'Recusado',
    'priority.media':'Média','priority.alta':'Alta','priority.baixa':'Baixa',
    'task.pendente':'Pendente','task.emAndamento':'Em Andamento','task.concluida':'Concluída',
    'gift.reservado':'Reservado',
    'delivery.entregue':'Entregue','delivery.cancelado':'Cancelado','delivery.atrasado':'Atrasado',

    /* ── Shape aliases ── */
    'shape.round2':'Redonda','shape.rectangle':'⬜ Rectangular','shape.rectangle2':'Retangular',

    /* ── Category aliases ── */
    'giftcat.eletro':'Eletrodomésticos','giftcat.viagem':'Viagem','giftcat.dinheiro':'Dinheiro',
    'rescat.mobiliario':'Mobiliário','rescat.audiovisual':'Audiovisual',
    'rescat.catering':'Catering','rescat.transporte':'Transporte',
    'decor.themeGeneral':'Geral',

    /* ── QR aliases ── */
    'qr.guest':'Convidado *','qr.selectEventFirst':'Selecione primeiro o evento',

    /* ── Mesa panel aliases ── */
    'msp.editTable':'Editar Mesa','msp.saveHint':'Clique em Guardar para confirmar',
    'msp.seats':'Lugares','msp.tablecloth':'Cor da Toalha',
    'msp.namePH':'Ex: Mesa dos Noivos','msp.deleteTable':'Eliminar mesa',
    'size.medium':'Médio','size.s':'P','size.m':'M','size.l':'G',

    /* ── Modal label aliases ── */
    'modal.eventName':'Nome do Evento *','modal.eventNamePH':'Ex: Casamento João & Maria',
    'modal.time':'Hora *','modal.eventType':'Tipo de Evento',
    'modal.locationPH':'Ex: Quinta das Flores, Sintra',
    'modal.description':'Descrição','modal.descriptionPH':'Descrição do evento...',
    'modal.location':'Localização','modal.fullName':'Nome completo',
    'modal.rsvpStatus':'Estado RSVP','modal.tableName':'Nome da Mesa',
    'modal.tableNamePH':'Ex: Mesa dos Padrinhos, Família da Noiva...',
    'modal.tableNum':'Número *','modal.capacityPH':'Nº de pessoas',
    'modal.locationPH2':'Ex: Jardim, Salão Principal',
    'modal.taskDescPH':'Descreva a tarefa...',
    'modal.staffResponsible':'Staff Responsável',
    'modal.itemNamePH':'Ex: Jogo de Louça',
    'modal.resourceName':'Nome do Recurso *',
    'modal.resourceNamePH':'Ex: Cadeiras, Projetor...',
    'modal.totalQty':'Quantidade Total','modal.usedQty':'Quantidade Usada',
    'modal.supplierPH':'Nome do fornecedor','modal.supplierPH2':'Ex: Flores & Arte',
    'modal.decorType':'Tipo / Descrição *',
    'modal.decorTypePH':'Ex: Arranjo floral, Centro de mesa, Iluminação...',
    'modal.quantity':'Quantidade','modal.unitPrice':'Preço Unitário (€)',
    'modal.notes':'Notas','modal.notesPH':'Detalhes adicionais...',
    'modal.clientNamePH':'Nome do contratante',
    'modal.autoPassword':'Deixar vazio para gerar automática',
    'modal.clientNote':'O contratante receberá acesso ao painel do cliente para gerir convidados e presentes do seu evento.',
    'modal.staffNote':'Se não preencher a palavra-passe, será gerada uma aleatória e mostrada após criação.',

    /* ── Table header aliases ── */
    'th.deadline':'Prazo Conf.','th.linkedEvent':'Evento Associado',

    /* ── Floor plan text splits ── */
    'floor.clickEdit':'Clique numa mesa para editar','floor.dragRepos':'Arraste para reposicionar',
  },

  en: {
    /* ── Navigation ── */
    'nav.home':'Home','nav.features':'Features','nav.about':'About',
    'nav.signin':'Sign In','nav.register':'Sign Up','nav.logout':'Sign Out',
    'nav.openMenu':'Open menu','nav.closeMenu':'Close menu',

    /* ── Hero ── */
    'hero.title1':'Simplify the Organization of Your',
    'hero.title2':'Special Event',
    'hero.subtitle':'The complete platform to manage guests, tables, gifts, and staff for your wedding or anniversary. All in one place.',
    'hero.cta':'Get Started',

    /* ── Mockup ── */
    'mockup.eventTag':'Wedding','mockup.active':'Active',
    'mockup.weddingName':'Wedding Silva & Costa',
    'mockup.guests':'Guests','mockup.confirmedGuests':'Confirmed guests',
    'mockup.qrGenerated':'QR Codes generated','mockup.location':'Quinta da Serra',

    /* ── Features ── */
    'feature.events.title':'Event Management',
    'feature.events.desc':'Create and edit events with complete information.',
    'feature.guests.title':'Guest Management',
    'feature.guests.desc':'Add guests and send digital invitations.',
    'feature.gifts.title':'Gift List',
    'feature.gifts.desc':'Create lists and allow reservations.',
    'feature.staff.title':'Staff Management',
    'feature.staff.desc':'Organize team tasks.',
    'feature.resources.title':'Event Resources',
    'feature.resources.desc':'Track equipment and materials.',
    'feature.qr.title':'Access QR Codes',
    'feature.qr.desc':'Entry system with unique QR codes.',

    /* ── Feature preview chips ── */
    'fp.reserved':'Reserved','fp.free':'Available','fp.confirmed':'Confirmed',
    'fp.pending':'Pending','fp.done':'Completed','fp.uniqueQr':'Unique QR',
    'fp.perGuest':'per guest','fp.task1':'Set up decorations',
    'fp.task2':'Check catering','fp.task3':'Staff briefing',
    'fp.gift1':'Dinner for 8','fp.gift2':'Honeymoon trip',
    'fp.gift3':'Kitchen appliance','fp.chairs':'Chairs','fp.tables':'Tables',
    'fp.projectors':'Projectors',

    /* ── About ── */
    'about.badge':'About Us',
    'about.title1':'We transform event management into something',
    'about.title2':'simple',
    'about.subtitle':'EventHub centralizes everything an organizer needs in one place.',
    'about.stat1.label':'User types','about.stat2.label':'Integrated modules',
    'about.card1':'Managed guests','about.card2':'Event confirmed',
    'about.card3':'Reserved gifts',

    /* ── CTA ── */
    'cta.title1':'Ready to simplify your','cta.title2':'next event?',
    'cta.subtitle':'Create your account for free and start organizing in minutes. No credit card needed.',
    'cta.btn':'Create free account','cta.link':'I already have an account',

    /* ── Footer ── */
    'footer.tagline':'Smart event organization.',
    'footer.platform':'Platform','footer.features':'Features',
    'footer.dashboard':'Dashboard','footer.support':'Support',
    'footer.help':'Help','footer.contact':'Contact','footer.legal':'Legal',
    'footer.terms':'Terms of Use','footer.privacy':'Privacy',
    'footer.cookies':'Cookies',
    'footer.copyright':'© 2026 EventHub. All rights reserved.',

    /* ── Login ── */
    'login.title':'Welcome back',
    'login.subtitle':'Sign in to your account to manage your event',
    'login.email':'Email','login.password':'Password',
    'login.forgot':'Forgot?','login.btn':'Sign In','login.or':'or',
    'login.google':'Sign in with Google',
    'login.noAccount':"Don't have an account?",'login.registerLink':'Sign up',
    'login.back':'Back to home','login.togglePw':'Show/hide password',

    /* ── Register ── */
    'reg.title':'Create account','reg.subtitle':'Fill in the details below',
    'reg.role':'I am...','reg.role.select':'Select an option',
    'reg.role.organizer':'Organizer (I create events)',
    'reg.role.staff':'Staff (I work at events)',
    'reg.role.guest':'Guest (I attend events)',
    'reg.name':'Full Name','reg.email':'Email',
    'reg.password':'Password','reg.confirmPw':'Confirm password',
    'reg.btn':'Sign Up','reg.hasAccount':'Already have an account?',
    'reg.loginLink':'Sign in','reg.back':'Back to home',
    'reg.match':'Passwords match','reg.noMatch':'Passwords do not match',
    'reg.namePH':'Your name','reg.emailPH':'email@example.com',

    /* ── Dashboard sidebar ── */
    'dash.inicio':'Home','dash.eventos':'My Events',
    'dash.convidados':'Guests & Tables','dash.decoracao':'Decoration',
    'dash.staff':'Staff & Tasks','dash.presentes':'Gift List',
    'dash.recursos':'Event Resources','dash.qrcodes':'Access QR Codes',
    'dash.clientes':'Contractors','dash.perfil':'Profile',
    'dash.definicoes':'Settings','dash.logout':'Sign Out',
    'dash.role.organizer':'Organizer',

    /* ── Dashboard header ── */
    'dash.search':'Search...',
    'notif.title':'Notifications','notif.clearAll':'Clear all',
    'notif.empty':'No notifications',

    /* ── Stats ── */
    'stat.eventos':'Active Events','stat.convidados':'Total Guests',
    'stat.tarefas':'Pending Tasks',

    /* ── Inicio section ── */
    'inicio.nextEvents':'Upcoming Events','inicio.viewAll':'View all',
    'inicio.pendingTasks':'Pending Staff Tasks',

    /* ── Table headers ── */
    'th.event':'Event','th.date':'Date','th.location':'Location',
    'th.status':'Status','th.actions':'Actions','th.name':'Name',
    'th.email':'Email','th.phone':'Phone','th.table':'Table',
    'th.rsvp':'RSVP','th.qrcode':'QR Code','th.capacity':'Capacity',
    'th.shape':'Shape','th.category':'Category','th.qty':'Qty.',
    'th.supplier':'Supplier','th.delivery':'Delivery',
    'th.confDeadline':'Conf. Deadline','th.item':'Item','th.contact':'Contact',
    'th.estPrice':'Est. Price','th.responsible':'Responsible',
    'th.description':'Description','th.start':'Start','th.end':'End',
    'th.priority':'Priority','th.assocEvent':'Associated Event',

    /* ── Section titles ── */
    'section.eventos.title':'My Events',
    'section.eventos.sub':'Manage all your events',
    'section.convidados.title':'Guests & Tables',
    'section.decor.title':'Decoration',
    'section.decor.sub':'Flowers, centerpieces, lighting and more',
    'section.staff.title':'Staff & Tasks',
    'section.presentes.title':'Gift List',
    'section.recursos.title':'Event Resources',
    'section.recursos.sub':'Equipment, materials and logistics',
    'section.qr.title':'Access QR Codes',
    'section.clientes.title':'Clients',
    'section.clientes.sub':'Manage clients and their events',

    /* ── Sub-tabs ── */
    'tab.guests':'Guests','tab.tables':'Table List',
    'tab.floor':'Floor Plan','tab.staff':'Staff','tab.tasks':'Tasks',

    /* ── Filters ── */
    'filter.all':'All','filter.active':'Active','filter.past':'Past',

    /* ── Floor plan ── */
    'floor.theme':'Theme',
    'floor.hint':'Click a table to edit · Drag to reposition',
    'floor.empty':'Select an event to view the floor plan',
    'floor.noTables':'No tables for this event. Add tables first.',
    'floor.newTable':'New Table',

    /* ── Perfil ── */
    'perfil.title':'My Profile','perfil.sub':'Update your personal information',
    'perfil.avatarNote':'Automatically generated avatar',
    'perfil.fullName':'Full Name','perfil.email':'Email',
    'perfil.phone':'Phone','perfil.role':'Role',
    'perfil.changePw':'Change Password',
    'perfil.currentPw':'Current','perfil.newPw':'New',
    'perfil.phonePH':'+1 (555) 000-0000',
    'perfil.currentPwPH':'Current','perfil.newPwPH':'New (min. 6 characters)',
    'perfil.saveBtn':'Save Changes',

    /* ── Settings section ── */
    'def.title':'Settings','def.sub':'Customize your experience',
    'def.langSection':'Platform Language',
    'def.langDesc':'Choose the language you want to use EventHub in.',
    'def.langPt':'Portuguese (Europe)','def.langEn':'English (US)',
    'def.tutorialSection':'Tutorial',
    'def.tutorialDesc':'Review the platform introduction guide at any time.',
    'def.tutorialBtn':'Start Tutorial',

    /* ── Buttons ── */
    'btn.newEvent':'New Event','btn.addGuest':'Add',
    'btn.addTable':'Add Table','btn.newTable':'New Table',
    'btn.addDecor':'Add Item','btn.addStaff':'Add Staff',
    'btn.addFornecedor':'Add Supplier',
    'btn.newTask':'New Task','btn.addGift':'Add Gift',
    'btn.addResource':'Add Resource','btn.generateQR':'Generate QR Code',
    'btn.newClient':'New Contractor','btn.saveEvent':'Save Event',
    'btn.saveGuest':'Save','btn.saveTable':'Save Table',
    'btn.saveTask':'Save Task','btn.saveGift':'Save Gift',
    'btn.saveResource':'Save Resource','btn.saveDecor':'Save',
    'btn.saveClient':'Create Client','btn.saveChanges':'Save Changes',
    'btn.cancel':'Cancel','btn.close':'Close','btn.preview':'Preview',
    'btn.confirm':'Confirm','btn.copy':'Copy',
    'btn.createStaff':'Create Staff','btn.generate':'Generate',
    'btn.edit':'Edit','btn.delete':'Delete','btn.remove':'Remove',
    'btn.viewGuestPage':'View Guest Page','btn.genQRShort':'Generate QR',
    'btn.download':'Download','btn.viewClient':'View Contractor Panel',
    'btn.viewStaff':'View Staff Panel',
    'btn.sendAccess':'Send Access by Email',

    /* ── Modal titles ── */
    'modal.newEvent':'New Event','modal.editEvent':'Edit Event',
    'modal.addGuest':'Add Guest','modal.editGuest':'Edit Guest',
    'modal.addTable':'Add Table','modal.editTable':'Edit Table',
    'modal.newTask':'New Task','modal.editTask':'Edit Task',
    'modal.addGift':'Add Gift','modal.editGift':'Edit Gift',
    'modal.addResource':'Add Resource','modal.editResource':'Edit Resource',
    'modal.addDecor':'Add Decoration','modal.editDecor':'Edit Decoration',
    'modal.addFornecedor':'Add Supplier','modal.editFornecedor':'Edit Supplier',
    'modal.fornecedorName':'Supplier Name *','modal.fornecedorNamePH':'E.g.: Flowers & Art',
    'modal.contactPH':'Contact name',
    'modal.addStaff':'Add Staff','modal.newClient':'New Contractor',
    'modal.editClient':'Edit Contractor','modal.generateQR':'Generate QR Code',
    'modal.editStaff':'Edit Staff',

    /* ── Form labels ── */
    'form.eventName':'Event Name *','form.date':'Date *','form.time':'Time *',
    'form.eventType':'Event Type','form.location':'Location',
    'form.dresscode':'Dress Code','form.client':'Client',
    'form.description':'Description','form.fullName':'Name *',
    'form.email':'Email','form.phone':'Phone','form.event':'Event *',
    'form.table':'Table','form.rsvpStatus':'RSVP Status',
    'form.tableName':'Table Name','form.tableNum':'Number *',
    'form.tableCapacity':'Capacity *','form.tableShape':'Shape',
    'form.tableLocation':'Location','form.taskDesc':'Description *',
    'form.staffResponsible':'Responsible Staff','form.startDate':'Start Date',
    'form.endDate':'End Date','form.priority':'Priority',
    'form.status':'Status','form.giftName':'Item Name *',
    'form.category':'Category','form.estPrice':'Estimated Price (€)',
    'form.resourceName':'Resource Name *','form.totalQty':'Total Quantity',
    'form.usedQty':'Used Quantity','form.supplier':'Supplier',
    'form.deliveryDate':'Delivery Date','form.confDeadline':'Confirmation Deadline',
    'form.deliveryStatus':'Delivery Status','form.decorType':'Type / Description *',
    'form.theme':'Theme','form.unitPrice':'Unit Price (€)',
    'form.quantity':'Quantity','form.notes':'Notes',
    'form.clientName':'Full Name *','form.clientEmail':'Email *',
    'form.clientPhone':'Phone','form.clientPw':'Password',
    'form.clientPwPH':'Leave blank to auto-generate',
    'form.clientNote':'The client will receive access to the client portal to manage guests and gifts for their event.',
    'form.staffPwNote':'If you leave the password blank, a random one will be generated and shown after creation.',
    'form.staffPw':'Password','form.staffPwPH':'Leave blank to auto-generate',

    /* ── Placeholders ── */
    'ph.eventName':'Ex: Wedding John & Mary',
    'ph.eventLocation':'Ex: Grand Ballroom, New York',
    'ph.eventDesc':'Event description...',
    'ph.guestName':'Full name','ph.guestEmail':'email@example.com',
    'ph.guestPhone':'+1 (555) 000-0000',
    'ph.tableName':'Ex: Best Man\'s Table, Bride\'s Family...',
    'ph.tableNum':'1','ph.tableCapacity':'No. of people',
    'ph.tableLocation':'Ex: Garden, Main Hall',
    'ph.taskDesc':'Describe the task...',
    'ph.giftName':'Ex: Dinnerware Set',
    'ph.resourceName':'Ex: Chairs, Projector...',
    'ph.resourceSupplier':'Supplier name',
    'ph.decorType':'Ex: Floral arrangement, Centerpiece, Lighting...',
    'ph.decorNotes':'Additional details...',
    'ph.decorSupplier':'Ex: Flowers & Art',
    'ph.clientName':'Client name','ph.clientEmail':'email@example.com',
    'ph.clientPhone':'+1 (555) 000-0000',
    'ph.staffName':'Staff member name','ph.staffEmail':'email@example.com',
    'ph.staffPhone':'+1 (555) 000-0000','ph.staffRole':'Ex: Photographer, DJ...',
    'ph.mesaName':'Ex: Bride & Groom\'s Table',
    'ph.search':'Search...',

    /* ── Select options ── */
    'opt.selectOption':'Select...','opt.selectEvent':'Select event...',
    'opt.selectStaff':'Select staff...','opt.noClient':'No client',
    'opt.noTable':'No table','opt.allEvents':'All events',
    'opt.general':'General','opt.noGuests':'No guests in this event',
    'opt.selectEventFirst':'Select the event first',

    /* ── Event types ── */
    'etype.wedding':'💒 Wedding','etype.baby':'🍼 Baby Shower',
    'etype.birthday':'🎂 Birthday','etype.christening':'⛪ Christening',
    'etype.compDinner':'🏢 Company Dinner','etype.conference':'📊 Conference',
    'etype.other':'✨ Other',

    /* ── Table shapes ── */
    'shape.round':'⭕ Round','shape.rect':'⬜ Rectangular',

    /* ── RSVP ── */
    'rsvp.pending':'Pending','rsvp.confirmed':'Confirmed','rsvp.declined':'Declined',

    /* ── Priority ── */
    'prio.alta':'High','prio.media':'Medium','prio.baixa':'Low',

    /* ── Task state ── */
    'tstate.pending':'Pending','tstate.inProgress':'In Progress','tstate.done':'Completed',

    /* ── Delivery state ── */
    'dstate.pending':'Pending','dstate.confirmed':'Confirmed',
    'dstate.delivered':'Delivered','dstate.cancelled':'Cancelled','dstate.delayed':'Delayed',

    /* ── Present state ── */
    'gstate.pending':'Pending','gstate.reserved':'Reserved','gstate.confirmed':'Confirmed',

    /* ── Gift categories ── */
    'gcat.appliances':'Appliances','gcat.decor':'Decoration',
    'gcat.travel':'Travel','gcat.money':'Money','gcat.other':'Other',

    /* ── Resource categories ── */
    'rcat.furniture':'Furniture','rcat.av':'Audiovisual','rcat.catering':'Catering',
    'rcat.decor':'Decoration','rcat.transport':'Transport','rcat.other':'Other',

    /* ── Decor themes ── */
    'dtheme.wedding':'💒 Wedding','dtheme.baby':'🍼 Baby Shower',
    'dtheme.birthday':'🎂 Birthday','dtheme.christening':'⛪ Christening',

    /* ── Staff role label ── */
    'staffM.role':'Position','staffM.rolePH':'Ex: Photographer, DJ...',

    /* ── QR modal ── */
    'qr.guestLabel':'Guest *','qr.generateBtn':'Generate',
    'qr.accessCode':'Access QR Code','qr.close':'Close',

    /* ── Mesa panel ── */
    'msp.title':'Edit Table','msp.subtitle':'Click Save to confirm',
    'msp.name':'Name','msp.shape':'Shape','msp.size':'Size',
    'msp.places':'Seats','msp.cloth':'Tablecloth Color',
    'msp.round':'Round','msp.rect':'Rectangular',
    'msp.small':'S','msp.med':'M','msp.large':'L',
    'msp.sizeSmall':'Small','msp.sizeMed':'Medium','msp.sizeLarge':'Large',
    'msp.save':'Save',

    /* ── Dynamic content ── */
    'dyn.loading':'Loading...','dyn.noEvents':'No events created.',
    'dyn.noGuests':'No guests.','dyn.noTasks':'No tasks created.',
    'dyn.noGifts':'No gifts.','dyn.noResources':'No resources.',
    'dyn.noFornecedores':'No suppliers.',
    'dyn.noDecor':'No decoration items. Add the first!',
    'dyn.noStaff':'No staff found','dyn.noClients':'No contractors registered. Create the first!',
    'dyn.noQR':'No QR Codes generated.','dyn.noTables':'No tables.',
    'dyn.noPendingTasks':'No pending tasks. 🎉',
    'dyn.noEvents2':'No events.',
    'dyn.tablePrefix':'Table ','dyn.tablePeople':' people',
    'dyn.viewGuests':'View guests',
    'dyn.active':'Active','dyn.past':'Past',
    'dyn.staffMembers':'Team Members',
    'dyn.loadingTables':'Loading tables...',
    'dyn.noTablesForEvent':'No table (no tables added to this event)',
    'dyn.delivery':'Delivery: ','dyn.qty':'Qty: ',
    'dyn.activeStatus':'Active',
    'dyn.temaLabel.casamento':'💒 Wedding',
    'dyn.temaLabel.baby_shower':'🍼 Baby Shower',
    'dyn.temaLabel.aniversario':'🎂 Birthday',
    'dyn.temaLabel.batizado':'⛪ Christening',
    'dyn.temaLabel.outro':'✨ Other',

    /* ── Toast messages ── */
    'toast.eventCreated':'🎉 Event created!','toast.eventUpdated':'✅ Event updated!',
    'toast.eventDeleted':'Event deleted',
    'toast.clientDeleted':'Contractor deleted','toast.staffDeleted':'Staff deleted',
    'toast.guestAdded':'✅ Guest added!','toast.guestUpdated':'✅ Guest updated!',
    'toast.guestEmailSent':'✓ Guest added and email sent',
    'toast.guestEmailFail':'⚠ Guest added but email could not be sent',
    'toast.guestDeleted':'Guest removed',
    'toast.tableCreated':'✅ Table created!','toast.tableUpdated':'✅ Table updated!',
    'toast.tableDeleted':'Table deleted',
    'toast.tableUpdated2':'Table updated!',
    'toast.taskCreated':'✅ Task created!','toast.taskUpdated':'✅ Task updated!',
    'toast.taskDeleted':'Task deleted',
    'toast.giftCreated':'✅ Gift added!','toast.giftUpdated':'✅ Gift updated!',
    'toast.giftDeleted':'Gift deleted',
    'toast.resourceCreated':'✅ Resource created!','toast.resourceUpdated':'✅ Resource updated!',
    'toast.resourceDeleted':'Resource deleted',
    'toast.fornecedorCreated':'✅ Supplier created!','toast.fornecedorUpdated':'✅ Supplier updated!',
    'toast.fornecedorDeleted':'Supplier deleted',
    'toast.decorCreated':'✅ Item added!','toast.decorUpdated':'✅ Decoration updated!',
    'toast.decorDeleted':'Item deleted',
    'toast.copied':'Copied!',
    'toast.staffCreated':'Staff created successfully!',
    'toast.staffCreated2':'✅ Staff created successfully!',
    'toast.staffUpdated':'✅ Staff updated!',
    'toast.clientCreated':'✅ Contractor created!',
    'toast.clientUpdated':'✅ Contractor updated!',
    'toast.qrGenerated':'✅ QR Code generated!','toast.qrDeleted':'QR Code deleted',
    'toast.profileUpdated':'✅ Profile updated!',
    'toast.notifsCleared':'Notifications cleared',
    'toast.errRequired':'Please fill in all required fields',
    'toast.errNameEvent':'Event name is required',
    'toast.errNameGuest':'Name and event are required',
    'toast.errDescEvent':'Description and event are required',
    'toast.errNameGift':'Item name and event are required',
    'toast.errNameResource':'Resource name is required',
    'toast.errNameFornecedor':'Supplier name is required',
    'toast.errDecor':'Type and event are required',
    'toast.errClientName':'Name and email are required',
    'toast.errSelectQR':'Select event and guest',
    'toast.errEventUnknown':'Error: unknown event',
    'toast.err':'❌ Error',

    /* ── Confirm dialogs ── */
    'confirm.deleteEvent':'Delete this event? This action cannot be undone.',
    'confirm.deleteGuest':'Remove guest?',
    'confirm.deleteTable':'Delete this table?',
    'confirm.deleteClient':'Delete this contractor? The account will be removed and their events will be left without a contractor.',
    'confirm.deleteStaff':'Delete this staff member? The account and their tasks will be removed.',
    'confirm.deleteTask':'Delete this task?',
    'confirm.deleteGift':'Delete this gift?',
    'confirm.deleteResource':'Delete this resource?',
    'confirm.deleteFornecedor':'Delete this supplier?',
    'confirm.deleteDecor':'Delete this decoration item?',
    'confirm.deleteQR':'Delete QR Code?',
    'confirm.sendEmail':'Send portal access email to {0}?\n\nA new temporary password will be generated and sent by email.',
    'confirm.sendEmailGuest':'Resend invite/access to {0} by email?',

    /* ── Tutorial ── */
    'tut.welcome.title':'Welcome to EventHub!',
    'tut.welcome.body':"Let's show you the main features of the platform. This tutorial can be skipped at any time and restarted in <strong>Settings</strong>.",
    'tut.welcome.start':'Start Tour',
    'tut.welcome.skip':'Skip Tutorial',
    'tut.next':'Next','tut.prev':'Previous','tut.finish':'Finish',
    'tut.skip':'Skip','tut.stepOf':'of',
    'tut.s1.title':'Your Main Dashboard',
    'tut.s1.body':'This is your control panel. See a summary of your active events, total guests, and pending tasks in real time.',
    'tut.s2.title':'Navigation Menu',
    'tut.s2.body':'Use the sidebar menu to navigate between sections: Events, Guests, Decoration, Staff, Gifts, Resources, QR Codes, and Clients.',
    'tut.s3.title':'Event Management',
    'tut.s3.body':'Create and manage all your events here. Add date, location, event type, dress code, and associated client.',
    'tut.s4.title':'Guests & Tables',
    'tut.s4.body':'Add guests, assign them to tables, and use the Floor Plan to visualize the arrangement with drag & drop.',
    'tut.s5.title':'Access QR Codes',
    'tut.s5.body':'Generate unique QR codes for each guest. Makes check-in easy on event day — just scan the code at the entrance.',
    'tut.s6.title':'Settings & Language',
    'tut.s6.body':'In Settings (last item in the menu) change the language between Portuguese and English, and restart this tutorial whenever you want.',

    /* ── Tooltips ── */
    'tip.rsvp':'RSVP (Répondez s\'il vous plaît) — Guest attendance confirmation for the event.',
    'tip.qrcode':'QR Code — Unique code that allows quick guest check-in at the event entrance.',
    'tip.checkin':'Check-in — Registration and confirmation of a guest\'s presence at the event entrance.',
    'tip.dresscode':'Dress Code — Suggested attire for event guests.',
    'tip.staff':'Staff — Team of professionals who work in the organization and execution of the event.',
    'tip.dashboard':'Dashboard — Central control panel with a summary of all activities.',
    'tip.floorPlan':'Floor Plan — Visual view of the table arrangement in the event space.',
    'tip.catering':'Catering — Food and beverage service provided at the event.',

    /* ── Lang switcher ── */
    'lang.choose':'Language / Idioma',
    'lang.pt':'Português (PT)','lang.en':'English (US)',
    'lang.ptDesc':'European Portuguese','lang.enDesc':'American English',

    /* ── Settings keys ── */
    'settings.subtitle':'Customization and preferences',
    'settings.langTitle':'Language','settings.langSubtitle':'Choose the interface language',
    'settings.tutTitle':'Tutorial',
    'settings.tutSubtitle':'Relaunch the platform introduction tutorial',
    'btn.restartTutorial':'Restart Tutorial',
    'btn.genQR':'Generate QR Code','btn.save':'Save','btn.createClient':'Create Contractor',

    /* ── Nav aliases ── */
    'nav.decoracao':'Decoration','nav.recursos':'Event Resources',
    'nav.tarefas':'Tasks','nav.staff':'Staff & Tasks',
    'nav.clientes':'Contractors','nav.perfil':'Profile','nav.presentes':'Gift List',
    'nav.fornecedores':'Suppliers',

    /* ── Section subtitles ── */
    'decor.subtitle':'Flowers, centerpieces, lighting and more',
    'clientes.subtitle':'Manage contractors and their events',
    'recursos.subtitle':'Equipment, materials and logistics',
    'fornecedores.subtitle':'Manage suppliers for your events',
    'perfil.subtitle':'Update your personal information',
    'perfil.avatarAuto':'Automatically generated avatar',
    'staff.teamTitle':'Team Members','qr.titleSuffix':'Access',
    'evento.contratante':'Contractor',

    /* ── Select option aliases ── */
    'select.event':'Select event...','select.pick':'Select...',
    'select.noClient':'No contractor','select.noTable':'No table',
    'select.noFornecedor':'No supplier',
    'select.staff':'Select staff...','filter.allEvents':'All events',

    /* ── Event type aliases ── */
    'evtype.casamento':'💒 Wedding','evtype.babyShower':'🍼 Baby Shower',
    'evtype.aniversario':'🎂 Birthday','evtype.batizado':'⛪ Christening',
    'evtype.jantarEmpresa':'🏢 Company Dinner','evtype.conferencia':'📊 Conference',
    'evtype.outro':'✨ Other',

    /* ── RSVP / status aliases ── */
    'rsvp.pendente':'Pending','rsvp.confirmado':'Confirmed','rsvp.recusado':'Declined',
    'priority.media':'Medium','priority.alta':'High','priority.baixa':'Low',
    'task.pendente':'Pending','task.emAndamento':'In Progress','task.concluida':'Completed',
    'gift.reservado':'Reserved',
    'delivery.entregue':'Delivered','delivery.cancelado':'Cancelled','delivery.atrasado':'Delayed',

    /* ── Shape aliases ── */
    'shape.round2':'Round','shape.rectangle':'⬜ Rectangular','shape.rectangle2':'Rectangular',

    /* ── Category aliases ── */
    'giftcat.eletro':'Appliances','giftcat.viagem':'Travel','giftcat.dinheiro':'Money',
    'rescat.mobiliario':'Furniture','rescat.audiovisual':'Audiovisual',
    'rescat.catering':'Catering','rescat.transporte':'Transport',
    'decor.themeGeneral':'General',

    /* ── QR aliases ── */
    'qr.guest':'Guest *','qr.selectEventFirst':'Select the event first',

    /* ── Mesa panel aliases ── */
    'msp.editTable':'Edit Table','msp.saveHint':'Click Save to confirm',
    'msp.seats':'Seats','msp.tablecloth':'Tablecloth Color',
    'msp.namePH':"Ex: Bride & Groom's Table",'msp.deleteTable':'Delete table',
    'size.medium':'Medium','size.s':'S','size.m':'M','size.l':'L',

    /* ── Modal label aliases ── */
    'modal.eventName':'Event Name *','modal.eventNamePH':'Ex: Wedding John & Mary',
    'modal.time':'Time *','modal.eventType':'Event Type',
    'modal.locationPH':'Ex: Grand Ballroom, New York',
    'modal.description':'Description','modal.descriptionPH':'Event description...',
    'modal.location':'Location','modal.fullName':'Full name',
    'modal.rsvpStatus':'RSVP Status','modal.tableName':'Table Name',
    "modal.tableNamePH":"Ex: Best Man's Table, Bride's Family...",
    'modal.tableNum':'Number *','modal.capacityPH':'No. of people',
    'modal.locationPH2':'Ex: Garden, Main Hall',
    'modal.taskDescPH':'Describe the task...',
    'modal.staffResponsible':'Responsible Staff',
    'modal.itemNamePH':'Ex: Dinnerware Set',
    'modal.resourceName':'Resource Name *',
    'modal.resourceNamePH':'Ex: Chairs, Projector...',
    'modal.totalQty':'Total Quantity','modal.usedQty':'Used Quantity',
    'modal.supplierPH':'Supplier name','modal.supplierPH2':'Ex: Flowers & Art',
    'modal.decorType':'Type / Description *',
    'modal.decorTypePH':'Ex: Floral arrangement, Centerpiece, Lighting...',
    'modal.quantity':'Quantity','modal.unitPrice':'Unit Price (€)',
    'modal.notes':'Notes','modal.notesPH':'Additional details...',
    'modal.clientNamePH':'Contractor name',
    'modal.autoPassword':'Leave blank to auto-generate',
    'modal.clientNote':"The contractor will receive access to the client portal to manage guests and gifts for their event.",
    'modal.staffNote':'If you leave the password blank, a random one will be generated and shown after creation.',

    /* ── Table header aliases ── */
    'th.deadline':'Conf. Deadline','th.linkedEvent':'Associated Event',

    /* ── Floor plan text splits ── */
    'floor.clickEdit':'Click a table to edit','floor.dragRepos':'Drag to reposition',
  }
};

/* ── Engine ──────────────────────────────────────────────── */

function t(key, fallback) {
  const lang = localStorage.getItem('eh_lang') || 'pt';
  const dict = LANG_TRANSLATIONS[lang];
  if (dict && dict[key] !== undefined) return dict[key];
  if (LANG_TRANSLATIONS.pt[key] !== undefined) return LANG_TRANSLATIONS.pt[key];
  return fallback !== undefined ? fallback : key;
}

function getLang() {
  return localStorage.getItem('eh_lang') || 'pt';
}

function setLang(lang) {
  if (lang !== 'pt' && lang !== 'en') return;
  localStorage.setItem('eh_lang', lang);
  document.documentElement.lang = lang === 'pt' ? 'pt-PT' : 'en-US';
  applyTranslations();
  _updateLangBtns();
  /* Re-render dynamic dashboard content if available */
  if (typeof reloadAllDashboard === 'function') reloadAllDashboard();
}

function applyTranslations() {
  /* textContent */
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const v = t(el.getAttribute('data-i18n'));
    if (v) el.textContent = v;
  });
  /* innerHTML (for bold/HTML in translations) */
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    const v = t(el.getAttribute('data-i18n-html'));
    if (v) el.innerHTML = v;
  });
  /* placeholder */
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    const v = t(el.getAttribute('data-i18n-ph'));
    if (v) el.placeholder = v;
  });
  /* aria-label */
  document.querySelectorAll('[data-i18n-aria]').forEach(el => {
    const v = t(el.getAttribute('data-i18n-aria'));
    if (v) el.setAttribute('aria-label', v);
  });
  /* title attribute (native tooltip) */
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const v = t(el.getAttribute('data-i18n-title'));
    if (v) el.title = v;
  });
  /* term tooltips — update data-tooltip from translation */
  document.querySelectorAll('[data-term]').forEach(el => {
    const tip = t('tip.' + el.getAttribute('data-term'));
    if (tip) el.setAttribute('data-tooltip', tip);
  });
}

function _updateLangBtns() {
  const lang = getLang();
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
  });
}

/* Run on every page load */
document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.lang = getLang() === 'pt' ? 'pt-PT' : 'en-US';
  applyTranslations();
  _updateLangBtns();
});
