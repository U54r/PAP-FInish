<?php
/*
 * ══════════════════════════════════════════════════════════════════
 *  FASE 4 — ADIÇÕES AO dashboard.php
 *  Copie cada bloco para o sítio indicado no dashboard.php existente
 * ══════════════════════════════════════════════════════════════════
 */
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado.');
}
?>


<!-- ─────────────────────────────────────────────────────────────────
     1. BOTÃO NOS CARDS DE EVENTO
     Adicione este botão dentro da função carregarEventosGrid(),
     junto aos botões de editar/eliminar existentes.
     ───────────────────────────────────────────────────────────────── -->

<!--
<button
    class="btn-icon"
    title="Personalizar Página do Convidado"
    onclick="abrirConfigGuestPage(${e.id_evento})"
>
    <i class="ph ph-paint-brush"></i>
</button>
-->


<!-- ─────────────────────────────────────────────────────────────────
     2. MODAL HTML
     Cole este bloco no final do <body> do dashboard.php,
     antes do </body>.
     ───────────────────────────────────────────────────────────────── -->

<div class="modal-overlay" id="modal-guest-page">
    <div class="modal" style="max-width:820px;width:95%;">

        <div class="modal-header">
            <h3><i class="ph ph-paint-brush"></i> Personalizar Página do Convidado</h3>
            <button class="modal-close" onclick="fecharModal('modal-guest-page')">
                <i class="ph ph-x"></i>
            </button>
        </div>

        <form id="form-guest-page" onsubmit="salvarGuestPageSettings(event)">
            <input type="hidden" id="gp-evento-id">

            <div class="modal-body">

                <!-- ── APARÊNCIA ── -->
                <h4 class="modal-section-title">
                    <i class="ph ph-swatches"></i> Aparência
                </h4>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Layout</label>
                        <select id="gp-layout">
                            <option value="classic">🏛 Clássico</option>
                            <option value="modern">⬛ Moderno</option>
                            <option value="elegant">✨ Elegante</option>
                            <option value="rustic">🌿 Rústico</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Cor de fundo</label>
                        <div style="display:flex;gap:.5rem;align-items:center;">
                            <input type="color" id="gp-bg-color" style="width:48px;height:38px;padding:2px;cursor:pointer;border-radius:6px;">
                            <input type="text"  id="gp-bg-color-hex" maxlength="7" placeholder="#faf7f2" style="flex:1;" oninput="syncColorHex('gp-bg-color','gp-bg-color-hex')">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Cor primária (botões, destaques)</label>
                        <div style="display:flex;gap:.5rem;align-items:center;">
                            <input type="color" id="gp-primary-color" style="width:48px;height:38px;padding:2px;cursor:pointer;border-radius:6px;">
                            <input type="text"  id="gp-primary-color-hex" maxlength="7" placeholder="#c9a96e" style="flex:1;" oninput="syncColorHex('gp-primary-color','gp-primary-color-hex')">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Cor do texto</label>
                        <div style="display:flex;gap:.5rem;align-items:center;">
                            <input type="color" id="gp-text-color" style="width:48px;height:38px;padding:2px;cursor:pointer;border-radius:6px;">
                            <input type="text"  id="gp-text-color-hex" maxlength="7" placeholder="#2c2416" style="flex:1;" oninput="syncColorHex('gp-text-color','gp-text-color-hex')">
                        </div>
                    </div>
                </div>

                <hr class="modal-divider">

                <!-- ── DRESS CODE ── -->
                <h4 class="modal-section-title">
                    <i class="ph ph-coat-hanger"></i> Dress Code
                </h4>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Título do Dress Code</label>
                        <input id="gp-dresscode-title" placeholder="Ex: Formal, Black Tie, Casual Elegante">
                    </div>
                    <div class="form-group full">
                        <label>O que sugerir</label>
                        <textarea id="gp-dresscode-suggested" rows="3" placeholder="Fato azul, vestido midi, sapatos clássicos..."></textarea>
                    </div>
                    <div class="form-group full">
                        <label>O que evitar</label>
                        <textarea id="gp-dresscode-avoid" rows="3" placeholder="Jeans, ténis, branco (reservado para a noiva)..."></textarea>
                    </div>
                    <div class="form-group full">
                        <label>Paleta de cores sugerida</label>
                        <textarea id="gp-dresscode-palette" rows="2" placeholder="Azul marinho, verde esmeralda, vinho, dourado..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Imagem de inspiração 1 <small>(URL)</small></label>
                        <input id="gp-dresscode-img1" type="url" placeholder="https://...">
                    </div>
                    <div class="form-group">
                        <label>Imagem de inspiração 2 <small>(URL)</small></label>
                        <input id="gp-dresscode-img2" type="url" placeholder="https://...">
                    </div>
                    <div class="form-group">
                        <label>Imagem de inspiração 3 <small>(URL)</small></label>
                        <input id="gp-dresscode-img3" type="url" placeholder="https://...">
                    </div>
                </div>

                <hr class="modal-divider">

                <!-- ── LOCALIZAÇÃO ── -->
                <h4 class="modal-section-title">
                    <i class="ph ph-map-pin"></i> Localização &amp; Horários
                </h4>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label>Nome do espaço</label>
                        <input id="gp-location-name" placeholder="Ex: Quinta das Flores">
                    </div>
                    <div class="form-group">
                        <label>Hora da cerimónia</label>
                        <input type="time" id="gp-ceremony-time">
                    </div>
                    <div class="form-group full">
                        <label>Morada completa</label>
                        <textarea id="gp-location-address" rows="2" placeholder="Rua, localidade, código postal..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Hora da receção / jantar</label>
                        <input type="time" id="gp-reception-time">
                    </div>
                    <div class="form-group full">
                        <label>URL do mapa embed (Google Maps iframe src)</label>
                        <input id="gp-location-map" type="url" placeholder="https://www.google.com/maps/embed?...">
                        <small style="color:var(--muted,#888);font-size:.78rem;">Google Maps → Partilhar → Incorporar → copie o atributo <em>src</em> do iframe</small>
                    </div>
                    <div class="form-group full">
                        <label>Informação de estacionamento</label>
                        <textarea id="gp-location-parking" rows="2" placeholder="Estacionamento gratuito no local, parque de estacionamento a 200m..."></textarea>
                    </div>
                </div>

                <!-- ── PREVIEW LINK ── -->
                <div id="gp-preview-bar" style="display:none;margin-top:1.5rem;padding:1rem;background:var(--bg-2,#f5f5f5);border-radius:.5rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
                    <span style="font-size:.88rem;color:var(--muted,#666);">
                        <i class="ph ph-eye"></i> Pré-visualizar como convidado:
                    </span>
                    <a id="gp-preview-link" href="#" target="_blank" class="btn-primary-sm" style="text-decoration:none;">
                        <i class="ph ph-arrow-square-out"></i> Abrir guest.php
                    </a>
                </div>

            </div><!-- /modal-body -->

            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-guest-page')">Cancelar</button>
                <button type="submit" class="btn-primary-sm">
                    <i class="ph ph-floppy-disk"></i> Guardar
                </button>
            </div>
        </form>
    </div>
</div>


<!-- ─────────────────────────────────────────────────────────────────
     3. JAVASCRIPT
     Cole este bloco no ficheiro JS do dashboard (ou no <script>
     existente no dashboard.php).
     ───────────────────────────────────────────────────────────────── -->
<script>
/* ── Sincroniza o color picker com o campo de texto hex ── */
function syncColorHex(pickerId, hexId) {
    const hex = document.getElementById(hexId).value;
    if (/^#[0-9a-fA-F]{6}$/.test(hex)) {
        document.getElementById(pickerId).value = hex;
    }
}

function syncPickerToHex(pickerId, hexId) {
    document.getElementById(hexId).value = document.getElementById(pickerId).value;
}

/* ── Abre o modal e carrega as definições atuais ── */
async function abrirConfigGuestPage(idEvento) {
    const r = await API.get(`api/guest_page_settings.php?id_evento=${idEvento}`);
    if (r.status !== 'ok') {
        toast('❌ Erro ao carregar configurações', 'error');
        return;
    }
    const s = r.data;

    document.getElementById('gp-evento-id').value = idEvento;

    // Aparência
    document.getElementById('gp-layout').value           = s.layout_template  || 'classic';
    document.getElementById('gp-bg-color').value         = s.bg_color          || '#faf7f2';
    document.getElementById('gp-bg-color-hex').value     = s.bg_color          || '#faf7f2';
    document.getElementById('gp-primary-color').value    = s.primary_color     || '#c9a96e';
    document.getElementById('gp-primary-color-hex').value= s.primary_color     || '#c9a96e';
    document.getElementById('gp-text-color').value       = s.text_color        || '#2c2416';
    document.getElementById('gp-text-color-hex').value   = s.text_color        || '#2c2416';

    // Sincronizar pickers → hex (quando muda o picker)
    ['gp-bg-color','gp-primary-color','gp-text-color'].forEach(id => {
        const hexId = id + '-hex';
        const el = document.getElementById(id);
        el.oninput = () => syncPickerToHex(id, hexId);
    });

    // Dress code
    document.getElementById('gp-dresscode-title').value    = s.dresscode_title     || '';
    document.getElementById('gp-dresscode-suggested').value= s.dresscode_suggested || '';
    document.getElementById('gp-dresscode-avoid').value    = s.dresscode_avoid     || '';
    document.getElementById('gp-dresscode-palette').value  = s.dresscode_palette   || '';
    document.getElementById('gp-dresscode-img1').value     = s.dresscode_image1    || '';
    document.getElementById('gp-dresscode-img2').value     = s.dresscode_image2    || '';
    document.getElementById('gp-dresscode-img3').value     = s.dresscode_image3    || '';

    // Localização & horários
    document.getElementById('gp-location-name').value    = s.location_name         || '';
    document.getElementById('gp-location-address').value = s.location_address      || '';
    document.getElementById('gp-location-map').value     = s.location_map_url      || '';
    document.getElementById('gp-location-parking').value = s.location_parking_info || '';
    document.getElementById('gp-ceremony-time').value    = s.ceremony_time         || '';
    document.getElementById('gp-reception-time').value   = s.reception_time        || '';

    // Preview link
    const bar  = document.getElementById('gp-preview-bar');
    const link = document.getElementById('gp-preview-link');
    if (bar && link) {
        bar.style.display = 'flex';
        link.href = `guest.php?id_evento=${idEvento}`;
    }

    abrirModal('modal-guest-page');
}

/* ── Guarda as configurações via PUT ── */
async function salvarGuestPageSettings(e) {
    e.preventDefault();
    const idEvento = document.getElementById('gp-evento-id').value;

    const body = {
        layout_template:      document.getElementById('gp-layout').value,
        bg_color:             document.getElementById('gp-bg-color').value,
        primary_color:        document.getElementById('gp-primary-color').value,
        text_color:           document.getElementById('gp-text-color').value,
        dresscode_title:      document.getElementById('gp-dresscode-title').value,
        dresscode_suggested:  document.getElementById('gp-dresscode-suggested').value,
        dresscode_avoid:      document.getElementById('gp-dresscode-avoid').value,
        dresscode_palette:    document.getElementById('gp-dresscode-palette').value,
        dresscode_image1:     document.getElementById('gp-dresscode-img1').value,
        dresscode_image2:     document.getElementById('gp-dresscode-img2').value,
        dresscode_image3:     document.getElementById('gp-dresscode-img3').value,
        location_name:        document.getElementById('gp-location-name').value,
        location_address:     document.getElementById('gp-location-address').value,
        location_map_url:     document.getElementById('gp-location-map').value,
        location_parking_info:document.getElementById('gp-location-parking').value,
        ceremony_time:        document.getElementById('gp-ceremony-time').value,
        reception_time:       document.getElementById('gp-reception-time').value,
    };

    const r = await API.put(`api/guest_page_settings.php?id_evento=${idEvento}`, body);
    if (r.status === 'ok') {
        toast('✅ Página do convidado atualizada!');
        fecharModal('modal-guest-page');
    } else {
        toast('❌ ' + (r.msg || 'Erro ao guardar'), 'error');
    }
}
</script>


<!-- ─────────────────────────────────────────────────────────────────
     4. CSS EXTRA (adicione no <style> do dashboard.php)
     ───────────────────────────────────────────────────────────────── -->
<style>
.modal-section-title {
    display: flex;
    align-items: center;
    gap: .5rem;
    font-size: .88rem;
    font-weight: 600;
    letter-spacing: .04em;
    text-transform: uppercase;
    color: var(--muted, #666);
    margin: 1.25rem 0 1rem;
}
.modal-section-title:first-child { margin-top: 0; }

.modal-divider {
    border: none;
    border-top: 1px solid var(--border, #e8e8e8);
    margin: 1.75rem 0 .25rem;
}

/* Garante que o campo full ocupa as 2 colunas no form-grid-2 */
.form-grid-2 .form-group.full {
    grid-column: 1 / -1;
}
</style>
