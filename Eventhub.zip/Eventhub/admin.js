/* =========================================================
   admin.js — Lógica do Painel de Administração (admin-dashboard.php)
   Depende de app.js (API, esc, toast, confirmDialog, abrirModal, fecharModal, getVal, setVal)
   ========================================================= */

'use strict';

const roleLabel = r => ({
    administrador: 'Administrador',
    organizador:   'Organizador',
    staff:         'Staff',
    cliente:       'Cliente',
    convidado:     'Convidado',
}[r] || r);

const estadoBadgeAdmin = e => e === 'ativo' ? 'badge-success' : 'badge-danger-soft';

// ── Estatísticas ─────────────────────────────────────────
async function carregarStatsAdmin() {
    const r = await API.get('admin_stats.php');
    if (r.status !== 'ok') return;
    const d = r.data;

    setStat('adm-stat-utilizadores',     d.total_utilizadores);
    setStat('adm-stat-eventos',          d.total_eventos);
    setStat('adm-stat-eventos-proximos', d.eventos_proximos);
    setStat('adm-stat-inativos',         d.contas_inativas);

    const tbody = document.getElementById('adm-stat-roles-tbody');
    if (!tbody) return;
    const roles = d.por_role || [];
    if (!roles.length) {
        tbody.innerHTML = `<tr><td colspan="2" class="td-empty">Sem dados.</td></tr>`;
        return;
    }
    tbody.innerHTML = roles.map(r => `
        <tr><td>${esc(roleLabel(r.nome_role))}</td><td>${r.total}</td></tr>
    `).join('');
}

// ── Utilizadores ─────────────────────────────────────────
let _admUtilizadoresCache = [];

async function carregarUtilizadoresAdmin(roleFiltro = '') {
    const r     = await API.get('admin_utilizadores.php');
    const tbody = document.getElementById('adm-utilizadores-tbody');
    if (!tbody || r.status !== 'ok') return;

    _admUtilizadoresCache = r.data || [];
    const ativo = roleFiltro || document.querySelector('.adm-role-filter-btn.active')?.dataset.role || '';
    const lista = ativo ? _admUtilizadoresCache.filter(u => u.nome_role === ativo) : _admUtilizadoresCache;

    if (!lista.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="td-empty">Sem utilizadores.</td></tr>`;
        return;
    }

    tbody.innerHTML = lista.map(u => `
        <tr>
            <td><strong>${esc(u.nome)}</strong></td>
            <td>${esc(u.email)}</td>
            <td>${esc(u.telefone || '—')}</td>
            <td><span class="badge badge-muted">${esc(roleLabel(u.nome_role))}</span></td>
            <td><span class="badge ${estadoBadgeAdmin(u.estado_conta)}">${esc(u.estado_conta)}</span></td>
            <td>${esc(u.organizador_nome || '—')}</td>
            <td>
                <button class="btn-icon" onclick='abrirEditarUtilizadorAdmin(${JSON.stringify(u).replace(/'/g, "\\'")})' title="Editar"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarUtilizadorAdmin(${u.id_utilizador})" title="Eliminar"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

function abrirNovoUtilizadorAdmin() {
    setVal('adm-id', '');
    setVal('adm-nome', '');
    setVal('adm-email', '');
    setVal('adm-telefone', '');
    setVal('adm-role', 'organizador');
    setVal('adm-estado', 'ativo');
    setVal('adm-password', '');
    document.getElementById('modal-adm-utilizador-titulo').textContent = 'Novo Utilizador';
    abrirModal('modal-adm-utilizador');
}

function abrirEditarUtilizadorAdmin(u) {
    setVal('adm-id', u.id_utilizador);
    setVal('adm-nome', u.nome);
    setVal('adm-email', u.email);
    setVal('adm-telefone', u.telefone || '');
    setVal('adm-role', u.nome_role);
    setVal('adm-estado', u.estado_conta);
    setVal('adm-password', '');
    document.getElementById('modal-adm-utilizador-titulo').textContent = 'Editar Utilizador';
    abrirModal('modal-adm-utilizador');
}

async function salvarUtilizadorAdmin(e) {
    if (e) e.preventDefault();
    const id = getVal('adm-id');
    const body = {
        nome:         getVal('adm-nome'),
        email:        getVal('adm-email'),
        telefone:     getVal('adm-telefone'),
        role:         getVal('adm-role'),
        estado_conta: getVal('adm-estado'),
        password:     getVal('adm-password'),
    };
    if (!body.nome || !body.email) { toast('Nome e email são obrigatórios', 'error'); return; }

    const r = id ? await API.put(`admin_utilizadores.php?id=${id}`, body) : await API.post('admin_utilizadores.php', body);
    if (r?.status === 'ok') {
        toast(r.msg || 'Utilizador guardado');
        if (!id && r.data?.password) {
            await alertDialog('Utilizador criado!\nPassword gerada automaticamente (esta informação não será mostrada novamente):', { copyValue: r.data.password });
        }
        fecharModal('modal-adm-utilizador');
        carregarUtilizadoresAdmin();
        carregarStatsAdmin();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function eliminarUtilizadorAdmin(id) {
    if (!await confirmDialog('Eliminar este utilizador? Esta ação é irreversível e remove também os eventos que ele organiza (se aplicável).')) return;
    const r = await API.delete(`admin_utilizadores.php?id=${id}`);
    if (r?.status === 'ok') {
        toast('Utilizador eliminado');
        carregarUtilizadoresAdmin();
        carregarStatsAdmin();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

// ── Eventos ──────────────────────────────────────────────
async function carregarEventosAdmin() {
    const r     = await API.get('admin_eventos.php');
    const tbody = document.getElementById('adm-eventos-tbody');
    if (!tbody || r.status !== 'ok') return;

    const eventos = r.data || [];
    if (!eventos.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="td-empty">Sem eventos.</td></tr>`;
        return;
    }

    tbody.innerHTML = eventos.map(ev => `
        <tr>
            <td><strong>${esc(ev.nome_evento)}</strong></td>
            <td>${esc(ev.organizador_nome)}</td>
            <td>${formatDateSimple(ev.data)}</td>
            <td>${esc(ev.local || '—')}</td>
            <td>${ev.total_convidados}</td>
            <td>
                <button class="btn-icon delete" onclick="eliminarEventoAdmin(${ev.id_evento})" title="Eliminar"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function eliminarEventoAdmin(id) {
    if (!await confirmDialog('Eliminar este evento? Esta ação remove também convidados, mesas, tarefas e tudo o que está ligado a ele. É irreversível.')) return;
    const r = await API.delete(`admin_eventos.php?id=${id}`);
    if (r?.status === 'ok') {
        toast('Evento eliminado');
        carregarEventosAdmin();
        carregarStatsAdmin();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

// ── Base de Dados ────────────────────────────────────────
async function confirmarAcaoBD(url, mensagem) {
    if (!await confirmDialog(mensagem)) return;
    window.open(url, '_blank');
}
