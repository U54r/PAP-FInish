/* =================================================================
   tutorial.js — EventHub First-time Tutorial / Onboarding
   - Shows a welcome screen on first login (non-guest users only)
   - Walks through 6 dashboard sections
   - Can be restarted from Settings
   - Skippable at any time
   ================================================================= */
'use strict';

(function () {

  const LS_KEY = 'eh_tutorial_seen';

  /* ── Tutorial step definitions ─────────────────────────── */
  const STEPS = [
    { section: 'inicio',     titleKey: 'tut.s1.title', bodyKey: 'tut.s1.body',
      target: '.stats-grid',    pos: 'bottom' },
    { section: 'inicio',     titleKey: 'tut.s2.title', bodyKey: 'tut.s2.body',
      target: '.sidebar-nav',   pos: 'right' },
    { section: 'eventos',    titleKey: 'tut.s3.title', bodyKey: 'tut.s3.body',
      target: '#section-eventos .section-header', pos: 'bottom' },
    { section: 'convidados', titleKey: 'tut.s4.title', bodyKey: 'tut.s4.body',
      target: '#section-convidados .section-header', pos: 'bottom' },
    { section: 'qrcodes',    titleKey: 'tut.s5.title', bodyKey: 'tut.s5.body',
      target: '#section-qrcodes .section-header', pos: 'bottom' },
    { section: 'definicoes', titleKey: 'tut.s6.title', bodyKey: 'tut.s6.body',
      target: '.nav-link[data-section="definicoes"]', pos: 'right' },
  ];

  let currentStep = 0;

  /* ── Build DOM ─────────────────────────────────────────── */
  function buildUI() {
    if (document.getElementById('eh-tutorial-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id = 'eh-tutorial-overlay';
    overlay.innerHTML = `
      <!-- WELCOME SCREEN -->
      <div id="tut-welcome" class="tut-welcome-wrap">
        <div class="tut-welcome-card">
          <div class="tut-welcome-icon">🎉</div>
          <h2 id="tut-w-title"></h2>
          <p id="tut-w-body" class="tut-w-body"></p>
          <div class="tut-welcome-actions">
            <button class="btn-primary-sm tut-btn-start" onclick="window.EHtutorial.start()">
              <span id="tut-w-start"></span>
            </button>
            <button class="tut-btn-skip-welcome" onclick="window.EHtutorial.skip()">
              <span id="tut-w-skip"></span>
            </button>
          </div>
        </div>
      </div>

      <!-- STEP CARD (positioned near target) -->
      <div id="tut-step-card" class="tut-step-card" style="display:none">
        <div class="tut-step-header">
          <span class="tut-step-counter" id="tut-counter"></span>
          <button class="tut-close-btn" onclick="window.EHtutorial.skip()" title="Skip">×</button>
        </div>
        <h3 id="tut-step-title" class="tut-step-title"></h3>
        <p  id="tut-step-body"  class="tut-step-body"></p>
        <div class="tut-step-nav">
          <button id="tut-prev-btn" class="tut-nav-prev" onclick="window.EHtutorial.prev()">
            <i class="ph ph-arrow-left"></i> <span id="tut-prev-lbl"></span>
          </button>
          <button id="tut-next-btn" class="tut-nav-next btn-primary-sm" onclick="window.EHtutorial.next()">
            <span id="tut-next-lbl"></span> <i class="ph ph-arrow-right"></i>
          </button>
        </div>
      </div>

      <!-- HIGHLIGHT RING -->
      <div id="tut-spotlight" class="tut-spotlight" style="display:none"></div>
    `;

    document.body.appendChild(overlay);
  }

  /* ── Show / hide overlay ───────────────────────────────── */
  function showOverlay() {
    const o = document.getElementById('eh-tutorial-overlay');
    if (o) { o.style.display = 'flex'; o.classList.add('active'); }
    document.body.style.overflow = 'hidden';
  }

  function hideOverlay() {
    const o = document.getElementById('eh-tutorial-overlay');
    if (o) { o.style.display = 'none'; o.classList.remove('active'); }
    document.body.style.overflow = '';
    _clearSpotlight();
    _hideStepCard();
  }

  /* ── Welcome screen ────────────────────────────────────── */
  function showWelcome() {
    buildUI();
    _setText('tut-w-title',  t('tut.welcome.title'));
    _setHTML('tut-w-body',   t('tut.welcome.body'));
    _setText('tut-w-start',  t('tut.welcome.start'));
    _setText('tut-w-skip',   t('tut.welcome.skip'));
    document.getElementById('tut-welcome').style.display = 'flex';
    _hideStepCard();
    _clearSpotlight();
    showOverlay();
  }

  /* ── Steps ─────────────────────────────────────────────── */
  function showStep(idx) {
    const step = STEPS[idx];
    if (!step) { finish(); return; }

    /* Navigate to the section */
    if (typeof goToSection === 'function') goToSection(step.section);

    /* Hide welcome, show step card */
    document.getElementById('tut-welcome').style.display = 'none';

    /* Fill step card */
    const total = STEPS.length;
    _setText('tut-counter',    `${idx + 1} ${t('tut.stepOf')} ${total}`);
    _setText('tut-step-title', t(step.titleKey));
    _setText('tut-step-body',  t(step.bodyKey));

    /* Nav buttons */
    const prevBtn  = document.getElementById('tut-prev-btn');
    const nextBtn  = document.getElementById('tut-next-btn');
    const nextLbl  = document.getElementById('tut-next-lbl');
    const prevLbl  = document.getElementById('tut-prev-lbl');

    prevBtn.style.display = idx === 0 ? 'none' : 'flex';
    if (prevLbl) prevLbl.textContent = t('tut.prev');
    if (nextLbl) nextLbl.textContent = idx === total - 1 ? t('tut.finish') : t('tut.next');

    document.getElementById('tut-step-card').style.display = 'flex';
    showOverlay();

    /* Position card & spotlight after nav renders */
    setTimeout(() => {
      _positionStepCard(step);
      _spotlightTarget(step.target);
    }, 120);
  }

  function _positionStepCard(step) {
    const card   = document.getElementById('tut-step-card');
    const target = document.querySelector(step.target);
    if (!card) return;

    if (!target) {
      /* Centre card if target not found */
      card.style.cssText += 'top:50%;left:50%;transform:translate(-50%,-50%)';
      return;
    }

    const tr   = target.getBoundingClientRect();
    const cW   = card.offsetWidth  || 320;
    const cH   = card.offsetHeight || 200;
    const vW   = window.innerWidth;
    const vH   = window.innerHeight;
    const GAP  = 18;

    let top, left;

    if (step.pos === 'right') {
      top  = tr.top + tr.height / 2 - cH / 2;
      left = tr.right + GAP;
      if (left + cW > vW - 12) { left = tr.left - cW - GAP; }
    } else { /* bottom */
      top  = tr.bottom + GAP;
      left = tr.left + tr.width / 2 - cW / 2;
      if (top + cH > vH - 12) { top = tr.top - cH - GAP; }
    }

    top  = Math.max(12, Math.min(top,  vH - cH - 12));
    left = Math.max(12, Math.min(left, vW - cW - 12));

    card.style.position = 'fixed';
    card.style.top      = top  + 'px';
    card.style.left     = left + 'px';
    card.style.transform = 'none';
  }

  function _spotlightTarget(selector) {
    const ring = document.getElementById('tut-spotlight');
    if (!ring) return;
    const target = document.querySelector(selector);
    if (!target) { ring.style.display = 'none'; return; }

    const r   = target.getBoundingClientRect();
    const pad = 8;
    ring.style.display = 'block';
    ring.style.top     = (r.top    - pad) + 'px';
    ring.style.left    = (r.left   - pad) + 'px';
    ring.style.width   = (r.width  + pad * 2) + 'px';
    ring.style.height  = (r.height + pad * 2) + 'px';
  }

  function _clearSpotlight() {
    const ring = document.getElementById('tut-spotlight');
    if (ring) ring.style.display = 'none';
  }

  function _hideStepCard() {
    const card = document.getElementById('tut-step-card');
    if (card) card.style.display = 'none';
  }

  /* ── API ────────────────────────────────────────────────── */
  function start() {
    currentStep = 0;
    showStep(0);
  }

  function next() {
    currentStep++;
    if (currentStep >= STEPS.length) { finish(); }
    else { showStep(currentStep); }
  }

  function prev() {
    if (currentStep > 0) { currentStep--; showStep(currentStep); }
  }

  function skip() {
    localStorage.setItem(LS_KEY, '1');
    hideOverlay();
  }

  function finish() {
    localStorage.setItem(LS_KEY, '1');
    hideOverlay();
    toast(getLang() === 'en' ? '✅ Tutorial complete!' : '✅ Tutorial concluído!');
    /* Go back to home */
    if (typeof goToSection === 'function') goToSection('inicio');
  }

  function restart() {
    localStorage.removeItem(LS_KEY);
    currentStep = 0;
    showWelcome();
  }

  /* ── Auto-trigger on first visit ───────────────────────── */
  document.addEventListener('DOMContentLoaded', () => {
    buildUI();
    if (!localStorage.getItem(LS_KEY)) {
      /* Slight delay so the dashboard finishes loading */
      setTimeout(showWelcome, 800);
    }
  });

  /* ── Helpers ────────────────────────────────────────────── */
  function _setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }
  function _setHTML(id, val) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = val;
  }

  /* ── Export ─────────────────────────────────────────────── */
  window.EHtutorial = { start, next, prev, skip, finish, restart, showWelcome };

})();
