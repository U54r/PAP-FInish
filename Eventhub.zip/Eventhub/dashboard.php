<?php
require_once __DIR__ . '/auth.php';
requireRole(['organizador']);
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Organizador — EventHub</title>
    <meta name="description" content="Painel de gestão de eventos — Event Hub.">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%230d9488'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' fill='white' font-size='18' font-weight='700' font-family='sans-serif'%3EEH%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <script src="lang.js"></script>
    <style>
        .notif-wrapper { position:relative; }
        #notif-panel {
            display:none; position:absolute; top:52px; right:0; width:380px;
            background:var(--white); border:1px solid var(--border-color);
            border-radius:16px; box-shadow:0 20px 60px rgba(0,0,0,0.12); z-index:500;
            overflow:hidden;
        }
        #notif-panel.open { display:block; }
        .notif-panel-header { display:flex; justify-content:space-between; align-items:center; padding:16px 20px; border-bottom:1px solid var(--border-color); }
        .notif-panel-header h4 { font-size:15px; font-weight:700; }
        .notif-panel-header button { font-size:12px; color:var(--primary); background:none; border:none; cursor:pointer; font-weight:600; }
        #notif-lista { max-height: 360px; overflow-y: auto; }
        .notif-item { display:flex; gap:12px; align-items:flex-start; padding:14px 20px; border-bottom:1px solid var(--border-color); transition:background .15s; }
        .notif-item:hover { background:var(--bg-light); }
        .notif-icon-wrap { font-size:20px; flex-shrink:0; margin-top:2px; }
        .notif-msg { font-size:13px; color:var(--text-dark); font-weight:500; line-height:1.4; }
        .notif-meta { font-size:11px; color:var(--text-muted); margin-top:3px; }
        .notif-dismiss { margin-left:auto; background:none; border:none; cursor:pointer; color:var(--text-muted); font-size:16px; flex-shrink:0; padding:2px; }
        .notif-empty { text-align:center; padding:32px; color:var(--text-muted); font-size:14px; }
        #notif-badge {
            position:absolute; top:-4px; right:-4px; background:#ef4444; color:white;
            font-size:10px; font-weight:800; border-radius:50%; width:18px; height:18px;
            display:flex; align-items:center; justify-content:center; border:2px solid white;
        }
        .perfil-avatar-wrap { text-align:center; margin-bottom:20px; }
        .perfil-avatar-wrap img { width:80px; height:80px; border-radius:50%; border:3px solid var(--primary); }
        .perfil-avatar-wrap p { font-size:13px; color:var(--text-muted); margin-top:8px; }
        .alert { padding:12px 16px; border-radius:10px; font-size:14px; margin-bottom:16px; display:flex; align-items:center; gap:8px; }
        .alert-error   { background:#fee2e2; color:#dc2626; }
        .alert-success { background:#dcfce7; color:#16a34a; }
        .td-empty { text-align:center; color:var(--text-muted); padding:24px; font-size:14px; }
        .empty-state { text-align:center; padding:48px; color:var(--text-muted); }
        .empty-state i { font-size:48px; display:block; margin-bottom:12px; }
        .modal-section-title {
            display:flex; align-items:center; gap:.5rem;
            font-size:.85rem; font-weight:600; letter-spacing:.04em;
            text-transform:uppercase; color:#64748b; margin:1.25rem 0 .75rem;
        }
        .modal-section-title:first-child { margin-top:0; }
        .modal-divider { border:none; border-top:1px solid #e2e8f0; margin:1.5rem 0 .25rem; }
        .form-grid-2 .form-group.full { grid-column:1/-1; }
    </style>
</head>
<body class="dashboard-body">
<div class="dashboard-container">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-logo">
                <i class="ph-fill ph-calendar-check"></i><span>Event Hub</span>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-link active" data-section="inicio"><i class="ph ph-house"></i> <span data-i18n="dash.inicio">Início</span></a>
                <a href="#" class="nav-link" data-section="eventos"><i class="ph ph-calendar-plus"></i> <span data-i18n="dash.eventos">Meus Eventos</span></a>
                <a href="#" class="nav-link" data-section="convidados"><i class="ph ph-users-three"></i> <span data-i18n="dash.convidados">Convidados & Mesas</span></a>
                <a href="#" class="nav-link" data-section="decoracao"><i class="ph ph-flower"></i> <span data-i18n="dash.decoracao">Decoração</span></a>
                <a href="#" class="nav-link" data-section="fornecedores"><i class="ph ph-buildings"></i> <span data-i18n="nav.fornecedores">Fornecedores</span></a>
                <a href="#" class="nav-link" data-section="staff"><i class="ph ph-clipboard-text"></i> <span data-i18n="dash.staff">Staff & Tarefas</span></a>
                <a href="#" class="nav-link" data-section="presentes"><i class="ph ph-gift"></i> <span data-i18n="dash.presentes">Lista de Presentes</span></a>
                <a href="#" class="nav-link" data-section="recursos"><i class="ph ph-package"></i> <span data-i18n="dash.recursos">Recursos do Evento</span></a>
                <a href="#" class="nav-link" data-section="qrcodes"><i class="ph ph-qr-code"></i> <span data-i18n="dash.qrcodes">QR Codes de Acesso</span></a>
                <a href="#" class="nav-link" data-section="clientes"><i class="ph ph-user-list"></i> <span data-i18n="dash.clientes">Contratantes</span></a>
                <a href="#" class="nav-link" data-section="perfil"><i class="ph ph-user-circle"></i> <span data-i18n="dash.perfil">Perfil</span></a>
                <a href="#" class="nav-link" data-section="definicoes"><i class="ph ph-gear-six"></i> <span data-i18n="dash.definicoes">Definições</span></a>
            </nav>
        </div>
        <div class="sidebar-footer">
            <a href="#" class="sidebar-user" onclick="goToSection('perfil'); return false;">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>"
                     alt="Avatar" class="sidebar-avatar">
                <div class="sidebar-user-info">
                    <span class="sidebar-user-name"><?= htmlspecialchars($user['nome']) ?></span>
                    <span class="sidebar-user-role" data-i18n="dash.role.organizer">Organizador</span>
                </div>
                <i class="ph ph-gear sidebar-user-gear"></i>
            </a>
            <a href="logout.php" class="logout-link"><i class="ph ph-sign-out"></i> <span data-i18n="dash.logout">Sair</span></a>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <header class="dashboard-header">
            <div class="welcome" id="page-title">
                <h1>Olá, <?= htmlspecialchars($user['nome']) ?>! 👋</h1>
                <p>Aqui está o resumo dos teus eventos.</p>
            </div>
            <div class="header-actions">
                <div class="search-bar">
                    <i class="ph ph-magnifying-glass"></i>
                    <input type="text" data-i18n-ph="dash.search" placeholder="Pesquisar..." id="search-input">
                </div>
                <div class="profile-section">
                    <!-- Language switcher in header -->
                    <div class="lang-switcher header-lang-wrap" role="group">
                        <button class="lang-btn active" data-lang="pt" onclick="setLang('pt')">🇵🇹 PT</button>
                        <button class="lang-btn" data-lang="en" onclick="setLang('en')">🇺🇸 EN</button>
                    </div>
                    <div class="notif-wrapper">
                        <div class="notif-icon" onclick="toggleNotifPanel()" style="cursor:pointer">
                            <i class="ph ph-bell"></i>
                            <span id="notif-badge" style="display:none">0</span>
                        </div>
                        <div id="notif-panel">
                            <div class="notif-panel-header">
                                <h4 data-i18n="notif.title">Notificações</h4>
                                <button onclick="limparTodasNotifs()" data-i18n="notif.clearAll">Limpar todas</button>
                            </div>
                            <div id="notif-lista"></div>
                        </div>
                    </div>
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>"
                         alt="Avatar" class="avatar" id="header-avatar"
                         onclick="goToSection('perfil')" style="cursor:pointer">
                </div>
            </div>
        </header>

        <!-- INÍCIO -->
        <div id="section-inicio" class="page-section active">
            <section class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="ph ph-calendar-star"></i></div>
                    <div class="stat-info"><h3 id="stat-eventos">—</h3><p data-i18n="stat.eventos">Eventos Ativos</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green"><i class="ph ph-users"></i></div>
                    <div class="stat-info"><h3 id="stat-convidados">—</h3><p data-i18n="stat.convidados">Total de Convidados</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon orange"><i class="ph ph-list-checks"></i></div>
                    <div class="stat-info"><h3 id="stat-tarefas">—</h3><p data-i18n="stat.tarefas">Tarefas Pendentes</p></div>
                </div>
            </section>
            <section class="content-section">
                <div class="section-header">
                    <h2 data-i18n="inicio.nextEvents">Próximos Eventos</h2>
                    <button class="btn-primary-sm" onclick="goToSection('eventos')" data-i18n="inicio.viewAll">Ver todos</button>
                </div>
                <div class="table-wrapper scroll-area">
                    <table>
                        <thead><tr><th data-i18n="th.event">Evento</th><th data-i18n="th.date">Data</th><th data-i18n="th.location">Local</th><th data-i18n="th.status">Estado</th><th data-i18n="th.actions">Ações</th></tr></thead>
                        <tbody id="inicio-eventos-tbody"><tr><td colspan="5" class="td-empty">A carregar...</td></tr></tbody>
                    </table>
                </div>
            </section>
            <section class="content-section">
                <div class="section-header"><h2 data-i18n="inicio.pendingTasks">Tarefas de Staff Pendentes</h2></div>
                <div class="tasks-list scroll-area" id="inicio-tarefas-list"><p class="td-empty">A carregar...</p></div>
            </section>
        </div>

        <!-- EVENTOS -->
        <div id="section-eventos" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title" data-i18n="section.eventos.title">Meus Eventos</h2><p class="section-subtitle" data-i18n="section.eventos.sub">Gerencie todos os seus eventos</p></div>
                <button class="btn-primary-sm" onclick="abrirModal('modal-evento')"><i class="ph ph-plus"></i> <span data-i18n="btn.newEvent">Novo Evento</span></button>
            </div>
            <div class="filter-bar">
                <button class="filter-btn active" data-filter="all" data-i18n="filter.all">Todos</button>
                <button class="filter-btn" data-filter="ativo" data-i18n="filter.active">Ativos</button>
                <button class="filter-btn" data-filter="inativo" data-i18n="filter.past">Passados</button>
            </div>
            <div class="events-grid scroll-area" id="events-grid"><div class="empty-state"><i class="ph ph-spinner-gap"></i><p>A carregar...</p></div></div>
        </div>

        <!-- CONVIDADOS & MESAS -->
        <div id="section-convidados" class="page-section">
            <div class="section-header mb-24"><div><h2 class="section-title" data-i18n="section.convidados.title">Convidados & Mesas</h2></div></div>
            <div class="sub-tabs">
                <button class="sub-tab active" data-tab="tab-convidados"><i class="ph ph-users"></i> <span data-i18n="tab.guests">Convidados</span></button>
                <button class="sub-tab" data-tab="tab-mesas"><i class="ph ph-table"></i> <span data-i18n="tab.tables">Lista de Mesas</span></button>
                <button class="sub-tab" data-tab="tab-planta" onclick="carregarPlanta()"><i class="ph ph-layout"></i> <span data-i18n="tab.floor">Planta da Sala</span></button>
            </div>

            <!-- Convidados -->
            <div id="tab-convidados" class="tab-content active">
                <div class="content-section">
                    <div class="section-header">
                        <h2 data-i18n="tab.guests">Lista de Convidados</h2>
                        <button class="btn-primary-sm" onclick="abrirModal('modal-convidado');document.getElementById('cv-id').value='';document.getElementById('modal-convidado-titulo').textContent=t('modal.addGuest');"><i class="ph ph-plus"></i> <span data-i18n="btn.addGuest">Adicionar</span></button>
                    </div>
                    <div class="table-wrapper scroll-area"><table><thead><tr><th data-i18n="th.name">Nome</th><th data-i18n="th.event">Evento</th><th data-i18n="th.table">Mesa</th><th><span class="term-explain" data-term="rsvp" data-tooltip="">RSVP</span></th><th><span class="term-explain" data-term="qrcode" data-tooltip="">QR Code</span></th><th data-i18n="th.actions">Ações</th></tr></thead><tbody id="convidados-tbody"><tr><td colspan="6" class="td-empty">A carregar...</td></tr></tbody></table></div>
                </div>
            </div>

            <!-- Lista de Mesas -->
            <div id="tab-mesas" class="tab-content">
                <div class="content-section">
                    <div class="section-header">
                        <h2 data-i18n="tab.tables">Lista de Mesas</h2>
                        <button class="btn-primary-sm" onclick="abrirModal('modal-mesa')"><i class="ph ph-plus"></i> <span data-i18n="btn.addTable">Adicionar Mesa</span></button>
                    </div>
                    <div class="table-wrapper scroll-area"><table><thead><tr><th data-i18n="th.table">Mesa</th><th data-i18n="th.name">Nome</th><th data-i18n="th.event">Evento</th><th data-i18n="th.capacity">Capacidade</th><th data-i18n="th.shape">Forma</th><th data-i18n="th.actions">Ações</th></tr></thead><tbody id="mesas-tbody"><tr><td colspan="6" class="td-empty">A carregar...</td></tr></tbody></table></div>
                </div>
            </div>

            <!-- Planta Visual -->
            <div id="tab-planta" class="tab-content">
                <div class="content-section">
                    <div class="section-header">
                        <h2 data-i18n="tab.floor">Planta da Sala</h2>
                        <div style="display:flex;gap:10px;align-items:center">
                            <select id="planta-evento-select" class="select-evento" style="padding:8px 12px;border:1px solid var(--border-color);border-radius:10px;font-size:14px;outline:none;" onchange="carregarPlanta()">
                                <option value="" data-i18n="select.event">Selecionar evento...</option>
                            </select>
                            <button class="btn-primary-sm" onclick="abrirModal('modal-mesa')"><i class="ph ph-plus"></i> <span data-i18n="btn.newTable">Nova Mesa</span></button>
                        </div>
                    </div>
                    <!-- Canvas theme picker -->
                    <div class="planta-tema-bar">
                        <span class="planta-tema-label" data-i18n="floor.theme">Tema</span>
                        <button class="planta-tema-btn active" data-tema=""        onclick="setPlantaTema(this,'')"       title="Padrão" ><span style="background:linear-gradient(135deg,#e2e8f0,#f1f5f9)"></span></button>
                        <button class="planta-tema-btn"        data-tema="rosa"    onclick="setPlantaTema(this,'rosa')"   title="Rosa"   ><span style="background:linear-gradient(135deg,#fce7f3,#fbcfe8)"></span></button>
                        <button class="planta-tema-btn"        data-tema="sage"    onclick="setPlantaTema(this,'sage')"   title="Sage"   ><span style="background:linear-gradient(135deg,#dcfce7,#bbf7d0)"></span></button>
                        <button class="planta-tema-btn"        data-tema="marfim"  onclick="setPlantaTema(this,'marfim')" title="Marfim" ><span style="background:linear-gradient(135deg,#fef9c3,#fef08a)"></span></button>
                        <button class="planta-tema-btn"        data-tema="azul"    onclick="setPlantaTema(this,'azul')"   title="Azul"   ><span style="background:linear-gradient(135deg,#dbeafe,#bfdbfe)"></span></button>
                        <button class="planta-tema-btn"        data-tema="lavanda" onclick="setPlantaTema(this,'lavanda')" title="Lavanda"><span style="background:linear-gradient(135deg,#ede9fe,#ddd6fe)"></span></button>
                    </div>
                    <div class="planta-canvas" id="planta-canvas">
                        <div class="planta-empty" id="planta-empty">
                            <i class="ph ph-layout"></i>
                            <p data-i18n="floor.empty">Selecione um evento para ver a planta da sala</p>
                        </div>
                    </div>
                    <div class="planta-legend">
                        <span style="font-size:11px;color:var(--text-muted)"><i class="ph ph-cursor-click" style="margin-right:4px"></i><span data-i18n="floor.clickEdit">Clique numa mesa para editar</span> &nbsp;·&nbsp; <i class="ph ph-arrows-out-cardinal" style="margin-right:4px"></i><span data-i18n="floor.dragRepos">Arraste para reposicionar</span></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- DECORAÇÃO -->
        <div id="section-decoracao" class="page-section">
            <div class="section-header mb-24">
                <div>
                    <h2 class="section-title" data-i18n="nav.decoracao">Decoração</h2>
                    <p class="section-subtitle" data-i18n="decor.subtitle">Flores, centros de mesa, iluminação e mais</p>
                </div>
                <div style="display:flex;gap:10px;align-items:center">
                    <select id="decor-evento-filter" class="select-evento" style="padding:8px 12px;border:1px solid var(--border-color);border-radius:10px;font-size:14px;outline:none;" onchange="carregarDecoracao()">
                        <option value="" data-i18n="filter.allEvents">Todos os eventos</option>
                    </select>
                    <button class="btn-primary-sm" onclick="abrirModal('modal-decoracao')"><i class="ph ph-plus"></i> <span data-i18n="btn.addDecor">Adicionar Item</span></button>
                </div>
            </div>
            <div class="decor-grid scroll-area" id="decor-grid">
                <div class="empty-state"><i class="ph ph-flower"></i><p>A carregar...</p></div>
            </div>
        </div>

        <!-- FORNECEDORES -->
        <div id="section-fornecedores" class="page-section">
            <div class="section-header mb-24">
                <div>
                    <h2 class="section-title" data-i18n="nav.fornecedores">Fornecedores</h2>
                    <p class="section-subtitle" data-i18n="fornecedores.subtitle">Gerencie os fornecedores dos seus eventos</p>
                </div>
                <button class="btn-primary-sm" onclick="abrirModal('modal-fornecedor');document.getElementById('fr-id').value='';document.getElementById('modal-fornecedor-titulo').textContent=t('modal.addFornecedor');"><i class="ph ph-plus"></i> <span data-i18n="btn.addFornecedor">Adicionar Fornecedor</span></button>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table>
                <thead><tr><th data-i18n="th.name">Nome</th><th data-i18n="th.category">Categoria</th><th data-i18n="th.contact">Contacto</th><th data-i18n="th.phone">Telefone</th><th>Email</th><th data-i18n="th.actions">Ações</th></tr></thead>
                <tbody id="fornecedores-tbody"><tr><td colspan="6" class="td-empty">A carregar...</td></tr></tbody>
            </table></div></div>
        </div>

        <!-- STAFF & TAREFAS -->
        <div id="section-staff" class="page-section">
            <div class="section-header mb-24"><div><h2 class="section-title" data-i18n="nav.staff">Staff &amp; Tarefas</h2></div></div>
            <div class="sub-tabs">
                <button class="sub-tab active" data-tab="tab-staff"><i class="ph ph-identification-badge"></i> <span class="term-explain" data-term="staff" data-tooltip="">Staff</span></button>
                <button class="sub-tab" data-tab="tab-tarefas"><i class="ph ph-clipboard-text"></i> <span data-i18n="nav.tarefas">Tarefas</span></button>
            </div>
            <div id="tab-staff" class="tab-content active">
                <div class="content-section">
                    <div class="section-header">
                        <h2 data-i18n="staff.teamTitle">Membros da Equipa</h2>
                        <button class="btn-primary-sm" onclick="abrirNovoStaff()"><i class="ph ph-plus"></i> <span data-i18n="btn.addStaff">Adicionar Staff</span></button>
                    </div>
                    <div class="table-wrapper scroll-area"><table><thead><tr><th data-i18n="th.name">Nome</th><th>Email</th><th data-i18n="th.phone">Telefone</th><th data-i18n="th.status">Estado</th><th data-i18n="th.actions">Ações</th></tr></thead><tbody id="staff-tbody"><tr><td colspan="5" class="td-empty">A carregar...</td></tr></tbody></table></div>
                </div>
            </div>
            <div id="tab-tarefas" class="tab-content">
                <div class="content-section">
                    <div class="section-header">
                        <h2 data-i18n="nav.tarefas">Tarefas</h2>
                        <button class="btn-primary-sm" onclick="abrirModal('modal-tarefa')"><i class="ph ph-plus"></i> <span data-i18n="btn.newTask">Nova Tarefa</span></button>
                    </div>
                    <div class="table-wrapper scroll-area"><table><thead><tr><th data-i18n="th.description">Descrição</th><th data-i18n="th.event">Evento</th><th>Staff</th><th data-i18n="th.start">Início</th><th data-i18n="th.end">Fim</th><th data-i18n="th.priority">Prioridade</th><th data-i18n="th.status">Estado</th><th data-i18n="th.actions">Ações</th></tr></thead><tbody id="tarefas-tbody"><tr><td colspan="8" class="td-empty">A carregar...</td></tr></tbody></table></div>
                </div>
            </div>
        </div>

        <!-- PRESENTES -->
        <div id="section-presentes" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title" data-i18n="nav.presentes">Lista de Presentes</h2></div>
                <button class="btn-primary-sm" onclick="abrirModal('modal-presente')"><i class="ph ph-plus"></i> <span data-i18n="btn.addGift">Adicionar Presente</span></button>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table><thead><tr><th data-i18n="th.item">Item</th><th data-i18n="th.event">Evento</th><th data-i18n="th.category">Categoria</th><th data-i18n="th.estPrice">Preço Est.</th><th data-i18n="th.status">Estado</th><th data-i18n="th.responsible">Responsável</th><th data-i18n="th.actions">Ações</th></tr></thead><tbody id="presentes-tbody"><tr><td colspan="7" class="td-empty">A carregar...</td></tr></tbody></table></div></div>
        </div>

        <!-- RECURSOS -->
        <div id="section-recursos" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title" data-i18n="nav.recursos">Recursos do Evento</h2><p class="section-subtitle" data-i18n="recursos.subtitle">Equipamentos, materiais e logística</p></div>
                <button class="btn-primary-sm" onclick="abrirModal('modal-recurso')"><i class="ph ph-plus"></i> <span data-i18n="btn.addResource">Adicionar Recurso</span></button>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table>
                <thead><tr><th data-i18n="th.name">Nome</th><th data-i18n="th.event">Evento</th><th data-i18n="th.category">Categoria</th><th data-i18n="th.qty">Qtd.</th><th data-i18n="th.supplier">Fornecedor</th><th data-i18n="th.delivery">Entrega</th><th data-i18n="th.deadline">Prazo Conf.</th><th data-i18n="th.status">Estado</th><th data-i18n="th.actions">Ações</th></tr></thead>
                <tbody id="recursos-tbody"><tr><td colspan="9" class="td-empty">A carregar...</td></tr></tbody>
            </table></div></div>
        </div>

        <!-- QR CODES -->
        <div id="section-qrcodes" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title"><span class="term-explain" data-term="qrcode" data-tooltip="">QR Codes</span> <span data-i18n="qr.titleSuffix">de Acesso</span></h2></div>
                <button class="btn-primary-sm" onclick="abrirModal('modal-qr')"><i class="ph ph-plus"></i> <span data-i18n="btn.genQR">Gerar QR Code</span></button>
            </div>
            <div class="qr-grid scroll-area" id="qr-grid"><div class="empty-state"><i class="ph ph-qr-code"></i><p>A carregar...</p></div></div>
        </div>

        <!-- CONTRATANTES -->
        <div id="section-clientes" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title" data-i18n="nav.clientes">Contratantes</h2><p class="section-subtitle" data-i18n="clientes.subtitle">Gerencie os contratantes e os seus eventos</p></div>
                <button class="btn-primary-sm" onclick="abrirNovoCliente()"><i class="ph ph-plus"></i> <span data-i18n="btn.newClient">Novo Contratante</span></button>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table>
                <thead><tr><th data-i18n="th.name">Nome</th><th>Email</th><th data-i18n="th.phone">Telefone</th><th data-i18n="th.linkedEvent">Evento Associado</th><th data-i18n="th.status">Estado</th><th data-i18n="th.actions">Ações</th></tr></thead>
                <tbody id="clientes-tbody"><tr><td colspan="6" class="td-empty">A carregar...</td></tr></tbody>
            </table></div></div>
        </div>

        <!-- PERFIL -->
        <div id="section-perfil" class="page-section">
            <div class="section-header mb-24"><div><h2 class="section-title" data-i18n="nav.perfil">O meu Perfil</h2><p class="section-subtitle" data-i18n="perfil.subtitle">Atualize os seus dados pessoais</p></div></div>
            <div class="content-section" style="max-width:560px">
                <div class="perfil-avatar-wrap">
                    <img id="perfil-avatar" src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>" alt="Avatar">
                    <p data-i18n="perfil.avatarAuto">Avatar gerado automaticamente</p>
                </div>
                <form onsubmit="guardarPerfil(event)">
                    <div class="form-grid-2">
                        <div class="form-group full"><label data-i18n="perfil.fullName">Nome Completo</label><input id="perfil-nome" type="text" required></div>
                        <div class="form-group"><label>Email</label><input id="perfil-email" type="email" disabled></div>
                        <div class="form-group"><label data-i18n="th.phone">Telefone</label><input id="perfil-telefone" type="text" placeholder="+351 9xx xxx xxx"></div>
                        <div class="form-group full"><label data-i18n="perfil.role">Função</label><input id="perfil-role" type="text" disabled></div>
                        <div class="form-group full" style="border-top:1px solid var(--border-color);padding-top:20px;margin-top:4px"><label data-i18n="perfil.changePw">Alterar Palavra-passe</label></div>
                        <div class="form-group"><label data-i18n="perfil.currentPw">Atual</label><input id="perfil-pw-atual" type="password" data-i18n-ph="perfil.currentPw" placeholder="Atual"></div>
                        <div class="form-group"><label data-i18n="perfil.newPw">Nova</label><input id="perfil-pw-nova" type="password" data-i18n-ph="perfil.newPwPH" placeholder="Nova (mín. 6 caracteres)"></div>
                    </div>
                    <div style="margin-top:24px"><button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center"><i class="ph ph-floppy-disk"></i> <span data-i18n="btn.saveChanges">Guardar Alterações</span></button></div>
                </form>
            </div>
        </div>

        <!-- DEFINIÇÕES -->
        <div id="section-definicoes" class="page-section">
            <div class="section-header mb-24"><div><h2 class="section-title" data-i18n="dash.definicoes">Definições</h2><p class="section-subtitle" data-i18n="settings.subtitle">Personalização e preferências</p></div></div>
            <div class="settings-section">
                <h3 data-i18n="settings.langTitle">Idioma</h3>
                <p class="section-subtitle" style="margin-bottom:16px" data-i18n="settings.langSubtitle">Escolha o idioma da interface</p>
                <div style="display:flex;gap:12px;flex-wrap:wrap">
                    <button class="settings-lang-btn" data-lang="pt" onclick="setLang('pt')">
                        <span style="font-size:22px">🇵🇹</span>
                        <div><strong data-i18n="lang.pt">Português (PT)</strong><small data-i18n="lang.ptDesc">Português Europeu</small></div>
                    </button>
                    <button class="settings-lang-btn" data-lang="en" onclick="setLang('en')">
                        <span style="font-size:22px">🇺🇸</span>
                        <div><strong data-i18n="lang.en">English (US)</strong><small data-i18n="lang.enDesc">American English</small></div>
                    </button>
                </div>
            </div>
            <div class="settings-section" style="margin-top:20px">
                <h3 data-i18n="settings.tutTitle">Tutorial</h3>
                <p class="section-subtitle" style="margin-bottom:16px" data-i18n="settings.tutSubtitle">Relance o tutorial de introdução à plataforma</p>
                <button class="btn-primary-sm" onclick="window.EHtutorial && window.EHtutorial.restart()">
                    <i class="ph ph-graduation-cap"></i> <span data-i18n="btn.restartTutorial">Reiniciar Tutorial</span>
                </button>
            </div>
        </div>
    </main>
</div>

<!-- ═══════════════════════════════════════════════
     MODAIS
═══════════════════════════════════════════════ -->

<!-- MODAL: Evento -->
<div class="modal-overlay" id="modal-evento">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-calendar-plus"></i> <span id="modal-evento-titulo" data-i18n="modal.newEvent">Novo Evento</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-evento')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarEvento(event)">
            <input type="hidden" id="ev-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="modal.eventName">Nome do Evento *</label><input id="ev-nome" type="text" required data-i18n-ph="modal.eventNamePH" placeholder="Ex: Casamento João & Maria"></div>
                    <div class="form-group"><label data-i18n="th.date">Data *</label><input id="ev-data" type="date" required></div>
                    <div class="form-group"><label data-i18n="modal.time">Hora *</label><input id="ev-hora" type="time" required></div>
                    <div class="form-group"><label data-i18n="modal.eventType">Tipo de Evento</label>
                        <select id="ev-tipo">
                            <option value="" data-i18n="select.pick">Selecionar...</option>
                            <option value="casamento" data-i18n="evtype.casamento">💒 Casamento</option>
                            <option value="baby_shower" data-i18n="evtype.babyShower">🍼 Baby Shower</option>
                            <option value="aniversario" data-i18n="evtype.aniversario">🎂 Aniversário</option>
                            <option value="batizado" data-i18n="evtype.batizado">⛪ Batizado</option>
                            <option value="jantar_empresa" data-i18n="evtype.jantarEmpresa">🏢 Jantar de Empresa</option>
                            <option value="conferencia" data-i18n="evtype.conferencia">📊 Conferência</option>
                            <option value="outro" data-i18n="evtype.outro">✨ Outro</option>
                        </select>
                    </div>
                    <div class="form-group full"><label data-i18n="th.location">Local</label><input id="ev-local" type="text" data-i18n-ph="modal.locationPH" placeholder="Ex: Quinta das Flores, Sintra"></div>
                    <div class="form-group"><label><span class="term-explain" data-term="dresscode" data-tooltip="">Dresscode</span></label>
                        <select id="ev-dresscode">
                            <option value="" data-i18n="select.pick">Selecionar...</option>
                            <option>Formal</option><option>Black Tie</option>
                            <option>Smart Casual</option><option>Casual</option><option>Business</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="evento.contratante">Contratante</label>
                        <select id="ev-cliente" class="select-cliente">
                            <option value="" data-i18n="select.noClient">Sem contratante</option>
                        </select>
                    </div>
                    <div class="form-group full"><label data-i18n="modal.description">Descrição</label><textarea id="ev-descricao" data-i18n-ph="modal.descriptionPH" placeholder="Descrição do evento..."></textarea></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-evento')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.saveEvent">Guardar Evento</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Convidado -->
<div class="modal-overlay" id="modal-convidado">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-user-plus"></i> <span id="modal-convidado-titulo" data-i18n="modal.addGuest">Adicionar Convidado</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-convidado')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarConvidado(event)">
            <input type="hidden" id="cv-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="th.name">Nome *</label><input id="cv-nome" type="text" required data-i18n-ph="modal.fullName" placeholder="Nome completo"></div>
                    <div class="form-group"><label>Email</label><input id="cv-email" type="email" placeholder="email@exemplo.com"></div>
                    <div class="form-group"><label data-i18n="th.phone">Telefone</label><input id="cv-telefone" type="text" placeholder="+351 9xx xxx xxx"></div>
                    <div class="form-group"><label data-i18n="th.event">Evento *</label>
                        <select id="cv-evento" class="select-evento" required>
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.table">Mesa</label>
                        <select id="cv-mesa">
                            <option value="" data-i18n="select.noTable">Sem mesa</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="modal.rsvpStatus"><span class="term-explain" data-term="rsvp" data-tooltip="">RSVP</span></label>
                        <select id="cv-rsvp">
                            <option value="pendente" data-i18n="rsvp.pendente">Pendente</option>
                            <option value="confirmado" data-i18n="rsvp.confirmado">Confirmado</option>
                            <option value="recusado" data-i18n="rsvp.recusado">Recusado</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-convidado')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.save">Guardar</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Mesa -->
<div class="modal-overlay" id="modal-mesa">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-table"></i> <span id="modal-mesa-titulo" data-i18n="modal.addTable">Adicionar Mesa</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-mesa')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarMesa(event)">
            <input type="hidden" id="ms-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="modal.tableName">Nome da Mesa</label><input id="ms-nome" type="text" data-i18n-ph="modal.tableNamePH" placeholder="Ex: Mesa dos Padrinhos, Família da Noiva..."></div>
                    <div class="form-group"><label data-i18n="modal.tableNum">Número *</label><input id="ms-numero" type="number" min="1" required placeholder="1"></div>
                    <div class="form-group"><label data-i18n="th.capacity">Capacidade *</label><input id="ms-capacidade" type="number" min="1" required data-i18n-ph="modal.capacityPH" placeholder="Nº de pessoas"></div>
                    <div class="form-group"><label data-i18n="th.shape">Forma</label>
                        <select id="ms-forma">
                            <option value="round" data-i18n="shape.round">⭕ Redonda</option>
                            <option value="rectangle" data-i18n="shape.rectangle">⬜ Rectangular</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="modal.location">Localização</label><input id="ms-local" type="text" data-i18n-ph="modal.locationPH2" placeholder="Ex: Jardim, Salão Principal"></div>
                    <div class="form-group"><label data-i18n="th.event">Evento *</label>
                        <select id="ms-evento" class="select-evento" required>
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-mesa')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.saveTable">Guardar Mesa</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Tarefa -->
<div class="modal-overlay" id="modal-tarefa">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-clipboard-text"></i> <span id="modal-tarefa-titulo" data-i18n="modal.newTask">Nova Tarefa</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-tarefa')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarTarefa(event)">
            <input type="hidden" id="tr-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="th.description">Descrição *</label><textarea id="tr-descricao" required data-i18n-ph="modal.taskDescPH" placeholder="Descreva a tarefa..."></textarea></div>
                    <div class="form-group"><label data-i18n="th.event">Evento *</label>
                        <select id="tr-evento" class="select-evento" required>
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="modal.staffResponsible">Staff Responsável</label>
                        <select id="tr-staff" class="select-staff">
                            <option value="" data-i18n="select.staff">Selecionar staff...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.start">Data de Início</label><input id="tr-inicio" type="datetime-local"></div>
                    <div class="form-group"><label data-i18n="th.end">Data de Fim</label><input id="tr-fim" type="datetime-local"></div>
                    <div class="form-group"><label data-i18n="th.priority">Prioridade</label>
                        <select id="tr-prioridade">
                            <option value="media" data-i18n="priority.media">Média</option>
                            <option value="alta" data-i18n="priority.alta">Alta</option>
                            <option value="baixa" data-i18n="priority.baixa">Baixa</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.status">Estado</label>
                        <select id="tr-estado">
                            <option value="pendente" data-i18n="task.pendente">Pendente</option>
                            <option value="em_andamento" data-i18n="task.emAndamento">Em Andamento</option>
                            <option value="concluida" data-i18n="task.concluida">Concluída</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-tarefa')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.saveTask">Guardar Tarefa</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Presente -->
<div class="modal-overlay" id="modal-presente">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-gift"></i> <span id="modal-presente-titulo" data-i18n="modal.addGift">Adicionar Presente</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-presente')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarPresente(event)">
            <input type="hidden" id="pr-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="th.item">Nome do Item *</label><input id="pr-nome" type="text" required data-i18n-ph="modal.itemNamePH" placeholder="Ex: Jogo de Louça"></div>
                    <div class="form-group"><label data-i18n="th.event">Evento *</label>
                        <select id="pr-evento" class="select-evento" required>
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.category">Categoria</label>
                        <select id="pr-categoria">
                            <option value="" data-i18n="select.pick">Selecionar...</option>
                            <option data-i18n="giftcat.eletro">Eletrodomésticos</option><option data-i18n="nav.decoracao">Decoração</option>
                            <option data-i18n="giftcat.viagem">Viagem</option><option data-i18n="giftcat.dinheiro">Dinheiro</option><option data-i18n="evtype.outro">Outro</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.estPrice">Preço Estimado (€)</label><input id="pr-preco" type="number" step="0.01" min="0" placeholder="0.00"></div>
                    <div class="form-group"><label data-i18n="th.status">Estado</label>
                        <select id="pr-estado">
                            <option value="pendente" data-i18n="rsvp.pendente">Pendente</option>
                            <option value="reservado" data-i18n="gift.reservado">Reservado</option>
                            <option value="confirmado" data-i18n="rsvp.confirmado">Confirmado</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-presente')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.saveGift">Guardar Presente</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Recurso -->
<div class="modal-overlay" id="modal-recurso">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-package"></i> <span id="modal-recurso-titulo" data-i18n="modal.addResource">Adicionar Recurso</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-recurso')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarRecurso(event)">
            <input type="hidden" id="rc-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="modal.resourceName">Nome do Recurso *</label><input id="rc-nome" type="text" required data-i18n-ph="modal.resourceNamePH" placeholder="Ex: Cadeiras, Projetor..."></div>
                    <div class="form-group"><label data-i18n="th.event">Evento</label>
                        <select id="rc-evento" class="select-evento">
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.category">Categoria</label>
                        <select id="rc-categoria">
                            <option value="" data-i18n="select.pick">Selecionar...</option>
                            <option data-i18n="rescat.mobiliario">Mobiliário</option><option data-i18n="rescat.audiovisual">Audiovisual</option>
                            <option data-i18n="rescat.catering">Catering</option><option data-i18n="nav.decoracao">Decoração</option><option data-i18n="rescat.transporte">Transporte</option><option data-i18n="evtype.outro">Outro</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="modal.totalQty">Quantidade Total</label><input id="rc-qtd-total" type="number" min="0" value="0"></div>
                    <div class="form-group"><label data-i18n="modal.usedQty">Quantidade Usada</label><input id="rc-qtd-usada" type="number" min="0" value="0"></div>
                    <div class="form-group"><label data-i18n="th.supplier">Fornecedor</label>
                        <select id="rc-fornecedor" class="select-fornecedor">
                            <option value="" data-i18n="select.noFornecedor">Sem fornecedor</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.delivery">Data de Entrega</label><input id="rc-data-entrega" type="date"></div>
                    <div class="form-group"><label data-i18n="th.deadline">Prazo de Confirmação</label><input id="rc-prazo" type="date"></div>
                    <div class="form-group"><label data-i18n="modal.deliveryStatus">Estado de Entrega</label>
                        <select id="rc-estado-entrega">
                            <option value="pendente" data-i18n="rsvp.pendente">Pendente</option>
                            <option value="confirmado" data-i18n="rsvp.confirmado">Confirmado</option>
                            <option value="entregue" data-i18n="delivery.entregue">Entregue</option>
                            <option value="cancelado" data-i18n="delivery.cancelado">Cancelado</option>
                            <option value="atrasado" data-i18n="delivery.atrasado">Atrasado</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-recurso')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.saveResource">Guardar Recurso</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Decoração -->
<div class="modal-overlay" id="modal-decoracao">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-flower"></i> <span id="modal-decoracao-titulo" data-i18n="modal.addDecor">Adicionar Decoração</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-decoracao')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarDecoracao(event)">
            <input type="hidden" id="dc-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="modal.decorType">Tipo / Descrição *</label><input id="dc-tipo" type="text" required data-i18n-ph="modal.decorTypePH" placeholder="Ex: Arranjo floral, Centro de mesa, Iluminação..."></div>
                    <div class="form-group"><label data-i18n="th.event">Evento *</label>
                        <select id="dc-evento" class="select-evento" required>
                            <option value="" data-i18n="select.event">Selecionar evento...</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="floor.theme">Tema</label>
                        <select id="dc-tema">
                            <option value="" data-i18n="decor.themeGeneral">Geral</option>
                            <option value="casamento" data-i18n="evtype.casamento">💒 Casamento</option>
                            <option value="baby_shower" data-i18n="evtype.babyShower">🍼 Baby Shower</option>
                            <option value="aniversario" data-i18n="evtype.aniversario">🎂 Aniversário</option>
                            <option value="batizado" data-i18n="evtype.batizado">⛪ Batizado</option>
                            <option value="outro" data-i18n="evtype.outro">✨ Outro</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.supplier">Fornecedor</label>
                        <select id="dc-fornecedor" class="select-fornecedor">
                            <option value="" data-i18n="select.noFornecedor">Sem fornecedor</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="modal.quantity">Quantidade</label><input id="dc-quantidade" type="number" min="1" value="1"></div>
                    <div class="form-group"><label data-i18n="modal.unitPrice">Preço Unitário (€)</label><input id="dc-preco" type="number" step="0.01" min="0" placeholder="0.00"></div>
                    <div class="form-group"><label data-i18n="th.delivery">Data de Entrega</label><input id="dc-data-entrega" type="date"></div>
                    <div class="form-group"><label data-i18n="th.status">Estado</label>
                        <select id="dc-estado">
                            <option value="pendente" data-i18n="rsvp.pendente">Pendente</option>
                            <option value="confirmado" data-i18n="rsvp.confirmado">Confirmado</option>
                            <option value="entregue" data-i18n="delivery.entregue">Entregue</option>
                            <option value="cancelado" data-i18n="delivery.cancelado">Cancelado</option>
                        </select>
                    </div>
                    <div class="form-group full"><label data-i18n="modal.notes">Notas</label><textarea id="dc-descricao" data-i18n-ph="modal.notesPH" placeholder="Detalhes adicionais..."></textarea></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-decoracao')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.save">Guardar</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Fornecedor -->
<div class="modal-overlay" id="modal-fornecedor">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-buildings"></i> <span id="modal-fornecedor-titulo" data-i18n="modal.addFornecedor">Adicionar Fornecedor</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-fornecedor')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarFornecedor(event)">
            <input type="hidden" id="fr-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="modal.fornecedorName">Nome do Fornecedor *</label><input id="fr-nome" type="text" required data-i18n-ph="modal.fornecedorNamePH" placeholder="Ex: Flores & Arte"></div>
                    <div class="form-group"><label data-i18n="th.category">Categoria</label>
                        <select id="fr-categoria">
                            <option value="" data-i18n="select.pick">Selecionar...</option>
                            <option data-i18n="rescat.mobiliario">Mobiliário</option><option data-i18n="rescat.audiovisual">Audiovisual</option>
                            <option data-i18n="rescat.catering">Catering</option><option data-i18n="nav.decoracao">Decoração</option><option data-i18n="rescat.transporte">Transporte</option><option data-i18n="evtype.outro">Outro</option>
                        </select>
                    </div>
                    <div class="form-group"><label data-i18n="th.contact">Contacto</label><input id="fr-contacto" type="text" data-i18n-ph="modal.contactPH" placeholder="Nome do contacto"></div>
                    <div class="form-group"><label data-i18n="th.phone">Telefone</label><input id="fr-telefone" type="text" placeholder="+351 9xx xxx xxx"></div>
                    <div class="form-group full"><label>Email</label><input id="fr-email" type="email" placeholder="email@exemplo.com"></div>
                    <div class="form-group full"><label data-i18n="modal.notes">Notas</label><textarea id="fr-observacoes" data-i18n-ph="modal.notesPH" placeholder="Detalhes adicionais..."></textarea></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-fornecedor')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" class="btn-primary-sm" data-i18n="btn.save">Guardar</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: Contratante -->
<div class="modal-overlay" id="modal-cliente">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-user-list"></i> <span id="modal-cliente-titulo" data-i18n="modal.newClient">Novo Contratante</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-cliente')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarCliente(event)">
            <input type="hidden" id="cl-id">
            <input type="hidden" id="cl-evento-anterior">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="perfil.fullName">Nome Completo *</label><input type="text" id="cl-nome" required data-i18n-ph="modal.clientNamePH" placeholder="Nome do contratante"></div>
                    <div class="form-group full"><label>Email *</label><input type="email" id="cl-email" required placeholder="email@exemplo.com"></div>
                    <div class="form-group"><label data-i18n="th.phone">Telefone</label><input type="text" id="cl-telefone" placeholder="+351 9xx xxx xxx"></div>
                    <div class="form-group"><label data-i18n="perfil.changePw">Palavra-passe</label><input type="password" id="cl-password" data-i18n-ph="modal.autoPassword" placeholder="Deixar vazio para gerar automática"></div>
                    <div class="form-group full"><label data-i18n="th.linkedEvent">Evento Associado</label>
                        <select id="cl-evento" class="select-evento"></select>
                    </div>
                </div>
                <p style="font-size:12px;color:#64748b;margin-top:8px" data-i18n="modal.clientNote">O contratante receberá acesso ao painel do cliente para gerir convidados e presentes do seu evento.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-cliente')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" id="cl-submit-btn" class="btn-primary-sm" data-i18n="btn.createClient">Criar Contratante</button>
            </div>
        </form>
        <div id="cliente-result" style="display:none;padding:16px;background:#f0fdf4;margin:12px;border-radius:8px;font-size:14px;color:#166534;border:1px solid #bbf7d0;"></div>
    </div>
</div>

<!-- MODAL: QR Code -->
<div class="modal-overlay" id="modal-qr">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-qr-code"></i> <span data-i18n="btn.genQR">Gerar QR Code</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-qr')"><i class="ph ph-x"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-grid-2">
                <div class="form-group"><label data-i18n="th.event">Evento *</label>
                    <select id="qr-evento" class="select-evento">
                        <option value="" data-i18n="select.event">Selecionar evento...</option>
                    </select>
                </div>
                <div class="form-group"><label data-i18n="qr.guest">Convidado *</label>
                    <select id="qr-guest">
                        <option value="" data-i18n="qr.selectEventFirst">Selecione primeiro o evento</option>
                    </select>
                </div>
            </div>
            <div id="qr-preview" style="display:none;text-align:center;margin-top:20px;padding:16px;background:#f8fafc;border-radius:10px;">
                <img id="qr-preview-img" src="" alt="QR Code" style="border-radius:8px;border:4px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,.12);">
                <p id="qr-preview-code" style="font-size:11px;color:#64748b;margin-top:10px;word-break:break-all;font-family:monospace;"></p>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn-cancel" onclick="fecharModal('modal-qr')" data-i18n="btn.cancel">Cancelar</button>
            <button type="button" class="btn-primary-sm" onclick="gerarQRCode()"><i class="ph ph-qr-code"></i> <span data-i18n="btn.generate">Gerar</span></button>
        </div>
    </div>
</div>

<!-- MODAL: Staff -->
<div class="modal-overlay" id="modal-staff">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-user-plus"></i> <span id="modal-staff-titulo" data-i18n="btn.addStaff">Adicionar Staff</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-staff')"><i class="ph ph-x"></i></button>
        </div>
        <form id="form-criar-staff" onsubmit="salvarStaff(event)">
            <input type="hidden" id="staff-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label data-i18n="th.name">Nome *</label><input type="text" id="staff-nome" required></div>
                    <div class="form-group full"><label>Email *</label><input type="email" id="staff-email" required></div>
                    <div class="form-group"><label data-i18n="th.phone">Telefone</label><input type="text" id="staff-telefone"></div>
                    <div class="form-group"><label data-i18n="perfil.changePw">Palavra-passe</label><input type="password" id="staff-password" data-i18n-ph="modal.autoPassword" placeholder="Deixar vazio para gerar automática"></div>
                </div>
                <p style="font-size:12px;color:#64748b;margin-top:8px" data-i18n="modal.staffNote">Se não preencher a palavra-passe, será gerada uma aleatória e mostrada após criação.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-staff')" data-i18n="btn.cancel">Cancelar</button>
                <button type="submit" id="staff-submit-btn" class="btn-primary-sm" data-i18n="btn.createStaff">Criar Staff</button>
            </div>
        </form>
        <div id="staff-result" style="display:none;padding:16px;background:#f0fdf4;margin:12px;border-radius:8px;font-size:14px;color:#166534;border:1px solid #bbf7d0;"></div>
    </div>
</div>

<script src="app.js?v=<?= filemtime(__DIR__.'/app.js') ?>"></script>
<script src="tutorial.js"></script>
<script>
/* ── Inicialização ─────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
    carregarEstatisticas();
    carregarInicioResumido();
    carregarNotificacoes();
    carregarEventos().then(evs => {
        preencherSelectEventos(evs);
        preencherSelectClientes();
    });
    carregarStaffSelects();
    carregarConvidados();
    carregarMesas();
    carregarStaffTabela();
    carregarTarefasTabela();
    carregarPresentes();
    preencherSelectFornecedores().then(() => {
        carregarRecursos();
        carregarDecoracao();
    });
    carregarQRCodes();
    carregarFornecedoresTabela();
    carregarClientesTabela();
    carregarPerfil();
});

/* ── Navegação lateral ─────────────────────────────────── */
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        goToSection(this.dataset.section);
    });
});

function goToSection(section) {
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector(`.nav-link[data-section="${section}"]`)?.classList.add('active');
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${section}`)?.classList.add('active');

    const actions = {
        inicio:      () => { carregarEstatisticas(); carregarInicioResumido(); },
        eventos:     carregarEventosGrid,
        convidados:  () => { carregarConvidados(); carregarMesas(); },
        decoracao:   carregarDecoracao,
        fornecedores: carregarFornecedoresTabela,
        staff:       () => { carregarStaffTabela(); carregarTarefasTabela(); },
        presentes:   carregarPresentes,
        recursos:    carregarRecursos,
        qrcodes:     carregarQRCodes,
        clientes:    carregarClientesTabela,
        perfil:      carregarPerfil,
        definicoes:  () => { _updateSettingsLangBtns(); },
    };
    if (actions[section]) actions[section]();
}

function _updateSettingsLangBtns() {
    const lang = (localStorage.getItem('eh_lang') || 'pt');
    document.querySelectorAll('.settings-lang-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.lang === lang);
    });
}

function reloadAllDashboard() {
    carregarEstatisticas();
    carregarInicioResumido();
    carregarEventosGrid?.();
    carregarConvidados();
    carregarMesas();
    carregarDecoracao();
    carregarStaffTabela();
    carregarTarefasTabela();
    carregarPresentes();
    carregarRecursos();
    carregarQRCodes();
    carregarFornecedoresTabela();
    preencherSelectFornecedores();
    carregarClientesTabela();
    _updateSettingsLangBtns();
}

/* ── Filtros de eventos ─────────────────────────────────── */
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        document.querySelectorAll('.event-card').forEach(card => {
            card.style.display = (filter === 'all' || card.dataset.status === filter) ? 'flex' : 'none';
        });
    });
});

/* ── Sub-tabs ───────────────────────────────────────────── */
document.querySelectorAll('.sub-tab').forEach(tab => {
    tab.addEventListener('click', function () {
        const parent = this.closest('.page-section');
        parent.querySelectorAll('.sub-tab').forEach(t => t.classList.remove('active'));
        parent.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        document.getElementById(this.dataset.tab)?.classList.add('active');
    });
});

/* ── Resumo do Início ───────────────────────────────────── */
async function carregarInicioResumido() {
    try {
        const [evR, tR] = await Promise.all([API.get('eventos.php'), API.get('tarefas.php')]);
        const tbody = document.getElementById('inicio-eventos-tbody');
        if (tbody && evR.status === 'ok') {
            const evs = (evR.data || []).slice(0, 5);
            tbody.innerHTML = evs.length
                ? evs.map(e => `
                    <tr>
                        <td><strong>${esc(e.nome_evento)}</strong></td>
                        <td>${formatDateSimple(e.data)}</td>
                        <td>${esc(e.local || '—')}</td>
                        <td><span class="badge badge-purple">${t('dyn.active')}</span></td>
                        <td>
                            <button class="btn-icon" onclick="abrirEditarEvento(${e.id_evento})"><i class="ph ph-pencil-simple"></i></button>
                            <button class="btn-icon delete" onclick="eliminarEvento(${e.id_evento})"><i class="ph ph-trash"></i></button>
                        </td>
                    </tr>`).join('')
                : `<tr><td colspan="5" class="td-empty">${t('dyn.noEvents2')}</td></tr>`;
        }
        const lista = document.getElementById('inicio-tarefas-list');
        if (lista && tR.status === 'ok') {
            const pendentes = (tR.data || []).filter(tarefa => tarefa.estado === 'pendente').slice(0, 4);
            lista.innerHTML = pendentes.length
                ? pendentes.map(tarefa => `
                    <div class="task-item">
                        <div class="task-info">
                            <i class="ph ph-circle"></i>
                            <span>${esc(tarefa.descricao)} — <strong>${esc(tarefa.nome_staff || '—')}</strong></span>
                        </div>
                        <span class="badge badge-warning">${t('task.pendente')}</span>
                    </div>`).join('')
                : `<p class="td-empty">${t('dyn.noPendingTasks')}</p>`;
        }
    } catch (e) { console.error(e); }
}

/* ── Staff Tabela ───────────────────────────────────────── */
async function carregarStaffTabela() {
    const r = await API.get('staff.php');
    const tbody = document.getElementById('staff-tbody');
    if (!tbody) return;
    if (r.status !== 'ok' || !(r.data || []).length) {
        tbody.innerHTML = `<tr><td colspan="5" class="td-empty">${t('dyn.noStaff')}</td></tr>`;
        return;
    }
    tbody.innerHTML = r.data.map(s => `
        <tr>
            <td><strong>${esc(s.nome)}</strong></td>
            <td>${esc(s.email || '—')}</td>
            <td>${esc(s.telefone || '—')}</td>
            <td><span class="badge ${s.estado_conta === 'ativo' ? 'badge-success' : 'badge-muted'}">${s.estado_conta === 'ativo' ? t('dyn.active') : capitalize(s.estado_conta || 'ativo')}</span></td>
            <td>
                <a class="btn-icon" href="staff-dashboard.php?preview_id=${s.id_utilizador}" target="_blank" title="${t('btn.viewStaff')}"><i class="ph ph-eye"></i></a>
                <button class="btn-icon" onclick='abrirEditarStaff(${JSON.stringify(s).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon" onclick="enviarEmailStaff(${s.id_utilizador},${jsStr(s.nome)})" title="${t('btn.sendAccess')}" style="color:#0d9488"><i class="ph ph-envelope-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarStaff(${s.id_utilizador})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

function abrirNovoStaff() {
    setVal('staff-id', '');
    setVal('staff-nome', '');
    setVal('staff-email', '');
    setVal('staff-telefone', '');
    setVal('staff-password', '');
    const emailInput = document.getElementById('staff-email');
    if (emailInput) emailInput.disabled = false;
    const titulo = document.getElementById('modal-staff-titulo');
    if (titulo) titulo.textContent = t('btn.addStaff');
    const btn = document.getElementById('staff-submit-btn');
    if (btn) btn.textContent = t('btn.createStaff');
    const res = document.getElementById('staff-result');
    if (res) res.style.display = 'none';
    abrirModal('modal-staff');
}

function abrirEditarStaff(s) {
    setVal('staff-id', s.id_utilizador);
    setVal('staff-nome', s.nome || '');
    setVal('staff-email', s.email || '');
    setVal('staff-telefone', s.telefone || '');
    setVal('staff-password', '');
    const emailInput = document.getElementById('staff-email');
    if (emailInput) emailInput.disabled = true;
    const titulo = document.getElementById('modal-staff-titulo');
    if (titulo) titulo.textContent = t('modal.editStaff');
    const btn = document.getElementById('staff-submit-btn');
    if (btn) btn.textContent = t('btn.saveChanges');
    const res = document.getElementById('staff-result');
    if (res) res.style.display = 'none';
    abrirModal('modal-staff');
}

/* ── Criar/Editar Staff ─────────────────────────────────── */
async function salvarStaff(e) {
    e.preventDefault();
    const id = getVal('staff-id');
    const body = {
        nome:     document.getElementById('staff-nome').value.trim(),
        email:    document.getElementById('staff-email').value.trim(),
        telefone: document.getElementById('staff-telefone').value.trim(),
        password: document.getElementById('staff-password').value,
        role:     'staff',
    };
    const r = await API.post('criar_utilizador.php', body);
    const resultDiv = document.getElementById('staff-result');
    if (r.status === 'ok') {
        if (!id && r.data && r.data.password) {
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = `✅ Staff criado! <strong>Palavra-passe gerada: ${esc(r.data.password)}</strong> — Guarde esta password para partilhar com o staff.`;
            toast(t('toast.staffCreated'));
        } else {
            resultDiv.style.display = 'none';
            toast(id ? t('toast.staffUpdated') : t('toast.staffCreated2'));
            fecharModal('modal-staff');
            document.getElementById('form-criar-staff').reset();
        }
        carregarStaffTabela();
        carregarStaffSelects();
    } else {
        resultDiv.style.display = 'none';
        toast('❌ ' + (r.msg || 'Erro ao criar staff'), 'error');
    }
}

async function eliminarStaff(id) {
    if (!await confirmDialog(t('confirm.deleteStaff'))) return;
    const r = await API.delete(`criar_utilizador.php?id=${id}`);
    if (r?.status === 'ok') {
        toast(t('toast.staffDeleted'));
        carregarStaffTabela();
        carregarStaffSelects();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function enviarEmailStaff(idStaff, nome) {
    if (!await confirmDialog(t('confirm.sendEmail').replace('{0}', nome))) return;
    const r = await API.post('enviar_email_staff.php', { id_staff: idStaff });
    if (r?.status === 'ok') {
        toast(`Email enviado para ${nome}!`);
        if (r.data?.password) {
            await alertDialog('Email enviado!\nPassword temporária gerada (esta informação não será mostrada novamente):', { copyValue: r.data.password });
        }
    } else {
        toast(r?.msg || 'Erro ao enviar email', 'error');
    }
}
</script>

<!-- MESA SIDE PANEL -->
<div id="msp-overlay" class="msp-overlay" onclick="fecharPainelMesa()"></div>
<div id="mesa-side-panel" class="mesa-side-panel">
    <div class="msp-header">
        <div>
            <h3 data-i18n="msp.editTable">Editar Mesa</h3>
            <p data-i18n="msp.saveHint">Clique em Guardar para confirmar</p>
        </div>
        <button class="msp-close" onclick="fecharPainelMesa()"><i class="ph ph-x"></i></button>
    </div>
    <!-- Live preview -->
    <div class="msp-preview" id="msp-preview"></div>
    <div class="msp-body">
        <input type="hidden" id="msp-id">
        <div class="msp-field">
            <label class="msp-label" data-i18n="th.name">Nome</label>
            <input type="text" id="msp-nome" class="msp-input" data-i18n-ph="msp.namePH" placeholder="Ex: Mesa dos Noivos" oninput="atualizarPreviewPanel()">
        </div>
        <div class="msp-field">
            <label class="msp-label" data-i18n="th.shape">Forma</label>
            <div class="msp-tipo-toggle">
                <button class="msp-tipo-btn active" data-forma="round" onclick="setFormaPanel(this,'round')">
                    <i class="ph ph-circle"></i> <span data-i18n="shape.round2">Redonda</span>
                </button>
                <button class="msp-tipo-btn" data-forma="rect" onclick="setFormaPanel(this,'rect')">
                    <i class="ph ph-rectangle"></i> <span data-i18n="shape.rectangle2">Retangular</span>
                </button>
            </div>
        </div>
        <div class="msp-field">
            <label class="msp-label"><span data-i18n="msp.size">Tamanho</span> &mdash; <span id="msp-tamanho-label" data-i18n="size.medium">Médio</span></label>
            <input type="range" id="msp-tamanho" class="msp-slider" min="1" max="3" step="1" value="2" oninput="onTamanhoChange(this)">
            <div class="msp-slider-marks"><span data-i18n="size.s">P</span><span data-i18n="size.m">M</span><span data-i18n="size.l">G</span></div>
        </div>
        <div class="msp-field">
            <label class="msp-label"><span data-i18n="msp.seats">Lugares</span> &mdash; <span id="msp-lugares-val">8</span></label>
            <input type="range" id="msp-lugares" class="msp-slider" min="1" max="24" value="8" oninput="onLugaresChange(this)">
        </div>
        <div class="msp-field">
            <label class="msp-label" data-i18n="msp.tablecloth">Cor da Toalha</label>
            <div class="msp-swatches">
                <button class="msp-swatch" data-cor="teal"    onclick="setCorPanel(this,'teal')"    title="Teal"    style="background:#ccfbf1;border-color:#0d9488"></button>
                <button class="msp-swatch" data-cor="rosa"    onclick="setCorPanel(this,'rosa')"    title="Rosa"    style="background:#fce7f3;border-color:#ec4899"></button>
                <button class="msp-swatch" data-cor="sage"    onclick="setCorPanel(this,'sage')"    title="Sage"    style="background:#dcfce7;border-color:#15803d"></button>
                <button class="msp-swatch" data-cor="marfim"  onclick="setCorPanel(this,'marfim')"  title="Marfim"  style="background:#fef9c3;border-color:#ca8a04"></button>
                <button class="msp-swatch" data-cor="azul"    onclick="setCorPanel(this,'azul')"    title="Azul"    style="background:#dbeafe;border-color:#2563eb"></button>
                <button class="msp-swatch" data-cor="lavanda" onclick="setCorPanel(this,'lavanda')" title="Lavanda" style="background:#ede9fe;border-color:#7c3aed"></button>
            </div>
        </div>
    </div>
    <div class="msp-footer">
        <button class="msp-btn-save" onclick="guardarMesaPanel()">
            <i class="ph ph-floppy-disk"></i> <span data-i18n="btn.save">Guardar</span>
        </button>
        <button class="msp-btn-del" onclick="eliminarMesaPanel()" data-i18n-title="msp.deleteTable" title="Eliminar mesa">
            <i class="ph ph-trash"></i>
        </button>
    </div>
</div>
</body>
</html>
