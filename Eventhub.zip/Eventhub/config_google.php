<?php
/**
 * config_google.php
 * 
 * Google OAuth 2.0 Configuration
 * 
 * Instructions to get credentials:
 * 1. Go to https://console.cloud.google.com
 * 2. Create a new project (or select existing one)
 * 3. Go to APIs & Services → Enable Google+ API
 * 4. Go to Credentials → Create OAuth 2.0 Client ID (Web application)
 * 5. Authorized redirect URIs: http://localhost/Eventhub/google_callback.php
 * 6. Copy Client ID and Client Secret below
 */

// ============================================================================
// IMPORTANT: Replace these with your actual Google OAuth credentials
// ============================================================================
define('GOOGLE_CLIENT_ID',     '288644791988-up0rbaaj3227uls11g0t2darge65unr6.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI',  'http://localhost/Eventhub/google_callback.php');

// Google OAuth endpoints
define('GOOGLE_AUTH_URL',      'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL',     'https://www.googleapis.com/oauth2/v4/token');
define('GOOGLE_USER_INFO_URL', 'https://www.googleapis.com/oauth2/v1/userinfo');

/**
 * Returns the Google authorization URL to redirect the user to
 * @return string The authorization URL
 */
function getGoogleAuthUrl(): string {
    if (session_status() === PHP_SESSION_NONE) session_start();
    $state = bin2hex(random_bytes(32));
    $_SESSION['oauth_state'] = $state;

    $params = [
        'client_id'     => GOOGLE_CLIENT_ID,
        'redirect_uri'  => GOOGLE_REDIRECT_URI,
        'response_type' => 'code',
        'scope'         => 'openid email profile',
        'access_type'   => 'offline',
        'prompt'        => 'consent',
        'state'         => $state,
    ];

    return GOOGLE_AUTH_URL . '?' . http_build_query($params);
}
