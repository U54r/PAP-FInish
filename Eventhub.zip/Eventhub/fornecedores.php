<?php
// fornecedores.php — CRUD Fornecedores
// DB: gestao_eventos
// Table: fornecedor (id_fornecedor, nome, categoria, contacto, telefone, email, observacoes, id_organizador)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();
requireRole(['organizador']);

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);
$uid    = (int)$_SESSION['id_utilizador'];

switch ($method) {

case 'GET':
    $stmt = $pdo->prepare("
        SELECT * FROM fornecedor
        WHERE id_organizador = ? OR id_organizador IS NULL
        ORDER BY nome ASC
    ");
    $stmt->execute([$uid]);
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    $d = getBody();
    if (empty($d['nome'])) {
        jsonErro('Campo obrigatório: nome');
    }
    $pdo->prepare("
        INSERT INTO fornecedor (nome, categoria, contacto, telefone, email, observacoes, id_organizador)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        $d['nome'],
        $d['categoria']    ?? '',
        $d['contacto']     ?? '',
        $d['telefone']     ?? '',
        $d['email']        ?? '',
        $d['observacoes']  ?? '',
        $uid,
    ]);
    jsonOk(['id_fornecedor' => (int)$pdo->lastInsertId()], 'Fornecedor criado');
    break;

case 'PUT':
    if (!$id) jsonErro('ID obrigatório');
    $putChk = $pdo->prepare('SELECT id_fornecedor FROM fornecedor WHERE id_fornecedor = ? AND (id_organizador = ? OR id_organizador IS NULL)');
    $putChk->execute([$id, $uid]);
    if (!$putChk->fetch()) jsonErro('Sem permissão.', 403);
    $d = getBody();
    if (empty($d['nome'])) {
        jsonErro('Campo obrigatório: nome');
    }
    $pdo->prepare("
        UPDATE fornecedor
        SET nome=?, categoria=?, contacto=?, telefone=?, email=?, observacoes=?
        WHERE id_fornecedor=?
    ")->execute([
        $d['nome'],
        $d['categoria']    ?? '',
        $d['contacto']     ?? '',
        $d['telefone']     ?? '',
        $d['email']        ?? '',
        $d['observacoes']  ?? '',
        $id,
    ]);
    jsonOk([], 'Fornecedor atualizado');
    break;

case 'DELETE':
    if (!$id) jsonErro('ID obrigatório');
    $delChk = $pdo->prepare('SELECT id_fornecedor FROM fornecedor WHERE id_fornecedor = ? AND (id_organizador = ? OR id_organizador IS NULL)');
    $delChk->execute([$id, $uid]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("DELETE FROM fornecedor WHERE id_fornecedor=?")->execute([$id]);
    jsonOk([], 'Fornecedor eliminado');
    break;
}
