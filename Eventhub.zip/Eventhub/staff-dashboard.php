<?php
require_once __DIR__ . '/auth.php';
requireLogin();
$currentUser = getCurrentUser();

$preview_id = 0;
if (in_array($currentUser['nome_role'], ['organizador', 'administrador']) && !empty($_GET['preview_id'])) {
    $preview_id = (int)$_GET['preview_id'];
}

if ($currentUser['nome_role'] !== 'staff' && !$preview_id) {
    if ($currentUser['nome_role'] === 'organizador')    header('Location: dashboard.php');
    elseif ($currentUser['nome_role'] === 'cliente')     header('Location: cliente-dashboard.php');
    else                                                  header('Location: login.php');
    exit;
}

$pdo = getDB();

// Verify that the previewed staff member belongs to this organizer
if ($preview_id) {
    $stmtPreviewChk = $pdo->prepare(
        "SELECT * FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?"
    );
    $stmtPreviewChk->execute([$preview_id, $currentUser['id_utilizador']]);
    $user = $stmtPreviewChk->fetch();
    if (!$user) {
        header('Location: dashboard.php');
        exit;
    }
} else {
    $user = $currentUser;
}
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Staff — Event Hub</title>
    <meta name="description" content="Painel de staff — gerencie as suas tarefas no Event Hub.">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%230d9488'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' fill='white' font-size='18' font-weight='700' font-family='sans-serif'%3EEH%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <link rel="stylesheet" href="staff.css?v=<?= filemtime(__DIR__.'/staff.css') ?>">
    <style>
        .notif-wrapper { position:relative; }
        #notif-panel { display:none; position:absolute; top:52px; right:0; width:360px; background:var(--white); border:1px solid var(--border-color); border-radius:16px; box-shadow:0 20px 60px rgba(0,0,0,0.12); z-index:500; overflow:hidden; }
        #notif-panel.open { display:block; }
        .notif-panel-header { display:flex; justify-content:space-between; align-items:center; padding:16px 20px; border-bottom:1px solid var(--border-color); }
        .notif-panel-header h4 { font-size:15px; font-weight:700; }
        .notif-panel-header button { font-size:12px; color:var(--primary); background:none; border:none; cursor:pointer; font-weight:600; }
        .notif-item { display:flex; gap:12px; align-items:flex-start; padding:14px 20px; border-bottom:1px solid var(--border-color); }
        .notif-item:hover { background:var(--bg-light); }
        .notif-icon-wrap { font-size:20px; flex-shrink:0; margin-top:2px; }
        .notif-msg  { font-size:13px; color:var(--text-dark); font-weight:500; line-height:1.4; }
        .notif-meta { font-size:11px; color:var(--text-muted); margin-top:3px; }
        .notif-dismiss { margin-left:auto; background:none; border:none; cursor:pointer; color:var(--text-muted); font-size:16px; flex-shrink:0; }
        .notif-empty { text-align:center; padding:32px; color:var(--text-muted); font-size:14px; }
        #notif-badge { position:absolute; top:-4px; right:-4px; background:#ef4444; color:white; font-size:10px; font-weight:800; border-radius:50%; width:18px; height:18px; display:flex; align-items:center; justify-content:center; border:2px solid white; }
        .perfil-avatar-wrap { text-align:center; margin-bottom:20px; }
        .perfil-avatar-wrap img { width:80px; height:80px; border-radius:50%; border:3px solid var(--primary); }
        .td-empty { text-align:center; color:var(--text-muted); padding:24px; font-size:14px; }
    </style>
</head>
<body class="dashboard-body">
<div class="dashboard-container">

    <aside class="sidebar">
        <div>
            <div class="sidebar-logo">
                <i class="ph-fill ph-calendar-check"></i><span>Event Hub</span>
            </div>
            <div class="staff-profile-card">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>"
                     class="staff-profile-img" alt="<?= htmlspecialchars($user['nome']) ?>">
                <div class="staff-profile-info">
                    <strong><?= htmlspecialchars($user['nome']) ?></strong>
                    <span>Staff</span>
                </div>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-link active" data-section="inicio"><i class="ph ph-house"></i> Início</a>
                <a href="#" class="nav-link" data-section="tarefas"><i class="ph ph-clipboard-text"></i> Minhas Tarefas</a>
                <a href="#" class="nav-link" data-section="eventos"><i class="ph ph-calendar"></i> Meus Eventos</a>
                <?php if (!$preview_id): ?>
                <a href="#" class="nav-link" data-section="perfil"><i class="ph ph-user-circle"></i> Perfil</a>
                <?php endif; ?>
            </nav>
        </div>
        <div class="sidebar-footer">
            <?php if ($preview_id): ?>
            <a href="dashboard.php" class="back-link"><i class="ph ph-arrow-left"></i> Voltar ao Dashboard</a>
            <?php else: ?>
            <a href="logout.php" class="logout-link"><i class="ph ph-sign-out"></i> Sair</a>
            <?php endif; ?>
        </div>
    </aside>

    <main class="main-content">
        <header class="dashboard-header">
            <div class="welcome" id="page-title">
                <h1>Olá, <?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?>! 👋</h1>
                <p>A tua área de trabalho pessoal.</p>
            </div>
            <div class="header-actions">
                <div class="search-bar">
                    <i class="ph ph-magnifying-glass"></i>
                    <input type="text" placeholder="Pesquisar tarefa..." id="search-input">
                </div>
                <div class="profile-section">
                    <?php if (!$preview_id): ?>
                    <div class="notif-wrapper">
                        <div class="notif-icon" onclick="toggleNotifPanel()" style="cursor:pointer">
                            <i class="ph ph-bell"></i>
                            <span id="notif-badge" style="display:none">0</span>
                        </div>
                        <div id="notif-panel">
                            <div class="notif-panel-header">
                                <h4>Notificações</h4>
                                <button onclick="limparTodasNotifs()">Limpar todas</button>
                            </div>
                            <div id="notif-lista"></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>"
                         alt="Avatar" class="avatar" <?= $preview_id ? '' : 'onclick="goToSection(\'perfil\')" style="cursor:pointer"' ?>>
                </div>
            </div>
        </header>

        <?php if ($preview_id): ?>
        <div class="preview-banner" style="background:#fef9c3;border:1.5px solid #fde68a;border-radius:14px;padding:12px 20px;font-size:13px;color:#78350f;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:10px">
            <i class="ph ph-eye"></i>
            Modo de pré-visualização — a ver o painel de <strong><?= htmlspecialchars($user['nome'] ?? '') ?></strong> (apenas leitura)
        </div>
        <?php endif; ?>

        <!-- INÍCIO -->
        <div id="section-inicio" class="page-section active">
            <section class="stats-grid stats-grid-4">
                <div class="stat-card stat-card-accent purple-accent">
                    <div class="stat-icon purple"><i class="ph ph-list-checks"></i></div>
                    <div class="stat-info"><h3 id="stat-total-tasks">—</h3><p>Total Tasks</p></div>
                    <div class="stat-trend">Total atribuídas</div>
                </div>
                <div class="stat-card stat-card-accent orange-accent">
                    <div class="stat-icon orange"><i class="ph ph-clock"></i></div>
                    <div class="stat-info"><h3 id="stat-pending">—</h3><p>Pending</p></div>
                    <div class="stat-trend">Por iniciar</div>
                </div>
                <div class="stat-card stat-card-accent blue-accent">
                    <div class="stat-icon blue"><i class="ph ph-spinner-gap"></i></div>
                    <div class="stat-info"><h3 id="stat-in-progress">—</h3><p>In Progress</p></div>
                    <div class="stat-trend">Em curso</div>
                </div>
                <div class="stat-card stat-card-accent green-accent">
                    <div class="stat-icon green"><i class="ph ph-check-circle"></i></div>
                    <div class="stat-info"><h3 id="stat-completed">—</h3><p>Completed</p></div>
                    <div class="stat-trend up">Concluídas</div>
                </div>
            </section>

            <section class="content-section progress-overview-section">
                <div class="section-header">
                    <h2>Progresso Geral</h2>
                    <span class="progress-percent-label" id="progress-pct-label">0% concluído</span>
                </div>
                <div class="overall-progress-bar">
                    <div class="overall-progress-fill" id="overall-progress-bar-fill" style="width:0%">
                        <span class="progress-label-inside">0 / 0 tarefas</span>
                    </div>
                </div>
                <div class="progress-legend">
                    <span class="legend-dot green"></span><span>Concluídas</span>
                    <span class="legend-dot blue"></span><span>Em Progresso</span>
                    <span class="legend-dot orange"></span><span>Pendentes</span>
                </div>
            </section>

            <div class="two-col-grid">
                <section class="content-section">
                    <div class="section-header">
                        <h2>🔥 Urgentes</h2>
                        <button class="btn-link" onclick="goToSection('tarefas')">Ver todas</button>
                    </div>
                    <div class="tasks-list" id="inicio-tarefas-urgentes"><p class="td-empty">A carregar...</p></div>
                </section>
                <section class="content-section">
                    <div class="section-header"><h2>📅 Meus Eventos</h2></div>
                    <div class="tasks-list" id="inicio-eventos-lista"><p class="td-empty">A carregar...</p></div>
                </section>
            </div>
        </div>

        <!-- TAREFAS (Kanban) -->
        <div id="section-tarefas" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">Minhas Tarefas</h2><p class="section-subtitle">Todas as tarefas atribuídas a ti</p></div>
                <div class="tasks-header-actions">
                    <select class="filter-select" id="filter-prioridade" onchange="filtrarKanban()">
                        <option value="">Todas as prioridades</option>
                        <option value="alta">Alta</option>
                        <option value="media">Média</option>
                        <option value="baixa">Baixa</option>
                    </select>
                </div>
            </div>
            <div class="kanban-board">
                <div class="kanban-col">
                    <div class="kanban-col-header pending-header">
                        <div class="kanban-col-title"><span class="kanban-dot orange"></span><h3>Pendente</h3></div>
                        <span class="kanban-count" id="kanban-count-pendente">0</span>
                    </div>
                    <div class="kanban-cards" id="kanban-pendente"></div>
                </div>
                <div class="kanban-col">
                    <div class="kanban-col-header progress-header">
                        <div class="kanban-col-title"><span class="kanban-dot blue"></span><h3>Em Andamento</h3></div>
                        <span class="kanban-count" id="kanban-count-em_andamento">0</span>
                    </div>
                    <div class="kanban-cards" id="kanban-em_andamento"></div>
                </div>
                <div class="kanban-col">
                    <div class="kanban-col-header done-header">
                        <div class="kanban-col-title"><span class="kanban-dot green"></span><h3>Concluída</h3></div>
                        <span class="kanban-count" id="kanban-count-concluida">0</span>
                    </div>
                    <div class="kanban-cards" id="kanban-concluida"></div>
                </div>
            </div>
        </div>

        <!-- EVENTOS -->
        <div id="section-eventos" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">Meus Eventos</h2><p class="section-subtitle">Eventos em que estás a colaborar</p></div>
            </div>
            <div class="events-grid" id="staff-events-grid"><div style="padding:40px;text-align:center;color:#64748b">A carregar...</div></div>
        </div>

        <!-- PERFIL -->
        <?php if (!$preview_id): ?>
        <div id="section-perfil" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">O meu Perfil</h2></div>
            </div>
            <div class="content-section" style="max-width:560px">
                <div class="perfil-avatar-wrap">
                    <img id="perfil-avatar" src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>" alt="Avatar">
                    <p>Avatar gerado pelo seu nome</p>
                </div>
                <form onsubmit="guardarPerfil(event)">
                    <div class="form-grid-2">
                        <div class="form-group full"><label>Nome Completo</label><input id="perfil-nome" type="text" required></div>
                        <div class="form-group"><label>Email</label><input id="perfil-email" type="email" disabled style="opacity:.6"></div>
                        <div class="form-group"><label>Telefone</label><input id="perfil-telefone" type="text"></div>
                        <div class="form-group full"><label>Função</label><input id="perfil-role" type="text" disabled style="opacity:.6"></div>
                        <div class="form-group full" style="border-top:1px solid var(--border-color);padding-top:16px;margin-top:4px"><label style="font-size:15px;font-weight:700">Alterar Palavra-passe</label></div>
                        <div class="form-group"><label>Atual</label><input id="perfil-pw-atual" type="password" placeholder="Palavra-passe atual"></div>
                        <div class="form-group"><label>Nova</label><input id="perfil-pw-nova" type="password" placeholder="Nova (mín. 6 caracteres)"></div>
                    </div>
                    <div style="margin-top:24px">
                        <button type="submit" class="btn-primary-sm" style="width:100%;justify-content:center">
                            <i class="ph ph-floppy-disk"></i> Guardar Alterações
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>

<script src="app.js"></script>
<script>
const PREVIEW_STAFF_ID = <?= $preview_id ? (int)$preview_id : 'null' ?>;
const STAFF_QS = PREVIEW_STAFF_ID ? `?id_staff=${PREVIEW_STAFF_ID}` : '';

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', e => { e.preventDefault(); goToSection(link.dataset.section); });
});

function goToSection(section) {
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector(`[data-section="${section}"]`)?.classList.add('active');
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${section}`)?.classList.add('active');
    const loaders = {
        inicio:   inicioStaff,
        tarefas:  carregarTarefasKanban,
        eventos:  carregarEventosStaff,
        perfil:   carregarPerfil,
    };
    if (loaders[section]) loaders[section]();
}

async function inicioStaff() {
    const tarefas = await carregarEstatisticasStaff();
    const urgentes = tarefas.filter(t => t.estado !== 'concluida' && t.prioridade === 'alta').slice(0, 4);
    const lista = document.getElementById('inicio-tarefas-urgentes');
    lista.innerHTML = urgentes.length ? urgentes.map(t => `
        <div class="task-item task-priority-high">
            <div class="task-priority-stripe"></div>
            <div class="task-main">
                <div class="task-info">
                    <i class="ph ph-circle task-status-icon"></i>
                    <div><p class="task-title">${esc(t.descricao)}</p>
                    <p class="task-event-tag"><i class="ph ph-calendar-blank"></i> ${esc(t.nome_evento ?? '')}</p></div>
                </div>
                <div class="task-right">
                    <span class="badge badge-danger-soft">Alta</span>
                    <span class="task-time"><i class="ph ph-clock"></i> ${t.hora_inicio ? formatDateTime(t.hora_inicio) : '—'}</span>
                </div>
            </div>
        </div>`).join('') : '<p class="td-empty">Sem tarefas urgentes! 🎉</p>';
}

async function carregarEventosStaff() {
    const r = await API.get(`eventos.php${STAFF_QS}`);
    const grid = document.getElementById('staff-events-grid');
    if (!grid || r.status !== 'ok') return;
    grid.innerHTML = r.data.length ? r.data.map(e => `
        <div class="event-card">
            <div class="event-card-header">
                <span class="badge badge-purple">Ativo</span>
                <span class="event-role-tag"><i class="ph ph-identification-badge"></i> Staff</span>
            </div>
            <h3 class="event-name">${esc(e.nome_evento)}</h3>
            <div class="event-meta">
                <span><i class="ph ph-calendar"></i> ${formatDateSimple(e.data)}</span>
                <span><i class="ph ph-clock"></i> ${e.hora?.slice(0,5) ?? ''}</span>
                <span><i class="ph ph-map-pin"></i> ${esc(e.local ?? '')}</span>
                <span><i class="ph ph-shirt"></i> ${esc(e.dresscode ?? '')}</span>
            </div>
            <p class="event-desc">${esc(e.descricao ?? '')}</p>
            <div class="event-card-footer">
                <button class="btn-link" onclick="goToSection('tarefas')">Ver as minhas tarefas →</button>
            </div>
        </div>`).join('')
        : '<div style="padding:40px;text-align:center;color:#64748b">Sem eventos atribuídos.</div>';
}

async function carregarEstatisticasStaff() {
    const r = await API.get(`tarefas.php${STAFF_QS}`);
    const tarefas = r.status === 'ok' ? (r.data || []) : [];
    const total    = tarefas.length;
    const pendente = tarefas.filter(t => t.estado === 'pendente').length;
    const em_and   = tarefas.filter(t => t.estado === 'em_andamento').length;
    const conc     = tarefas.filter(t => t.estado === 'concluida').length;
    document.getElementById('stat-total-tasks').textContent = total;
    document.getElementById('stat-pending').textContent     = pendente;
    document.getElementById('stat-in-progress').textContent = em_and;
    document.getElementById('stat-completed').textContent   = conc;
    const pct   = total ? Math.round((conc / total) * 100) : 0;
    const bar   = document.getElementById('overall-progress-bar-fill');
    const label = document.getElementById('progress-pct-label');
    if (bar)   { bar.style.width = pct + '%'; bar.querySelector('.progress-label-inside').textContent = `${conc} / ${total} tarefas`; }
    if (label) label.textContent = pct + '% concluído';
    return tarefas;
}

async function carregarTarefasKanban() {
    const r = await API.get(`tarefas.php${STAFF_QS}`);
    const tarefas = r.status === 'ok' ? (r.data || []) : [];
    const cols = { pendente: [], em_andamento: [], concluida: [] };
    tarefas.forEach(t => { if (cols[t.estado]) cols[t.estado].push(t); });
    Object.entries(cols).forEach(([estado, lista]) => {
        const container = document.getElementById(`kanban-${estado}`);
        const counter   = document.getElementById(`kanban-count-${estado}`);
        if (counter) counter.textContent = lista.length;
        if (!container) return;
        if (!lista.length) { container.innerHTML = '<p class="td-empty" style="font-size:13px">Sem tarefas</p>'; return; }
        container.innerHTML = lista.map(t => `
            <div class="kanban-card" data-priority="${esc(t.prioridade || 'media')}" data-id="${t.id_tarefa}" style="display:flex;flex-direction:column;gap:8px;background:var(--white);border:1.5px solid var(--border-color);border-radius:12px;padding:14px;">
                <p style="font-size:14px;font-weight:600;color:var(--text-dark);margin:0">${esc(t.descricao)}</p>
                <p style="font-size:12px;color:var(--text-muted);margin:0"><i class="ph ph-calendar-blank"></i> ${esc(t.nome_evento || '—')}</p>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                    <span class="badge ${prioridadeBadge(t.prioridade)}">${t.prioridade || 'media'}</span>
                    ${t.hora_inicio ? `<span style="font-size:11px;color:var(--text-muted)"><i class="ph ph-clock"></i> ${formatDateTime(t.hora_inicio)}</span>` : ''}
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px">
                    ${PREVIEW_STAFF_ID ? '' : (estado !== 'em_andamento' ? `<button class="btn-icon" style="font-size:12px;padding:4px 10px;border-radius:8px" onclick="mudarEstadoTarefa(${t.id_tarefa},'em_andamento')"><i class="ph ph-arrow-right"></i> Iniciar</button>` : '')}
                    ${PREVIEW_STAFF_ID ? '' : (estado !== 'concluida'    ? `<button class="btn-icon" style="font-size:12px;padding:4px 10px;border-radius:8px;color:#16a34a;border-color:#16a34a" onclick="mudarEstadoTarefa(${t.id_tarefa},'concluida')"><i class="ph ph-check"></i> Concluir</button>` : '')}
                </div>
            </div>`).join('');
    });
}

async function mudarEstadoTarefa(id, estado) {
    const r = await API.put(`tarefas.php?id=${id}`, { estado });
    if (r?.status === 'ok') { carregarTarefasKanban(); carregarEstatisticasStaff(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

function filtrarKanban() {
    const prio = document.getElementById('filter-prioridade').value;
    document.querySelectorAll('.kanban-card').forEach(card => {
        card.style.display = (!prio || card.dataset.priority === prio) ? 'flex' : 'none';
    });
}

window.addEventListener('DOMContentLoaded', () => {
    inicioStaff();
    carregarTarefasKanban();
    if (!PREVIEW_STAFF_ID) {
        carregarNotificacoes();
        carregarPerfil();
    }
});
</script>
</body>
</html>
