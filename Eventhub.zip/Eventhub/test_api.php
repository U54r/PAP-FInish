<?php
// test_api.php
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';

session_start();

// Fazer login automaticamente para teste
$email = 'bruno.costa@email.com';
$password = 'org123';

$pdo = getDB();
$stmt = $pdo->prepare("SELECT u.*, r.nome_role FROM utilizador u JOIN role r ON r.id_role = u.id_role WHERE u.email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user && $user['password'] === hash('sha256', $password)) {
    $_SESSION['id_utilizador'] = $user['id_utilizador'];
    $_SESSION['nome'] = $user['nome'];
    $_SESSION['role'] = $user['nome_role'];
    echo "✅ Login automático bem-sucedido!<br>";
    echo "ID: " . $user['id_utilizador'] . "<br>";
    echo "Nome: " . $user['nome'] . "<br>";
    echo "Role: " . $user['nome_role'] . "<br><br>";
} else {
    echo "❌ Falha no login<br>";
}

// Testar API de eventos
echo "<h3>Testando API de eventos:</h3>";
$ch = curl_init('http://localhost/eventhub/eventos.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
curl_close($ch);

echo "<pre>";
print_r(json_decode($response, true));
echo "</pre>";
?>