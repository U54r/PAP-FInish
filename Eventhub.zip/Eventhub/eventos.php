<?php
// eventos.php — CRUD de Eventos
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    if ($id) {
        $role = $_SESSION['role'] ?? '';
        $uid  = (int)($_SESSION['id_utilizador'] ?? 0);
        if ($role === 'organizador') {
            $stmt = $pdo->prepare("SELECT * FROM evento WHERE id_evento = ? AND id_organizador = ?");
            $stmt->execute([$id, $uid]);
        } elseif ($role === 'cliente') {
            $stmt = $pdo->prepare("SELECT * FROM evento WHERE id_evento = ? AND id_cliente = ?");
            $stmt->execute([$id, $uid]);
        } elseif ($role === 'staff') {
            $stmt = $pdo->prepare("
                SELECT DISTINCT e.* FROM evento e
                JOIN tarefas t ON t.id_evento = e.id_evento
                WHERE e.id_evento = ? AND t.id_staff = ?
            ");
            $stmt->execute([$id, $uid]);
        } else {
            $stmt = $pdo->prepare("
                SELECT DISTINCT e.* FROM evento e
                JOIN event_guest eg ON eg.id_evento = e.id_evento
                JOIN guest g ON g.id_guest = eg.id_guest
                WHERE e.id_evento = ? AND g.email = ?
            ");
            $stmt->execute([$id, $_SESSION['email'] ?? '']);
        }
        $ev = $stmt->fetch();
        $ev ? jsonOk($ev) : jsonErro('Evento não encontrado', 404);
    }
    $role = $_SESSION['role'];
    $id_staff_filtro = (int)($_GET['id_staff'] ?? 0);
    if ($role === 'organizador' && $id_staff_filtro) {
        // Pré-visualização: eventos onde um staff específico deste organizador tem tarefas
        $stmt = $pdo->prepare("
            SELECT DISTINCT e.* FROM evento e
            JOIN tarefas t ON t.id_evento = e.id_evento
            WHERE t.id_staff = ? AND e.id_organizador = ?
            ORDER BY e.data ASC
        ");
        $stmt->execute([$id_staff_filtro, $_SESSION['id_utilizador']]);
    } elseif ($role === 'organizador') {
        $stmt = $pdo->prepare("SELECT * FROM evento WHERE id_organizador = ? ORDER BY data ASC");
        $stmt->execute([$_SESSION['id_utilizador']]);
    } elseif ($role === 'staff') {
        $stmt = $pdo->prepare("
            SELECT DISTINCT e.* FROM evento e
            JOIN tarefas t ON t.id_evento = e.id_evento
            WHERE t.id_staff = ? ORDER BY e.data ASC
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
    } else {
        // guest - vê eventos onde está convidado (via email, pois id_guest ≠ id_utilizador)
        $stmt = $pdo->prepare("
            SELECT DISTINCT e.* FROM evento e
            JOIN event_guest eg ON eg.id_evento = e.id_evento
            JOIN guest g ON g.id_guest = eg.id_guest
            WHERE g.email = ? ORDER BY e.data ASC
        ");
        $stmt->execute([$_SESSION['email'] ?? '']);
    }
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador']);
    $d = getBody();
    if (empty($d['nome_evento']) || empty($d['data']) || empty($d['hora'])) {
        jsonErro('Campos obrigatórios: nome_evento, data, hora');
    }
    $idCliente = null;
    if (!empty($d['id_cliente'])) {
        $clChk = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?");
        $clChk->execute([(int)$d['id_cliente'], $_SESSION['id_utilizador']]);
        if (!$clChk->fetch()) jsonErro('Cliente não encontrado ou sem permissão', 403);
        $idCliente = (int)$d['id_cliente'];
    }
    $stmt = $pdo->prepare("
        INSERT INTO evento (id_organizador, nome_evento, local, data, hora, dresscode, descricao, tipo_evento, id_cliente)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['id_utilizador'],
        $d['nome_evento'], $d['local'] ?? '',
        $d['data'], $d['hora'],
        $d['dresscode'] ?? '', $d['descricao'] ?? '',
        $d['tipo_evento'] ?? null,
        $idCliente,
    ]);
    $novo_id = (int)$pdo->lastInsertId();
    criarNotificacao($novo_id, $_SESSION['id_utilizador'],
        "Evento '{$d['nome_evento']}' criado com sucesso!", 'confirmacao');
    jsonOk(['id_evento' => $novo_id], 'Evento criado com sucesso');
    break;

case 'PUT':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $d = getBody();
    $idClientePut = null;
    if (!empty($d['id_cliente'])) {
        $clChkPut = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?");
        $clChkPut->execute([(int)$d['id_cliente'], $_SESSION['id_utilizador']]);
        if (!$clChkPut->fetch()) jsonErro('Cliente não encontrado ou sem permissão', 403);
        $idClientePut = (int)$d['id_cliente'];
    }
    $stmt = $pdo->prepare("
        UPDATE evento SET nome_evento=?, local=?, data=?, hora=?, dresscode=?, descricao=?,
                          tipo_evento=?, id_cliente=?
        WHERE id_evento=? AND id_organizador=?
    ");
    $stmt->execute([
        $d['nome_evento'], $d['local'] ?? '',
        $d['data'], $d['hora'],
        $d['dresscode'] ?? '', $d['descricao'] ?? '',
        $d['tipo_evento'] ?? null,
        $idClientePut,
        $id, $_SESSION['id_utilizador'],
    ]);
    criarNotificacao($id, $_SESSION['id_utilizador'],
        "Evento '{$d['nome_evento']}' foi atualizado.", 'atualizacao');
    jsonOk([], 'Evento atualizado');
    break;

case 'PATCH':
    // Atribuição/remoção rápida de cliente a um evento (sem substituir o resto dos dados)
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $d = getBody();
    if (!array_key_exists('id_cliente', $d)) jsonErro('Campo id_cliente obrigatório');
    $check = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento=? AND id_organizador=?");
    $check->execute([$id, $_SESSION['id_utilizador']]);
    if (!$check->fetch()) jsonErro('Sem permissão ou evento não encontrado', 403);
    $idClientePatch = null;
    if (!empty($d['id_cliente'])) {
        $clChkPatch = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?");
        $clChkPatch->execute([(int)$d['id_cliente'], $_SESSION['id_utilizador']]);
        if (!$clChkPatch->fetch()) jsonErro('Cliente não encontrado ou sem permissão', 403);
        $idClientePatch = (int)$d['id_cliente'];
    }
    $pdo->prepare("UPDATE evento SET id_cliente=? WHERE id_evento=? AND id_organizador=?")
        ->execute([$idClientePatch, $id, $_SESSION['id_utilizador']]);
    jsonOk([], 'Cliente atribuído ao evento');
    break;

case 'DELETE':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $check = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento=? AND id_organizador=?");
    $check->execute([$id, $_SESSION['id_utilizador']]);
    if (!$check->fetch()) jsonErro('Sem permissão ou evento não encontrado', 403);
    // Clear FK-constrained child tables before deleting the event
    $pdo->prepare("DELETE FROM notificacoes   WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM event_guest    WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_mesa    WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM tarefas        WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM qr_codes       WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_recurso WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_presente WHERE id_evento=?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento         WHERE id_evento=?")->execute([$id]);
    jsonOk([], 'Evento eliminado');
    break;
}
