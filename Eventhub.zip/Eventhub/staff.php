<?php
// staff.php — Lista staff disponível (role = staff)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireRole(['organizador']);

$pdo      = getDB();
$roleFilter = $_GET['role'] ?? 'staff';

// Allow fetching clientes (role=5) or staff (role=3) by query param
$allowedRoles = ['staff', 'cliente', 'convidado'];
if (!in_array($roleFilter, $allowedRoles)) $roleFilter = 'staff';

if ($roleFilter === 'staff') {
    // Staff linked to this organizer or assigned to their events
    $stmt = $pdo->prepare("
        SELECT u.id_utilizador, u.nome, u.email, u.telefone, u.estado_conta
        FROM utilizador u
        JOIN role r ON r.id_role = u.id_role
        WHERE r.nome_role = 'staff'
          AND (
              u.id_organizador = ?
              OR u.id_utilizador IN (
                  SELECT DISTINCT t.id_staff FROM tarefas t
                  JOIN evento e ON e.id_evento = t.id_evento
                  WHERE e.id_organizador = ?
              )
          )
        ORDER BY u.nome
    ");
    $stmt->execute([$_SESSION['id_utilizador'], $_SESSION['id_utilizador']]);
} elseif ($roleFilter === 'cliente') {
    // Clientes deste organizador, com o evento a que estão associados (se algum)
    $stmt = $pdo->prepare("
        SELECT u.id_utilizador, u.nome, u.email, u.telefone, u.estado_conta,
               (SELECT ev.id_evento FROM evento ev
                 WHERE ev.id_cliente = u.id_utilizador AND ev.id_organizador = u.id_organizador
                 ORDER BY ev.data DESC LIMIT 1) AS id_evento,
               (SELECT ev.nome_evento FROM evento ev
                 WHERE ev.id_cliente = u.id_utilizador AND ev.id_organizador = u.id_organizador
                 ORDER BY ev.data DESC LIMIT 1) AS nome_evento
        FROM utilizador u
        JOIN role r ON r.id_role = u.id_role
        WHERE r.nome_role = 'cliente'
          AND u.id_organizador = ?
        ORDER BY u.nome
    ");
    $stmt->execute([$_SESSION['id_utilizador']]);
} else {
    // Outros roles criados por este organizador
    $stmt = $pdo->prepare("
        SELECT u.id_utilizador, u.nome, u.email, u.telefone, u.estado_conta
        FROM utilizador u
        JOIN role r ON r.id_role = u.id_role
        WHERE r.nome_role = ?
          AND u.id_organizador = ?
        ORDER BY u.nome
    ");
    $stmt->execute([$roleFilter, $_SESSION['id_utilizador']]);
}
jsonOk($stmt->fetchAll());
