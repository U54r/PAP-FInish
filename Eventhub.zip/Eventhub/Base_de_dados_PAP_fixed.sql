-- =============================================================
-- INSTALAÇÃO COMPLETA (com criação da base de dados)
-- Para ser executado noutro computador ou em apresentação
-- =============================================================

-- Criar a base de dados se não existir
CREATE DATABASE IF NOT EXISTS gestao_eventos
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- Usar a base de dados
USE gestao_eventos;

-- ------------------------------------------------------------
-- Desativar verificação de chaves estrangeiras temporariamente
-- ------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Eliminar todas as tabelas (ordem correta de dependências)
-- ------------------------------------------------------------
DROP TABLE IF EXISTS event_guest;
DROP TABLE IF EXISTS evento_mesa;
DROP TABLE IF EXISTS guest_invite_tokens;
DROP TABLE IF EXISTS event_page_settings;
DROP TABLE IF EXISTS notificacoes;
DROP TABLE IF EXISTS tarefas;
DROP TABLE IF EXISTS evento_presente;
DROP TABLE IF EXISTS evento_recurso;
DROP TABLE IF EXISTS qr_codes;
DROP TABLE IF EXISTS presente;
DROP TABLE IF EXISTS recurso;
DROP TABLE IF EXISTS mesa;
DROP TABLE IF EXISTS guest;
DROP TABLE IF EXISTS evento;
DROP TABLE IF EXISTS utilizador;
DROP TABLE IF EXISTS role;

-- ------------------------------------------------------------
-- Criar tabelas
-- ------------------------------------------------------------

CREATE TABLE role (
    id_role   INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome_role VARCHAR(50) NOT NULL
);

CREATE TABLE utilizador (
    id_utilizador  INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome           VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    telefone       VARCHAR(20),
    password       VARCHAR(255) NOT NULL,
    id_role        INTEGER NOT NULL,
    id_organizador INTEGER NULL,
    estado_conta   VARCHAR(20) DEFAULT 'ativo',
    data_registo   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_role) REFERENCES role(id_role),
    FOREIGN KEY (id_organizador) REFERENCES utilizador(id_utilizador) ON DELETE SET NULL
);

CREATE TABLE evento (
    id_evento      INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_organizador INTEGER NOT NULL,
    nome_evento    VARCHAR(150) NOT NULL,
    local          VARCHAR(200),
    data           DATE NOT NULL,
    hora           TIME NOT NULL,
    dresscode      VARCHAR(50),
    descricao      TEXT,
    FOREIGN KEY (id_organizador) REFERENCES utilizador(id_utilizador)
);

CREATE TABLE qr_codes (
    id_qr          INTEGER PRIMARY KEY AUTO_INCREMENT,
    codigo         VARCHAR(255) NOT NULL UNIQUE,
    id_utilizador  INTEGER NOT NULL,
    id_evento      INTEGER NOT NULL,
    estado         VARCHAR(30) DEFAULT 'ativo',
    FOREIGN KEY (id_utilizador) REFERENCES utilizador(id_utilizador),
    FOREIGN KEY (id_evento)     REFERENCES evento(id_evento)
);

CREATE TABLE recurso (
    id_recurso       INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome             VARCHAR(150) NOT NULL,
    categoria        VARCHAR(100),
    quantidade_total INTEGER NOT NULL DEFAULT 0,
    quantidade_usada INTEGER NOT NULL DEFAULT 0,
    fornecedor       VARCHAR(150)
);

CREATE TABLE evento_recurso (
    id_evento    INTEGER NOT NULL,
    id_recurso   INTEGER NOT NULL,
    quantidade   INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (id_evento, id_recurso),
    FOREIGN KEY (id_evento)  REFERENCES evento(id_evento),
    FOREIGN KEY (id_recurso) REFERENCES recurso(id_recurso)
);

CREATE TABLE presente (
    id_presente      INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome_item        VARCHAR(150) NOT NULL,
    categoria        VARCHAR(100),
    preco_estimado   DECIMAL(10,2),
    estado           VARCHAR(30) DEFAULT 'pendente',
    id_responsavel   INTEGER,
    FOREIGN KEY (id_responsavel) REFERENCES utilizador(id_utilizador)
);

CREATE TABLE evento_presente (
    id_evento   INTEGER NOT NULL,
    id_presente INTEGER NOT NULL,
    PRIMARY KEY (id_evento, id_presente),
    FOREIGN KEY (id_evento)   REFERENCES evento(id_evento),
    FOREIGN KEY (id_presente) REFERENCES presente(id_presente)
);

CREATE TABLE tarefas (
    id_tarefa    INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_evento    INTEGER NOT NULL,
    id_staff     INTEGER NOT NULL,
    descricao    TEXT,
    hora_inicio  DATETIME,
    hora_fim     DATETIME,
    prioridade   VARCHAR(20) DEFAULT 'media',
    estado       VARCHAR(20) DEFAULT 'pendente',
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_staff)  REFERENCES utilizador(id_utilizador)
);

CREATE TABLE notificacoes (
    id_notificacao INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_evento      INTEGER NOT NULL,
    id_utilizador  INTEGER NOT NULL,
    mensagem       TEXT,
    tipo           VARCHAR(100),
    data_hora      DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_evento)     REFERENCES evento(id_evento),
    FOREIGN KEY (id_utilizador) REFERENCES utilizador(id_utilizador)
);

CREATE TABLE guest (
    id_guest   INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(120),
    telefone   VARCHAR(20)
);

CREATE TABLE mesa (
    id_mesa      INTEGER PRIMARY KEY AUTO_INCREMENT,
    numero       INTEGER NOT NULL,
    capacidade   INTEGER NOT NULL,
    localizacao  VARCHAR(100)
);

CREATE TABLE evento_mesa (
    id_evento  INTEGER NOT NULL,
    id_mesa    INTEGER NOT NULL,
    PRIMARY KEY (id_evento, id_mesa),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_mesa)   REFERENCES mesa(id_mesa)
);

CREATE TABLE event_guest (
    id_evento    INTEGER NOT NULL,
    id_guest     INTEGER NOT NULL,
    id_mesa      INTEGER,
    estado_rsvp  VARCHAR(20) DEFAULT 'pendente',
    PRIMARY KEY (id_evento, id_guest),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_guest)  REFERENCES guest(id_guest),
    FOREIGN KEY (id_mesa)   REFERENCES mesa(id_mesa)
);

CREATE TABLE event_page_settings (
    id_evento           INTEGER NOT NULL,
    layout_template     ENUM('classic','modern','elegant','rustic') NOT NULL DEFAULT 'classic',
    bg_color            VARCHAR(20),
    primary_color       VARCHAR(20),
    text_color          VARCHAR(20),
    dresscode_title     VARCHAR(150),
    dresscode_suggested TEXT,
    dresscode_avoid     TEXT,
    dresscode_palette   TEXT,
    dresscode_image1    VARCHAR(255),
    dresscode_image2    VARCHAR(255),
    dresscode_image3    VARCHAR(255),
    location_name       VARCHAR(150),
    location_address    TEXT,
    location_map_url    VARCHAR(500),
    location_parking_info TEXT,
    ceremony_time       TIME,
    reception_time      TIME,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_evento),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento) ON DELETE CASCADE
);

CREATE TABLE guest_invite_tokens (
    id_token    INTEGER NOT NULL AUTO_INCREMENT,
    id_evento   INTEGER NOT NULL,
    email       VARCHAR(120) NOT NULL,
    token       VARCHAR(64) NOT NULL,
    expires     DATETIME NOT NULL,
    used        TINYINT NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_token),
    UNIQUE KEY (token),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Inserir dados iniciais (com nomes de colunas explícitos)
-- ------------------------------------------------------------

INSERT INTO role (id_role, nome_role) VALUES
    (1, 'administrador'),
    (2, 'organizador'),
    (3, 'staff'),
    (4, 'convidado');

-- Passwords em SHA256: admin123, org123, staff123, staff456, org456
INSERT INTO utilizador (id_utilizador, nome, email, telefone, password, id_role, estado_conta) VALUES
    (1, 'Ana Silva',    'ana.silva@email.com',    '912000001', SHA2('admin123', 256), 1, 'ativo'),
    (2, 'Bruno Costa',  'bruno.costa@email.com',  '912000002', SHA2('org123',   256), 2, 'ativo'),
    (3, 'Carla Mendes', 'carla.mendes@email.com', '912000003', SHA2('staff123', 256), 3, 'ativo'),
    (4, 'David Lopes',  'david.lopes@email.com',  '912000004', SHA2('staff456', 256), 3, 'ativo'),
    (5, 'Eva Nunes',    'eva.nunes@email.com',    '912000005', SHA2('org456',   256), 2, 'ativo');

INSERT INTO evento (id_evento, id_organizador, nome_evento, local, data, hora, dresscode, descricao) VALUES
    (1, 2, 'Gala de Aniversario 2026', 'Hotel Ritz, Lisboa',         '2026-06-15', '20:00:00', 'Black Tie', 'Gala de celebracao dos 10 anos da empresa.'),
    (2, 5, 'Casamento Silva & Costa',  'Quinta das Flores, Setubal', '2026-07-20', '17:00:00', 'Formal',    'Cerimonia e jantar de casamento.'),
    (3, 2, 'Conferencia Tech 2026',    'Centro de Congressos, Porto','2026-09-05', '09:00:00', 'Business',  'Conferencia anual de tecnologia e inovacao.');

INSERT INTO recurso (id_recurso, nome, categoria, quantidade_total, quantidade_usada, fornecedor) VALUES
    (1, 'Cadeiras',           'Mobiliario',  200, 150, 'Mobirent Lda'),
    (2, 'Mesas redondas',     'Mobiliario',   30,  20, 'Mobirent Lda'),
    (3, 'Projetor HD',        'Audiovisual',   5,   2, 'AV Solutions'),
    (4, 'Microfones sem fio', 'Audiovisual',  10,   4, 'AV Solutions'),
    (5, 'Arranjos florais',   'Decoracao',    25,  10, 'Flores & Arte');

INSERT INTO evento_recurso (id_evento, id_recurso, quantidade) VALUES
    (1,1,150), (1,2,20), (1,5,15),
    (2,1,100), (2,2,12), (2,5,10),
    (3,3,2),   (3,4,4);

INSERT INTO presente (id_presente, nome_item, categoria, preco_estimado, estado, id_responsavel) VALUES
    (1, 'Quadro decorativo',    'Arte',        80.00, 'confirmado', 3),
    (2, 'Vale presente Spa',    'Bem-estar',  120.00, 'confirmado', 4),
    (3, 'Conjunto de vinhos',   'Gastronomia', 60.00, 'pendente',   3),
    (4, 'Livro de fotografias', 'Memorias',    45.00, 'pendente',   NULL);

INSERT INTO evento_presente (id_evento, id_presente) VALUES
    (2,1), (2,2), (2,3), (1,4);

INSERT INTO tarefas (id_tarefa, id_evento, id_staff, descricao, hora_inicio, hora_fim, prioridade, estado) VALUES
    (1,1,3,'Coordenar rececao de convidados','2026-06-15 19:00:00','2026-06-15 21:00:00','alta','pendente'),
    (2,1,4,'Gerir servico de mesa','2026-06-15 20:00:00','2026-06-15 23:00:00','alta','pendente'),
    (3,2,3,'Organizar flores e decoracao','2026-07-20 14:00:00','2026-07-20 17:00:00','media','pendente'),
    (4,3,4,'Configurar equipamento audiovisual','2026-09-05 07:00:00','2026-09-05 09:00:00','alta','pendente'),
    (5,3,3,'Registo e credenciacao de entradas','2026-09-05 08:30:00','2026-09-05 10:00:00','media','pendente');

INSERT INTO notificacoes (id_notificacao, id_evento, id_utilizador, mensagem, tipo, data_hora) VALUES
    (1,1,2,'O evento Gala de Aniversario foi confirmado.','confirmacao','2026-05-01 10:00:00'),
    (2,1,3,'Tens uma nova tarefa atribuida na Gala.','tarefa','2026-05-02 09:00:00'),
    (3,2,5,'O casamento foi registado com sucesso.','confirmacao','2026-05-03 11:00:00'),
    (4,3,2,'Lembrete: Conferencia Tech em 3 meses.','lembrete','2026-06-05 08:00:00');

INSERT INTO qr_codes (id_qr, codigo, id_utilizador, id_evento, estado) VALUES
    (1,'QR-EVT1-USR1-001',1,1,'ativo'),
    (2,'QR-EVT1-USR3-002',3,1,'ativo'),
    (3,'QR-EVT2-USR2-003',2,2,'ativo'),
    (4,'QR-EVT3-USR4-004',4,3,'ativo');

INSERT INTO guest (id_guest, nome, email, telefone) VALUES
    (1,'Mariana Ferreira','mariana.f@email.com','961000001'),
    (2,'Joao Rodrigues',  'joao.r@email.com',   '961000002'),
    (3,'Sofia Pinto',     'sofia.p@email.com',  '961000003'),
    (4,'Miguel Alves',    'miguel.a@email.com', '961000004'),
    (5,'Ines Carvalho',   'ines.c@email.com',   '961000005');

-- Inserção correta na tabela 'mesa' (4 colunas: id_mesa, numero, capacidade, localizacao)
INSERT INTO mesa (id_mesa, numero, capacidade, localizacao) VALUES
    (1, 1, 10, 'Sala Principal - Zona A'),
    (2, 2, 10, 'Sala Principal - Zona A'),
    (3, 3, 8,  'Sala Principal - Zona B'),
    (4, 4, 6,  'Terraco'),
    (5, 5, 6,  'Terraco');

INSERT INTO evento_mesa (id_evento, id_mesa) VALUES
    (1,1), (1,2), (1,3),
    (2,1), (2,2), (2,4), (2,5),
    (3,3), (3,4);

INSERT INTO event_guest (id_evento, id_guest, id_mesa, estado_rsvp) VALUES
    (1,1,1,'confirmado'),
    (1,2,1,'confirmado'),
    (1,3,2,'pendente'),
    (2,4,4,'confirmado'),
    (2,5,4,'confirmado'),
    (3,1,3,'pendente'),
    (3,2,3,'confirmado');

-- Garantir que todos os eventos tenham uma linha em event_page_settings
INSERT INTO event_page_settings (id_evento)
SELECT id_evento FROM evento
WHERE id_evento NOT IN (SELECT id_evento FROM event_page_settings);

-- ------------------------------------------------------------
-- Reativar verificação de chaves estrangeiras
-- ------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------
-- Mensagem de sucesso
-- ------------------------------------------------------------
SELECT '✅ Base de dados completamente criada/recriada com sucesso!' AS status;