<?php
// enviar_email_cliente.php — Envia email de acesso ao portal do cliente
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/email_helper.php';
apiHeaders();
requireRole(['organizador']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErro('Método não permitido', 405);

$d = getBody();
$id_cliente = (int)($d['id_cliente'] ?? 0);
if (!$id_cliente) jsonErro('id_cliente obrigatório');

$pdo = getDB();

// Confirm this client belongs to this organizer
$stmtCl = $pdo->prepare("
    SELECT u.*, r.nome_role
    FROM utilizador u
    JOIN role r ON r.id_role = u.id_role
    WHERE u.id_utilizador = ? AND u.id_organizador = ? AND r.nome_role = 'cliente'
");
$stmtCl->execute([$id_cliente, $_SESSION['id_utilizador']]);
$cliente = $stmtCl->fetch();
if (!$cliente) jsonErro('Cliente não encontrado ou sem permissão', 403);

// Get organizer name
$stmtOrg = $pdo->prepare("SELECT nome FROM utilizador WHERE id_utilizador = ?");
$stmtOrg->execute([$_SESSION['id_utilizador']]);
$org = $stmtOrg->fetch();
$orgName = $org['nome'] ?? 'o organizador';

// Get first upcoming event for this client
$stmtEv = $pdo->prepare("
    SELECT * FROM evento WHERE id_cliente = ? ORDER BY data ASC LIMIT 1
");
$stmtEv->execute([$id_cliente]);
$evento = $stmtEv->fetch();

$eventName  = $evento['nome_evento'] ?? 'o seu evento';
$eventDate  = $evento ? date('d/m/Y', strtotime($evento['data'])) : '—';
$eventLocal = $evento['local'] ?? '';

// Generate a fresh temporary password
$plainPwd = bin2hex(random_bytes(4)); // 8 chars
$hash     = hash('sha256', $plainPwd);

$pdo->prepare("UPDATE utilizador SET password = ? WHERE id_utilizador = ?")
    ->execute([$hash, $id_cliente]);

$ok = sendClientDashboardEmail(
    $cliente['email'],
    $cliente['nome'],
    $orgName,
    $eventName,
    $eventDate,
    $eventLocal,
    $plainPwd
);

if ($ok) {
    jsonOk(['password' => $plainPwd], 'Email enviado com sucesso para ' . $cliente['email']);
} else {
    jsonErro('Falha no envio do email. Verifique as configurações SMTP.');
}
