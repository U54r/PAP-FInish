<?php
// qrcodes.php — QR codes por convidado por evento (armazenados em event_guest.qr_code)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Add qr_code column to event_guest if it doesn't exist yet
try {
    $pdo->exec("ALTER TABLE event_guest ADD COLUMN qr_code VARCHAR(100) NULL DEFAULT NULL");
} catch (PDOException $e) {
    // Column already exists — safe to ignore
}

switch ($method) {

case 'GET':
    $idEvento = (int) ($_GET['id_evento'] ?? 0);

    if (($_SESSION['role'] ?? '') === 'cliente') {
        // Clients can only view QRs for their own events
        if (!$idEvento) jsonErro('id_evento obrigatório', 400);
        $chk = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?");
        $chk->execute([$idEvento, $_SESSION['id_utilizador']]);
        if (!$chk->fetch()) jsonErro('Sem permissão', 403);
        $stmt = $pdo->prepare("
            SELECT eg.id_guest, g.nome AS nome_guest, eg.qr_code
            FROM event_guest eg
            JOIN guest g ON g.id_guest = eg.id_guest
            WHERE eg.id_evento = ?
            ORDER BY g.nome ASC
        ");
        $stmt->execute([$idEvento]);
        jsonOk($stmt->fetchAll());
        break;
    }

    requireRole(['organizador']);

    if ($idEvento) {
        // Verify event belongs to this organizer
        $evChk = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?");
        $evChk->execute([$idEvento, $_SESSION['id_utilizador']]);
        if (!$evChk->fetch()) jsonErro('Sem permissão.', 403);
        // Return the guest list for a specific event (used by the QR modal AJAX)
        $stmt = $pdo->prepare("
            SELECT eg.id_guest, g.nome, eg.qr_code
            FROM event_guest eg
            JOIN guest g ON g.id_guest = eg.id_guest
            WHERE eg.id_evento = ?
            ORDER BY g.nome ASC
        ");
        $stmt->execute([$idEvento]);
        jsonOk($stmt->fetchAll());
        break;
    }

    // List all QR codes that have been generated for this organizer's events
    $stmt = $pdo->prepare("
        SELECT
            eg.id_guest,
            eg.id_evento,
            eg.qr_code,
            g.nome      AS nome_guest,
            e.nome_evento,
            e.data      AS data_evento
        FROM event_guest eg
        JOIN guest  g ON g.id_guest  = eg.id_guest
        JOIN evento e ON e.id_evento = eg.id_evento
        WHERE e.id_organizador = ? AND eg.qr_code IS NOT NULL
        ORDER BY e.nome_evento, g.nome ASC
    ");
    $stmt->execute([$_SESSION['id_utilizador']]);
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador']);
    $d        = getBody();
    $idEvento = (int) ($d['id_evento'] ?? 0);
    $idGuest  = (int) ($d['id_guest']  ?? 0);

    if (!$idEvento || !$idGuest) {
        jsonErro('id_evento e id_guest são obrigatórios.');
    }

    // Confirm the event belongs to this organizer and the guest is in it
    $stmtCheck = $pdo->prepare("
        SELECT eg.id_guest
        FROM event_guest eg
        JOIN evento e ON e.id_evento = eg.id_evento
        WHERE eg.id_evento = ? AND eg.id_guest = ? AND e.id_organizador = ?
    ");
    $stmtCheck->execute([$idEvento, $idGuest, $_SESSION['id_utilizador']]);
    if (!$stmtCheck->fetch()) {
        jsonErro('Evento ou convidado não encontrado.', 403);
    }

    // Generate unique code: QR-EVT{id_evento}-GST{id_guest}-{RANDOM6}
    $chars   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $random  = '';
    for ($i = 0; $i < 6; $i++) {
        $random .= $chars[random_int(0, strlen($chars) - 1)];
    }
    $codigo = "QR-EVT{$idEvento}-GST{$idGuest}-{$random}";

    $pdo->prepare("
        UPDATE event_guest SET qr_code = ?
        WHERE id_evento = ? AND id_guest = ?
    ")->execute([$codigo, $idEvento, $idGuest]);

    jsonOk(['codigo' => $codigo], 'QR Code gerado');
    break;

case 'DELETE':
    requireRole(['organizador']);
    $idEvento = (int) ($_GET['id_evento'] ?? 0);
    $idGuest  = (int) ($_GET['id_guest']  ?? 0);

    if (!$idEvento || !$idGuest) {
        jsonErro('id_evento e id_guest são obrigatórios.');
    }

    $delChk = $pdo->prepare("
        SELECT eg.id_guest FROM event_guest eg
        JOIN evento e ON e.id_evento = eg.id_evento
        WHERE eg.id_evento = ? AND eg.id_guest = ? AND e.id_organizador = ?
    ");
    $delChk->execute([$idEvento, $idGuest, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);

    $pdo->prepare("
        UPDATE event_guest SET qr_code = NULL
        WHERE id_evento = ? AND id_guest = ?
    ")->execute([$idEvento, $idGuest]);

    jsonOk([], 'QR Code eliminado');
    break;
}
