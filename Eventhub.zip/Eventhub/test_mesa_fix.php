<?php
/**
 * Test script to verify mesa dropdown and convidados fixes
 * Run: http://localhost/Eventhub/test_mesa_fix.php
 */

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

require_once __DIR__ . '/db.php';

$pdo = getDB();

// Test 1: Check if we have test data
echo "=== TEST 1: Checking Database ===\n";
$stmt = $pdo->query("SELECT COUNT(*) as cnt FROM evento");
$eventos = $stmt->fetch()['cnt'];
echo "Total eventos: $eventos\n";

$stmt = $pdo->query("SELECT COUNT(*) as cnt FROM mesa");
$mesas = $stmt->fetch()['cnt'];
echo "Total mesas: $mesas\n";

$stmt = $pdo->query("SELECT COUNT(*) as cnt FROM guest");
$guests = $stmt->fetch()['cnt'];
echo "Total guests: $guests\n";

echo "\n=== TEST 2: Get All Mesas (for Mesas tab) ===\n";
$stmt = $pdo->query("
    SELECT m.*,
           GROUP_CONCAT(e.nome_evento) AS nome_evento
    FROM mesa m
    LEFT JOIN evento_mesa em ON em.id_mesa = m.id_mesa
    LEFT JOIN evento e ON e.id_evento = em.id_evento
    GROUP BY m.id_mesa
    ORDER BY m.numero
");
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(['status' => 'ok', 'count' => count($result), 'data' => $result], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

echo "\n\n=== TEST 3: Get Mesas for First Event ===\n";
$stmt = $pdo->query("SELECT id_evento FROM evento LIMIT 1");
$firstEvent = $stmt->fetch();
if ($firstEvent) {
    $id_evento = $firstEvent['id_evento'];
    echo "Testing with evento ID: $id_evento\n";
    
    $stmt = $pdo->prepare("
        SELECT m.id_mesa, m.numero, m.capacidade, m.localizacao,
               (SELECT COUNT(*) FROM event_guest eg
                WHERE eg.id_mesa = m.id_mesa AND eg.id_evento = ?) AS ocupacao
        FROM evento_mesa em
        JOIN mesa m ON m.id_mesa = em.id_mesa
        WHERE em.id_evento = ?
        ORDER BY m.numero
    ");
    $stmt->execute([$id_evento, $id_evento]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'ok', 'count' => count($result), 'data' => $result], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo "No events found\n";
}

echo "\n\n=== TEST 4: Get All Guests ===\n";
$stmt = $pdo->prepare("
    SELECT
         eg.id_guest,
         eg.estado_rsvp,
         eg.id_mesa,
         g.nome,
         g.email,
         g.telefone,
         e.nome_evento,
         m.numero as num_mesa
     FROM event_guest eg
     JOIN guest g ON g.id_guest = eg.id_guest
     JOIN evento e ON e.id_evento = eg.id_evento
     LEFT JOIN mesa m ON m.id_mesa = eg.id_mesa
     ORDER BY e.nome_evento, g.nome ASC
");
$stmt->execute([]);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(['status' => 'ok', 'count' => count($result), 'data' => $result], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
