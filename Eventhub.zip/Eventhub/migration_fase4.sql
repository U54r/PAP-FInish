-- ═══════════════════════════════════════════════════════════
--  FASE 4 — Migração da base de dados
--  Execute este ficheiro UMA VEZ no MySQL/MariaDB
-- ═══════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS `event_page_settings` (
    `id`                    INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `id_evento`             INT UNSIGNED     NOT NULL,

    -- Aparência
    `layout_template`       VARCHAR(20)      NOT NULL DEFAULT 'classic'
                            COMMENT 'classic | modern | elegant | rustic',
    `bg_color`              VARCHAR(7)       NOT NULL DEFAULT '#faf7f2',
    `primary_color`         VARCHAR(7)       NOT NULL DEFAULT '#c9a96e',
    `text_color`            VARCHAR(7)       NOT NULL DEFAULT '#2c2416',

    -- Dress Code
    `dresscode_title`       VARCHAR(100)     NOT NULL DEFAULT 'Formal',
    `dresscode_suggested`   TEXT,
    `dresscode_avoid`       TEXT,
    `dresscode_palette`     TEXT,
    `dresscode_image1`      VARCHAR(500),
    `dresscode_image2`      VARCHAR(500),
    `dresscode_image3`      VARCHAR(500),

    -- Localização
    `location_name`         VARCHAR(200),
    `location_address`      TEXT,
    `location_map_url`      VARCHAR(1000),
    `location_parking_info` TEXT,

    -- Horários
    `ceremony_time`         TIME,
    `reception_time`        TIME,

    -- Meta
    `created_at`            TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`            TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_evento` (`id_evento`),
    CONSTRAINT `fk_eps_evento`
        FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id_evento`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
