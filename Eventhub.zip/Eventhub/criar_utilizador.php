<?php
// criar_utilizador.php — Permite ao organizador criar staff ou convidados com conta
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireRole(['organizador']); // só organizadores podem usar

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) jsonErro('ID obrigatório');

    // Só pode eliminar contas (staff/cliente/convidado) criadas por este organizador
    $chk = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?");
    $chk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$chk->fetch()) jsonErro('Utilizador não encontrado ou sem permissão', 403);

    // Limpar referências noutras tabelas antes de eliminar (evita erros de FK)
    $pdo->prepare("DELETE FROM notificacoes WHERE id_utilizador = ?")->execute([$id]);
    $pdo->prepare("UPDATE presente SET id_responsavel = NULL WHERE id_responsavel = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM tarefas WHERE id_staff = ?")->execute([$id]);
    $pdo->prepare("UPDATE evento SET id_cliente = NULL WHERE id_cliente = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM utilizador WHERE id_utilizador = ?")->execute([$id]);

    jsonOk([], 'Utilizador eliminado');
}

if ($method !== 'POST') {
    jsonErro('Método não permitido', 405);
}

$d        = getBody();
$nome     = trim($d['nome']     ?? '');
$email    = trim($d['email']    ?? '');
$telefone = trim($d['telefone'] ?? '');
$role     = trim($d['role']     ?? ''); // 'staff' ou 'convidado'
$password = $d['password'] ?? '';

if (!$nome || !$email) {
    jsonErro('Nome e email são obrigatórios');
}
if (!in_array($role, ['staff', 'convidado', 'cliente'])) {
    jsonErro('Role inválido. Use staff, convidado ou cliente');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonErro('Email inválido');
}

// Buscar id_role a partir da tabela role
$stmtRole = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = ?");
$stmtRole->execute([$role]);
$roleRow = $stmtRole->fetch();
if (!$roleRow) jsonErro('Role não encontrado na base de dados');
$roleId = $roleRow['id_role'];

// Verificar se email já existe
$check = $pdo->prepare("SELECT id_utilizador, id_organizador FROM utilizador WHERE email = ?");
$check->execute([$email]);
$existing = $check->fetch();

if ($existing) {
    // Permitir upsert apenas se a conta pertence a este organizador
    // (convidado criado por este org pode ser promovido a cliente/staff)
    if ((int)($existing['id_organizador'] ?? 0) !== (int)$_SESSION['id_utilizador']) {
        jsonErro('Este email pertence a uma conta de outro perfil.');
    }
    // Só altera a password se uma nova tiver sido explicitamente fornecida,
    // para não revogar silenciosamente o acesso ao editar nome/telefone
    if ($password !== '') {
        $pdo->prepare("
            UPDATE utilizador SET nome=?, telefone=?, id_role=?, password=?, estado_conta='ativo'
            WHERE id_utilizador=?
        ")->execute([$nome, $telefone ?: null, $roleId, hash('sha256', $password), $existing['id_utilizador']]);
    } else {
        $pdo->prepare("
            UPDATE utilizador SET nome=?, telefone=?, id_role=?, estado_conta='ativo'
            WHERE id_utilizador=?
        ")->execute([$nome, $telefone ?: null, $roleId, $existing['id_utilizador']]);
    }

    jsonOk([
        'id_utilizador' => (int)$existing['id_utilizador'],
        'password'      => null,
    ], "Conta atualizada com sucesso");
}

// Gerar password se não for fornecida (apenas para contas novas)
$passwordGerada = null;
if (empty($password)) {
    $passwordGerada = bin2hex(random_bytes(4)); // 8 caracteres hex
    $password       = $passwordGerada;
}
$hash = hash('sha256', $password);

$stmt = $pdo->prepare("
    INSERT INTO utilizador (nome, email, telefone, password, id_role, id_organizador, estado_conta, data_registo)
    VALUES (?, ?, ?, ?, ?, ?, 'ativo', NOW())
");
$stmt->execute([
    $nome,
    $email,
    $telefone ?: null,
    $hash,
    $roleId,
    $_SESSION['id_utilizador']
]);

$novoId = $pdo->lastInsertId();

jsonOk([
    'id_utilizador' => (int)$novoId,
    'password'      => $passwordGerada,
], "Utilizador criado com sucesso");
