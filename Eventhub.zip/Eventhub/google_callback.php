<?php
/**
 * google_callback.php
 * 
 * Google OAuth 2.0 Callback Handler
 * 
 * This file handles the redirect from Google after the user grants permission.
 * It exchanges the authorization code for an access token, retrieves user info,
 * and either logs in an existing user or creates a new one.
 */

// Start session FIRST before any requires
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/google_auth.php';

// ============================================================================
// 1. Check for errors from Google
// ============================================================================
if (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
    $error_description = htmlspecialchars($_GET['error_description'] ?? '');
    error_log("[EventHub Google OAuth] Error from Google: $error - $error_description");
    header('Location: login.php?erro=google_' . urlencode($error));
    exit;
}

// ============================================================================
// 2. Check for authorization code
// ============================================================================
if (!isset($_GET['code'])) {
    error_log('[EventHub Google OAuth] No authorization code received');
    header('Location: login.php?erro=google_no_code');
    exit;
}

$code = $_GET['code'];

// Require state parameter for CSRF protection
if (!isset($_GET['state']) || !validateState($_GET['state'])) {
    error_log('[EventHub Google OAuth] Missing or invalid state parameter (possible CSRF attack)');
    header('Location: login.php?erro=google_csrf');
    exit;
}

// ============================================================================
// 3. Exchange authorization code for access token
// ============================================================================
$tokenData = exchangeCodeForToken($code);
if (!$tokenData || !isset($tokenData['access_token'])) {
    error_log('[EventHub Google OAuth] Failed to exchange code for token');
    header('Location: login.php?erro=google_token');
    exit;
}

$accessToken = $tokenData['access_token'];

// ============================================================================
// 4. Get user information from Google
// ============================================================================
$googleUser = getGoogleUserInfo($accessToken);
if (!$googleUser || !isset($googleUser['id'], $googleUser['email'])) {
    error_log('[EventHub Google OAuth] Failed to get user info or missing required fields');
    header('Location: login.php?erro=google_user_info');
    exit;
}

$googleId    = $googleUser['id'];
$email       = $googleUser['email'];
$name        = $googleUser['name'] ?? explode('@', $email)[0];
$picture     = $googleUser['picture'] ?? null;

// ============================================================================
// 5. Find or create user in database
// ============================================================================
try {
    $pdo = getDB();
    
    // Try to find by google_id first (most reliable)
    $stmt = $pdo->prepare(
        "SELECT u.*, r.nome_role
         FROM utilizador u
         INNER JOIN role r ON r.id_role = u.id_role
         WHERE u.google_id = ? AND u.estado_conta = 'ativo'
         LIMIT 1"
    );
    $stmt->execute([$googleId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // If not found by google_id, try by email
    if (!$user) {
        $stmt = $pdo->prepare(
            "SELECT u.*, r.nome_role
             FROM utilizador u
             INNER JOIN role r ON r.id_role = u.id_role
             WHERE u.email = ? AND u.estado_conta = 'ativo'
             LIMIT 1"
        );
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // If found by email, update with google_id
        if ($user) {
            $stmt = $pdo->prepare("UPDATE utilizador SET google_id = ? WHERE id_utilizador = ?");
            $stmt->execute([$googleId, $user['id_utilizador']]);
        }
    }

    // If still not found, create new user as organizador
    if (!$user) {
        // Get the organizador role ID
        $stmt = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = 'organizador' LIMIT 1");
        $stmt->execute();
        $roleRow = $stmt->fetch(PDO::FETCH_ASSOC);
        $organizadorRoleId = $roleRow['id_role'] ?? 2; // Default to 2 if not found

        // Generate a secure random password (user won't need it)
        $randomPassword = bin2hex(random_bytes(16));
        $passwordHash = hash('sha256', $randomPassword);

        // Create new user
        $stmt = $pdo->prepare(
            "INSERT INTO utilizador (nome, email, password, id_role, google_id, estado_conta, data_registo)
             VALUES (?, ?, ?, ?, ?, 'ativo', NOW())"
        );
        $stmt->execute([$name, $email, $passwordHash, $organizadorRoleId, $googleId]);
        $userId = $pdo->lastInsertId();

        // Retrieve the newly created user
        $stmt = $pdo->prepare(
            "SELECT u.*, r.nome_role
             FROM utilizador u
             INNER JOIN role r ON r.id_role = u.id_role
             WHERE u.id_utilizador = ?"
        );
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Log the new user creation
        error_log("[EventHub Google OAuth] New user created: $email (ID: $userId, Role: organizador)");
    }

    if (!$user) {
        throw new Exception('User creation/retrieval failed');
    }

} catch (Exception $e) {
    error_log('[EventHub Google OAuth] Database error: ' . $e->getMessage());
    header('Location: login.php?erro=google_db');
    exit;
}

// ============================================================================
// 6. Regenerate session ID and start session (security best practice)
// ============================================================================
session_regenerate_id(true);

// ============================================================================
// 7. Set session variables (same as normal login)
// ============================================================================
$_SESSION['id_utilizador'] = $user['id_utilizador'];
$_SESSION['nome']          = $user['nome'];
$_SESSION['email']         = $user['email'];
$_SESSION['role']          = $user['nome_role'];
$_SESSION['id_role']       = $user['id_role'];
$_SESSION['user']          = $user;
$_SESSION['google_login']  = true;

// Store access token in session (optional, for future API calls)
$_SESSION['google_access_token'] = $accessToken;

// ============================================================================
// 8. Redirect to dashboard based on role
// ============================================================================
$role = $user['nome_role'];

if ($role === 'organizador' || $role === 'administrador') {
    header('Location: dashboard.php?msg=google_login');
} elseif ($role === 'staff') {
    header('Location: staff-dashboard.php?msg=google_login');
} else {
    header('Location: guest.php?msg=google_login');
}

exit;
