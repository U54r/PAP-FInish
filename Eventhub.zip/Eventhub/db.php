<?php
// ============================================================
// db.php — Ligação à base de dados + criação automática
// Cria a base de dados e todas as tabelas automaticamente
// na primeira vez que o projeto é executado.
// ============================================================

define('DB_HOST',    'localhost');
define('DB_NAME',    'gestao_eventos');
define('DB_USER',    'root');
define('DB_PASS',    '');          // XAMPP: password vazia por defeito
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    try {
        // ── Passo 1: liga SEM especificar a base de dados ──────────
        // Isto permite criar a BD se ela não existir ainda
        $pdoRoot = new PDO(
            'mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET,
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        // ── Passo 2: cria a base de dados se não existir ───────────
        $pdoRoot->exec(
            "CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "`
             CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        );
        $pdoRoot->exec("USE `" . DB_NAME . "`");

        // ── Passo 3: cria todas as tabelas se não existirem ────────
        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `role` (
                `id_role`   INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome_role` VARCHAR(50) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `utilizador` (
                `id_utilizador` INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome`          VARCHAR(100) NOT NULL,
                `email`         VARCHAR(120) NOT NULL UNIQUE,
                `telefone`      VARCHAR(20),
                `password`      VARCHAR(255) NOT NULL,
                `id_role`       INTEGER NOT NULL,
                `estado_conta`  VARCHAR(20) DEFAULT 'ativo',
                `data_registo`  DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`id_role`) REFERENCES `role`(`id_role`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `evento` (
                `id_evento`      INTEGER PRIMARY KEY AUTO_INCREMENT,
                `id_organizador` INTEGER NOT NULL,
                `nome_evento`    VARCHAR(150) NOT NULL,
                `local`          VARCHAR(200),
                `data`           DATE NOT NULL,
                `hora`           TIME NOT NULL,
                `dresscode`      VARCHAR(50),
                `descricao`      TEXT,
                FOREIGN KEY (`id_organizador`) REFERENCES `utilizador`(`id_utilizador`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `qr_codes` (
                `id_qr`         INTEGER PRIMARY KEY AUTO_INCREMENT,
                `codigo`        VARCHAR(255) NOT NULL UNIQUE,
                `id_utilizador` INTEGER NOT NULL,
                `id_evento`     INTEGER NOT NULL,
                `estado`        VARCHAR(30) DEFAULT 'ativo',
                FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador`(`id_utilizador`),
                FOREIGN KEY (`id_evento`)     REFERENCES `evento`(`id_evento`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `recurso` (
                `id_recurso`       INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome`             VARCHAR(150) NOT NULL,
                `categoria`        VARCHAR(100),
                `quantidade_total` INTEGER NOT NULL DEFAULT 0,
                `quantidade_usada` INTEGER NOT NULL DEFAULT 0,
                `fornecedor`       VARCHAR(150)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `evento_recurso` (
                `id_evento`  INTEGER NOT NULL,
                `id_recurso` INTEGER NOT NULL,
                `quantidade` INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (`id_evento`, `id_recurso`),
                FOREIGN KEY (`id_evento`)  REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_recurso`) REFERENCES `recurso`(`id_recurso`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `presente` (
                `id_presente`    INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome_item`      VARCHAR(150) NOT NULL,
                `categoria`      VARCHAR(100),
                `preco_estimado` DECIMAL(10,2),
                `estado`         VARCHAR(30) DEFAULT 'pendente',
                `id_responsavel` INTEGER,
                FOREIGN KEY (`id_responsavel`) REFERENCES `utilizador`(`id_utilizador`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `evento_presente` (
                `id_evento`   INTEGER NOT NULL,
                `id_presente` INTEGER NOT NULL,
                PRIMARY KEY (`id_evento`, `id_presente`),
                FOREIGN KEY (`id_evento`)   REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_presente`) REFERENCES `presente`(`id_presente`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `tarefas` (
                `id_tarefa`   INTEGER PRIMARY KEY AUTO_INCREMENT,
                `id_evento`   INTEGER NOT NULL,
                `id_staff`    INTEGER NOT NULL,
                `descricao`   TEXT,
                `hora_inicio` DATETIME,
                `hora_fim`    DATETIME,
                `prioridade`  VARCHAR(20) DEFAULT 'media',
                `estado`      VARCHAR(20) DEFAULT 'pendente',
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_staff`)  REFERENCES `utilizador`(`id_utilizador`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `notificacoes` (
                `id_notificacao` INTEGER PRIMARY KEY AUTO_INCREMENT,
                `id_evento`      INTEGER NOT NULL,
                `id_utilizador`  INTEGER NOT NULL,
                `mensagem`       TEXT,
                `tipo`           VARCHAR(100),
                `data_hora`      DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`id_evento`)     REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_utilizador`) REFERENCES `utilizador`(`id_utilizador`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `guest` (
                `id_guest`  INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome`      VARCHAR(100) NOT NULL,
                `email`     VARCHAR(120),
                `telefone`  VARCHAR(20)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `mesa` (
                `id_mesa`     INTEGER PRIMARY KEY AUTO_INCREMENT,
                `numero`      INTEGER NOT NULL,
                `capacidade`  INTEGER NOT NULL,
                `localizacao` VARCHAR(100)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `evento_mesa` (
                `id_evento` INTEGER NOT NULL,
                `id_mesa`   INTEGER NOT NULL,
                PRIMARY KEY (`id_evento`, `id_mesa`),
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_mesa`)   REFERENCES `mesa`(`id_mesa`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `event_guest` (
                `id_evento`  INTEGER NOT NULL,
                `id_guest`   INTEGER NOT NULL,
                `id_mesa`    INTEGER,
                `estado_rsvp` VARCHAR(20) DEFAULT 'pendente',
                PRIMARY KEY (`id_evento`, `id_guest`),
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`),
                FOREIGN KEY (`id_guest`)  REFERENCES `guest`(`id_guest`),
                FOREIGN KEY (`id_mesa`)   REFERENCES `mesa`(`id_mesa`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `guest_invite_tokens` (
                `id_token`   INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `id_evento`  INTEGER NOT NULL,
                `email`      VARCHAR(120) NOT NULL,
                `token`      VARCHAR(64) NOT NULL UNIQUE,
                `expires`    DATETIME NOT NULL,
                `used`       TINYINT NOT NULL DEFAULT 0,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `event_page_settings` (
                `id_evento`           INTEGER NOT NULL PRIMARY KEY,
                `layout_template`     ENUM('classic','modern','elegant','rustic') NOT NULL DEFAULT 'classic',
                `bg_color`            VARCHAR(20),
                `primary_color`       VARCHAR(20),
                `text_color`          VARCHAR(20),
                `dresscode_title`     VARCHAR(150),
                `dresscode_suggested` TEXT,
                `dresscode_avoid`     TEXT,
                `dresscode_palette`   TEXT,
                `dresscode_image1`    VARCHAR(255),
                `dresscode_image2`    VARCHAR(255),
                `dresscode_image3`    VARCHAR(255),
                `location_name`       VARCHAR(150),
                `location_address`    TEXT,
                `location_map_url`    VARCHAR(500),
                `location_parking_info` TEXT,
                `ceremony_time`       TIME,
                `reception_time`      TIME,
                `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // ── Tabela: fornecedor ─────────────────────────────────────────────
        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `fornecedor` (
                `id_fornecedor`  INTEGER PRIMARY KEY AUTO_INCREMENT,
                `nome`           VARCHAR(150) NOT NULL,
                `categoria`      VARCHAR(100),
                `contacto`       VARCHAR(150),
                `telefone`       VARCHAR(30),
                `email`          VARCHAR(150),
                `observacoes`    TEXT,
                `id_organizador` INTEGER NULL,
                FOREIGN KEY (`id_organizador`) REFERENCES `utilizador`(`id_utilizador`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // ── Tabela: decoracao ──────────────────────────────────────────────
        $pdoRoot->exec("
            CREATE TABLE IF NOT EXISTS `decoracao` (
                `id_decoracao`   INTEGER PRIMARY KEY AUTO_INCREMENT,
                `id_evento`      INTEGER NOT NULL,
                `tipo`           VARCHAR(100) NOT NULL,
                `descricao`      TEXT,
                `fornecedor`     VARCHAR(150),
                `quantidade`     INTEGER DEFAULT 1,
                `preco_unitario` DECIMAL(10,2),
                `data_entrega`   DATE,
                `estado`         VARCHAR(50) DEFAULT 'pendente',
                `tema`           VARCHAR(100),
                FOREIGN KEY (`id_evento`) REFERENCES `evento`(`id_evento`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");

        // ── Add missing columns for future features ─────────────────────────
        $pdoRoot->exec("ALTER TABLE `utilizador` ADD COLUMN IF NOT EXISTS `id_organizador` INTEGER NULL");
        $pdoRoot->exec("ALTER TABLE `utilizador` ADD COLUMN IF NOT EXISTS `google_id` VARCHAR(100) NULL");
        $pdoRoot->exec("ALTER TABLE `evento` ADD COLUMN IF NOT EXISTS `capa_evento` VARCHAR(500) NULL");
        // Event type (wedding, baby shower, etc.) and client link
        $pdoRoot->exec("ALTER TABLE `evento` ADD COLUMN IF NOT EXISTS `tipo_evento` VARCHAR(80) NULL");
        $pdoRoot->exec("ALTER TABLE `evento` ADD COLUMN IF NOT EXISTS `id_cliente` INTEGER NULL");
        // Mesa: name, position, shape for visual floor plan
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `nome` VARCHAR(100) NULL");
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `pos_x` INTEGER DEFAULT 80");
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `pos_y` INTEGER DEFAULT 80");
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `forma` VARCHAR(20) DEFAULT 'round'");
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `cor_toalha` VARCHAR(50) DEFAULT 'teal'");
        $pdoRoot->exec("ALTER TABLE `mesa` ADD COLUMN IF NOT EXISTS `tamanho` INTEGER DEFAULT 2");
        // Recurso: delivery and deadline tracking
        $pdoRoot->exec("ALTER TABLE `recurso` ADD COLUMN IF NOT EXISTS `data_entrega` DATE NULL");
        $pdoRoot->exec("ALTER TABLE `recurso` ADD COLUMN IF NOT EXISTS `prazo_confirmacao` DATE NULL");
        $pdoRoot->exec("ALTER TABLE `recurso` ADD COLUMN IF NOT EXISTS `estado_entrega` VARCHAR(50) DEFAULT 'pendente'");
        $pdoRoot->exec("ALTER TABLE `recurso` ADD COLUMN IF NOT EXISTS `id_organizador` INTEGER NULL DEFAULT NULL");
        // QR code per guest-event association (used by guest.php for check-in)
        $pdoRoot->exec("ALTER TABLE `event_guest` ADD COLUMN IF NOT EXISTS `qr_code` VARCHAR(255) NULL");
        // Recurso / Decoracao: link to dedicated fornecedor table
        $pdoRoot->exec("ALTER TABLE `recurso` ADD COLUMN IF NOT EXISTS `id_fornecedor` INTEGER NULL");
        $pdoRoot->exec("ALTER TABLE `decoracao` ADD COLUMN IF NOT EXISTS `id_fornecedor` INTEGER NULL");

        // Add foreign key constraint for id_organizador (with try-catch for compatibility)
        try {
            $pdoRoot->exec("ALTER TABLE `utilizador` ADD CONSTRAINT `fk_utilizador_organizador` FOREIGN KEY (`id_organizador`) REFERENCES `utilizador`(`id_utilizador`) ON DELETE SET NULL");
        } catch (Exception $e) {
            // Constraint may already exist - that's fine
        }
        // FK for evento.id_cliente
        try {
            $pdoRoot->exec("ALTER TABLE `evento` ADD CONSTRAINT `fk_evento_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `utilizador`(`id_utilizador`) ON DELETE SET NULL");
        } catch (Exception $e) { /* already exists */ }
        // FK for recurso.id_fornecedor / decoracao.id_fornecedor
        try {
            $pdoRoot->exec("ALTER TABLE `recurso` ADD CONSTRAINT `fk_recurso_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `fornecedor`(`id_fornecedor`) ON DELETE SET NULL");
        } catch (Exception $e) { /* already exists */ }
        try {
            $pdoRoot->exec("ALTER TABLE `decoracao` ADD CONSTRAINT `fk_decoracao_fornecedor` FOREIGN KEY (`id_fornecedor`) REFERENCES `fornecedor`(`id_fornecedor`) ON DELETE SET NULL");
        } catch (Exception $e) { /* already exists */ }

        // ── Migração: converte texto livre 'fornecedor' em registos da tabela fornecedor ──
        $temColunaTextoRecurso = $pdoRoot->query("SHOW COLUMNS FROM `recurso` LIKE 'fornecedor'")->fetch();
        if ($temColunaTextoRecurso) {
            $pdoRoot->exec("
                INSERT INTO `fornecedor` (nome, id_organizador)
                SELECT DISTINCT r.fornecedor, r.id_organizador FROM `recurso` r
                WHERE r.fornecedor IS NOT NULL AND r.fornecedor <> ''
                AND NOT EXISTS (SELECT 1 FROM `fornecedor` f WHERE f.nome = r.fornecedor COLLATE utf8mb4_unicode_ci)
            ");
            $pdoRoot->exec("
                UPDATE `recurso` r JOIN `fornecedor` f ON f.nome = r.fornecedor COLLATE utf8mb4_unicode_ci
                SET r.id_fornecedor = f.id_fornecedor
                WHERE r.fornecedor IS NOT NULL AND r.fornecedor <> ''
            ");
            $pdoRoot->exec("ALTER TABLE `recurso` DROP COLUMN `fornecedor`");
        }
        $temColunaTextoDecoracao = $pdoRoot->query("SHOW COLUMNS FROM `decoracao` LIKE 'fornecedor'")->fetch();
        if ($temColunaTextoDecoracao) {
            $pdoRoot->exec("
                INSERT INTO `fornecedor` (nome)
                SELECT DISTINCT d.fornecedor FROM `decoracao` d
                WHERE d.fornecedor IS NOT NULL AND d.fornecedor <> ''
                AND NOT EXISTS (SELECT 1 FROM `fornecedor` f WHERE f.nome = d.fornecedor)
            ");
            $pdoRoot->exec("
                UPDATE `decoracao` d JOIN `fornecedor` f ON f.nome = d.fornecedor
                SET d.id_fornecedor = f.id_fornecedor
                WHERE d.fornecedor IS NOT NULL AND d.fornecedor <> ''
            ");
            $pdoRoot->exec("ALTER TABLE `decoracao` DROP COLUMN `fornecedor`");
        }

        // ── Passo 4: insere dados iniciais se a tabela role estiver vazia ─
        $count = $pdoRoot->query("SELECT COUNT(*) FROM `role`")->fetchColumn();
        if ((int)$count === 0) {
            $pdoRoot->exec("
                INSERT INTO `role` (nome_role) VALUES
                    ('administrador'),
                    ('organizador'),
                    ('staff'),
                    ('convidado'),
                    ('cliente');
            ");
        } else {
            // Ensure cliente role exists (for existing DBs)
            $roleCheck = $pdoRoot->query("SELECT COUNT(*) FROM `role` WHERE nome_role='cliente'")->fetchColumn();
            if ((int)$roleCheck === 0) {
                $pdoRoot->exec("INSERT INTO `role` (nome_role) VALUES ('cliente')");
            }
        }
        $count2 = $pdoRoot->query("SELECT COUNT(*) FROM `utilizador`")->fetchColumn();
        if ((int)$count2 === 0) {

            // Utilizadores de demonstração
            $pdoRoot->exec("
                INSERT INTO `utilizador` (nome, email, telefone, password, id_role, estado_conta) VALUES
                    ('Ana Silva',    'ana.silva@email.com',    '912000001', SHA2('admin123', 256), 1, 'ativo'),
                    ('Bruno Costa',  'bruno.costa@email.com',  '912000002', SHA2('org123',   256), 2, 'ativo'),
                    ('Carla Mendes', 'carla.mendes@email.com', '912000003', SHA2('staff123', 256), 3, 'ativo'),
                    ('David Lopes',  'david.lopes@email.com',  '912000004', SHA2('staff456', 256), 3, 'ativo'),
                    ('Eva Nunes',    'eva.nunes@email.com',    '912000005', SHA2('org456',   256), 2, 'ativo');
            ");

            // Eventos de demonstração
            $pdoRoot->exec("
                INSERT INTO `evento` (id_organizador, nome_evento, local, data, hora, dresscode, descricao) VALUES
                    (2, 'Gala de Aniversario 2026', 'Hotel Ritz, Lisboa',          '2026-06-15', '20:00:00', 'Black Tie', 'Gala de celebracao dos 10 anos da empresa.'),
                    (5, 'Casamento Silva & Costa',  'Quinta das Flores, Setubal',  '2026-07-20', '17:00:00', 'Formal',    'Cerimonia e jantar de casamento.'),
                    (2, 'Conferencia Tech 2026',    'Centro de Congressos, Porto', '2026-09-05', '09:00:00', 'Business',  'Conferencia anual de tecnologia e inovacao.');
            ");

            $pdoRoot->exec("
                INSERT INTO `fornecedor` (nome, categoria, id_organizador) VALUES
                    ('Mobirent Lda',  'Mobiliario',  2),
                    ('AV Solutions',  'Audiovisual', 2),
                    ('Flores & Arte', 'Decoracao',   2);
            ");

            $pdoRoot->exec("
                INSERT INTO `recurso` (nome, categoria, quantidade_total, quantidade_usada, id_fornecedor, id_organizador) VALUES
                    ('Cadeiras',           'Mobiliario',  200, 150, 1, 2),
                    ('Mesas redondas',     'Mobiliario',   30,  20, 1, 2),
                    ('Projetor HD',        'Audiovisual',   5,   2, 2, 2),
                    ('Microfones sem fio', 'Audiovisual',  10,   4, 2, 2),
                    ('Arranjos florais',   'Decoracao',    25,  10, 3, 2);
            ");

            $pdoRoot->exec("
                INSERT INTO `evento_recurso` (id_evento, id_recurso, quantidade) VALUES
                    (1,1,150),(1,2,20),(1,5,15),
                    (2,1,100),(2,2,12),(2,5,10),
                    (3,3,2),(3,4,4);
            ");

            $pdoRoot->exec("
                INSERT INTO `presente` (nome_item, categoria, preco_estimado, estado, id_responsavel) VALUES
                    ('Quadro decorativo',    'Arte',        80.00, 'confirmado', 3),
                    ('Vale presente Spa',    'Bem-estar',  120.00, 'confirmado', 4),
                    ('Conjunto de vinhos',   'Gastronomia', 60.00, 'pendente',   3),
                    ('Livro de fotografias', 'Memorias',    45.00, 'pendente',   NULL);
            ");

            $pdoRoot->exec("
                INSERT INTO `evento_presente` (id_evento, id_presente) VALUES
                    (2,1),(2,2),(2,3),(1,4);
            ");

            $pdoRoot->exec("
                INSERT INTO `tarefas` (id_evento, id_staff, descricao, hora_inicio, hora_fim, prioridade, estado) VALUES
                    (1, 3, 'Coordenar rececao de convidados',    '2026-06-15 19:00:00', '2026-06-15 21:00:00', 'alta',  'pendente'),
                    (1, 4, 'Gerir servico de mesa',              '2026-06-15 20:00:00', '2026-06-15 23:00:00', 'alta',  'pendente'),
                    (2, 3, 'Organizar flores e decoracao',       '2026-07-20 14:00:00', '2026-07-20 17:00:00', 'media', 'pendente'),
                    (3, 4, 'Configurar equipamento audiovisual', '2026-09-05 07:00:00', '2026-09-05 09:00:00', 'alta',  'pendente'),
                    (3, 3, 'Registo e credenciacao de entradas', '2026-09-05 08:30:00', '2026-09-05 10:00:00', 'media', 'pendente');
            ");

            $pdoRoot->exec("
                INSERT INTO `notificacoes` (id_evento, id_utilizador, mensagem, tipo, data_hora) VALUES
                    (1, 2, 'O evento Gala de Aniversario foi confirmado.',  'confirmacao', '2026-05-01 10:00:00'),
                    (1, 3, 'Tens uma nova tarefa atribuida na Gala.',       'tarefa',      '2026-05-02 09:00:00'),
                    (2, 5, 'O casamento foi registado com sucesso.',        'confirmacao', '2026-05-03 11:00:00'),
                    (3, 2, 'Lembrete: Conferencia Tech em 3 meses.',        'lembrete',    '2026-06-05 08:00:00');
            ");

            $pdoRoot->exec("
                INSERT INTO `qr_codes` (codigo, id_utilizador, id_evento, estado) VALUES
                    ('QR-EVT1-USR1-001', 1, 1, 'ativo'),
                    ('QR-EVT1-USR3-002', 3, 1, 'ativo'),
                    ('QR-EVT2-USR2-003', 2, 2, 'ativo'),
                    ('QR-EVT3-USR4-004', 4, 3, 'ativo');
            ");

            $pdoRoot->exec("
                INSERT INTO `guest` (nome, email, telefone) VALUES
                    ('Mariana Ferreira', 'mariana.f@email.com', '961000001'),
                    ('Joao Rodrigues',   'joao.r@email.com',    '961000002'),
                    ('Sofia Pinto',      'sofia.p@email.com',   '961000003'),
                    ('Miguel Alves',     'miguel.a@email.com',  '961000004'),
                    ('Ines Carvalho',    'ines.c@email.com',    '961000005');
            ");

            $pdoRoot->exec("
                INSERT INTO `mesa` (numero, capacidade, localizacao) VALUES
                    (1, 10, 'Sala Principal - Zona A'),
                    (2, 10, 'Sala Principal - Zona A'),
                    (3,  8, 'Sala Principal - Zona B'),
                    (4,  6, 'Terraco'),
                    (5,  6, 'Terraco');
            ");

            $pdoRoot->exec("
                INSERT INTO `evento_mesa` (id_evento, id_mesa) VALUES
                    (1,1),(1,2),(1,3),
                    (2,1),(2,2),(2,4),(2,5),
                    (3,3),(3,4);
            ");

            $pdoRoot->exec("
                INSERT INTO `event_guest` (id_evento, id_guest, id_mesa, estado_rsvp) VALUES
                    (1,1,1,'confirmado'),
                    (1,2,1,'confirmado'),
                    (1,3,2,'pendente'),
                    (2,4,4,'confirmado'),
                    (2,5,4,'confirmado'),
                    (3,1,3,'pendente'),
                    (3,2,3,'confirmado');
            ");
        }

        // ── Passo 5: cria a ligação final com a BD selecionada ─────
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET,
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );

        return $pdo;

    } catch (PDOException $e) {
        $msg = $e->getMessage();
        $dica = '';

        // Dá dicas específicas para os erros mais comuns
        if (str_contains($msg, 'Connection refused') || str_contains($msg, '2002')) {
            $dica = 'O MySQL não está a correr. Abra o XAMPP Control Panel e clique em <strong>Start</strong> no MySQL.';
        } elseif (str_contains($msg, 'Access denied') || str_contains($msg, '1045')) {
            $dica = 'Credenciais incorretas. Verifique o utilizador e password no ficheiro <code>db.php</code>.';
        } else {
            $dica = 'Certifique-se que o XAMPP está a correr (Apache + MySQL).';
        }

        die('
        <!DOCTYPE html>
        <html lang="pt-PT">
        <head>
            <meta charset="UTF-8">
            <title>Erro de Base de Dados - Event Hub</title>
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
            <style>
                body { font-family: Inter, sans-serif; background: #f8fafc;
                       display: flex; align-items: center; justify-content: center;
                       min-height: 100vh; margin: 0; }
                .card { background: white; border-radius: 16px; padding: 40px;
                        max-width: 520px; width: 90%; box-shadow: 0 8px 32px rgba(0,0,0,.08); }
                h2 { color: #dc2626; margin: 0 0 16px; font-size: 20px; }
                p  { color: #374151; line-height: 1.6; margin: 0 0 12px; font-size: 15px; }
                .step { background: #f1f5f9; border-radius: 10px; padding: 16px 20px;
                        margin: 16px 0; font-size: 14px; color: #1e293b; }
                .step strong { display: block; margin-bottom: 4px; color: #0f172a; }
                code { background: #e2e8f0; padding: 2px 6px; border-radius: 4px;
                       font-family: monospace; font-size: 13px; }
                .err { background: #fee2e2; border-radius: 8px; padding: 12px 16px;
                       font-size: 12px; color: #991b1b; font-family: monospace;
                       margin-top: 16px; word-break: break-all; }
            </style>
        </head>
        <body>
        <div class="card">
            <h2>⚠️ Erro de ligação à base de dados</h2>
            <p>' . $dica . '</p>
            <div class="step">
                <strong>Como resolver:</strong>
                1. Abra o <strong>XAMPP Control Panel</strong><br>
                2. Clique em <strong>Start</strong> no <strong>Apache</strong><br>
                3. Clique em <strong>Start</strong> no <strong>MySQL</strong><br>
                4. Recarregue esta página — a base de dados é criada automaticamente
            </div>
            <div class="err">' . htmlspecialchars($msg) . '</div>
        </div>
        </body>
        </html>
        ');
    }
}
