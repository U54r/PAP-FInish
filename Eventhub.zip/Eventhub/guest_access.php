<?php
/**
 * guest_access.php — Magic link login for guests.
 * Guest clicks the link in their email → automatically logged in → redirected to guest.php
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$token = trim($_GET['token'] ?? '');

if (!$token) {
    header('Location: login.php?erro=link_invalido');
    exit;
}

$pdo = getDB();

// Validate token: must exist, not used, and not expired
$stmt = $pdo->prepare("
    SELECT t.id_token, t.email, t.id_evento,
           u.id_utilizador, u.nome, u.id_role, u.estado_conta, u.id_organizador,
           r.nome_role
    FROM guest_invite_tokens t
    JOIN utilizador u ON u.email = t.email
    JOIN role r ON r.id_role = u.id_role
    WHERE t.token = ? AND t.used = 0 AND t.expires > NOW()
    LIMIT 1
");
$stmt->execute([$token]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    header('Location: login.php?erro=link_expirado');
    exit;
}

if ($row['estado_conta'] !== 'ativo') {
    header('Location: login.php?erro=conta_inativa');
    exit;
}

// Mark token as used so the link can only be clicked once
$pdo->prepare("UPDATE guest_invite_tokens SET used = 1 WHERE id_token = ?")
    ->execute([$row['id_token']]);

// Regenerate session ID to prevent session fixation
session_regenerate_id(true);

// Create session — same structure as login.php
$_SESSION['id_utilizador'] = $row['id_utilizador'];
$_SESSION['nome']          = $row['nome'];
$_SESSION['email']         = $row['email'];
$_SESSION['role']          = $row['nome_role'];
$_SESSION['id_role']       = $row['id_role'];
$_SESSION['user']          = $row;

header('Location: guest.php');
exit;
