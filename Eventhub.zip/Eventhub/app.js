/* =========================================================
   app.js — EventHub Frontend ↔ Backend connector
   ========================================================= */

'use strict';

// ── Helpers HTTP ──────────────────────────────────────────
const API = {
    async req(url, method = 'GET', body = null) {
        const opts = {
            method,
            headers: { 'Content-Type': 'application/json' }
        };
        if (body) opts.body = JSON.stringify(body);
        try {
            const response = await fetch(url, opts);
            const text = await response.text();
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('Erro ao parsear JSON de "' + url + '":', text.slice(0, 300));
                return { status: 'erro', msg: 'Resposta inválida do servidor' };
            }
        } catch (e) {
            console.error('Erro de rede:', e);
            return { status: 'erro', msg: 'Erro de rede: ' + e.message };
        }
    },
    get:    (url)        => API.req(url),
    post:   (url, body)  => API.req(url, 'POST', body),
    put:    (url, body)  => API.req(url, 'PUT',  body),
    patch:  (url, body)  => API.req(url, 'PATCH', body),
    delete: (url)        => API.req(url, 'DELETE'),
};

// ── Utilitários ──────────────────────────────────────────
const getVal = id => document.getElementById(id)?.value ?? '';
const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val ?? ''; };

const esc = s => {
    if (s == null) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
};

// Alias para compatibilidade — remove a dependência de escapeHtml
const escapeHtml = esc;

// Encodes a value as a double-quoted JS string literal safe inside a double-quoted
// HTML attribute. JSON.stringify escapes ', \, newlines, etc.; replacing " with
// &quot; prevents the attribute from closing prematurely.
const jsStr = s => JSON.stringify(String(s ?? '')).replace(/"/g, '&quot;');

const capitalize  = s => s ? s.charAt(0).toUpperCase() + s.slice(1).replace(/_/g, ' ') : '';

const formatDateSimple = d => {
    if (!d) return '';
    const data = new Date(d + 'T00:00:00');
    if (isNaN(data.getTime())) return d;
    const locale = (typeof getLang === 'function' && getLang() === 'en') ? 'en-US' : 'pt-PT';
    return data.toLocaleDateString(locale, { day: '2-digit', month: 'short', year: 'numeric' });
};

const formatDateTime = d => {
    if (!d) return '—';
    const data = new Date(d);
    if (isNaN(data.getTime())) return d;
    const locale = (typeof getLang === 'function' && getLang() === 'en') ? 'en-US' : 'pt-PT';
    return data.toLocaleDateString(locale, { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
};

/* Localized status label helpers */
const tRsvp      = v => ({ confirmado: t('rsvp.confirmado'), pendente: t('rsvp.pendente'), recusado: t('rsvp.recusado') }[v] || capitalize(v));
const tPrio      = v => ({ alta: t('priority.alta'), media: t('priority.media'), baixa: t('priority.baixa') }[v] || capitalize(v));
const tTaskState = v => ({ pendente: t('task.pendente'), em_andamento: t('task.emAndamento'), concluida: t('task.concluida') }[v] || capitalize(v));
const tDelivery  = v => ({ pendente: t('rsvp.pendente'), confirmado: t('rsvp.confirmado'), entregue: t('delivery.entregue'), cancelado: t('delivery.cancelado'), atrasado: t('delivery.atrasado') }[v] || capitalize(v));
const tGiftState = v => ({ pendente: t('rsvp.pendente'), reservado: t('gift.reservado'), confirmado: t('rsvp.confirmado') }[v] || capitalize(v));

const setStat = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

const prioridadeBadge  = p => ({ alta: 'badge-danger-soft', media: 'badge-info',    baixa: 'badge-muted' }[p]  || 'badge-muted');
const estadoBadgeTarefa= e => ({ pendente: 'badge-warning', em_andamento: 'badge-purple', concluida: 'badge-success' }[e] || 'badge-muted');
const rsvpBadge        = e => ({ confirmado: 'badge-success', pendente: 'badge-warning', recusado: 'badge-danger-soft' }[e] || 'badge-muted');
const presenteBadge    = e => ({ confirmado: 'badge-success', pendente: 'badge-warning', reservado: 'badge-warning' }[e] || 'badge-muted');

// ── Toast ────────────────────────────────────────────────
function toast(msg, tipo = 'success') {
    const existing = document.getElementById('eh-toast');
    if (existing) existing.remove();

    const icons  = { success: 'ph-check-circle-fill', error: 'ph-x-circle-fill', info: 'ph-info' };
    const colors = { success: '#22c55e', error: '#ef4444', info: '#3b82f6' };

    const el = document.createElement('div');
    el.id = 'eh-toast';
    el.style.cssText = `
        position:fixed; bottom:28px; left:50%; transform:translateX(-50%) translateY(80px);
        background:#0f172a; color:#fff; border:1px solid rgba(255,255,255,0.1);
        border-radius:40px; padding:14px 24px; font-size:14px; font-weight:500;
        display:flex; align-items:center; gap:10px; z-index:99999;
        box-shadow:0 8px 32px rgba(0,0,0,0.3); transition:transform .35s ease;
        max-width:90vw;
    `;
    el.innerHTML = `<i class="ph-fill ${icons[tipo]}" style="color:${colors[tipo]};font-size:20px;"></i><span>${msg}</span>`;
    document.body.appendChild(el);
    setTimeout(() => el.style.transform = 'translateX(-50%) translateY(0)', 50);
    setTimeout(() => {
        el.style.transform = 'translateX(-50%) translateY(80px)';
        setTimeout(() => el.remove(), 400);
    }, 3500);
}

// ── Custom confirm/alert dialogs (substituem os nativos confirm()/alert()) ──
function _ehDialogStyles() {
    if (document.getElementById('eh-dialog-style')) return;
    const style = document.createElement('style');
    style.id = 'eh-dialog-style';
    style.textContent = `
        .eh-dialog-overlay { position:fixed; inset:0; background:rgba(15,23,42,0.55); backdrop-filter:blur(4px); z-index:100000; display:flex; align-items:center; justify-content:center; padding:20px; opacity:0; transition:opacity .18s ease; }
        .eh-dialog-overlay.eh-open { opacity:1; }
        .eh-dialog-box { background:#fff; border-radius:20px; max-width:400px; width:100%; box-shadow:0 25px 60px rgba(0,0,0,0.25); padding:28px; text-align:center; transform:scale(0.94) translateY(8px); transition:transform .18s ease; }
        .eh-dialog-overlay.eh-open .eh-dialog-box { transform:scale(1) translateY(0); }
        .eh-dialog-icon { width:56px; height:56px; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 16px; font-size:28px; }
        .eh-dialog-icon.eh-warn    { background:#fef2f2; color:#ef4444; }
        .eh-dialog-icon.eh-success { background:#f0fdfa; color:#0d9488; }
        .eh-dialog-msg { font-size:14px; color:#334155; line-height:1.6; white-space:pre-line; margin:0 0 20px; }
        .eh-dialog-copy { display:flex; align-items:center; gap:8px; background:#f0fdfa; border:1.5px solid #99f6e4; border-radius:10px; padding:10px 14px; margin:0 0 20px; }
        .eh-dialog-copy code { flex:1; font-family:monospace; font-size:15px; font-weight:700; color:#0f766e; text-align:left; word-break:break-all; }
        .eh-dialog-copy button { background:none; border:none; cursor:pointer; color:#0d9488; font-size:18px; flex-shrink:0; display:flex; align-items:center; }
        .eh-dialog-actions { display:flex; gap:10px; }
        .eh-dialog-actions button { flex:1; padding:11px; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer; border:1.5px solid var(--border-color); background:#fff; color:#334155; transition:background .15s; }
        .eh-dialog-actions button:hover { background:#f8fafc; }
        .eh-dialog-actions .eh-dialog-confirm { background:#0f172a; color:#fff; border-color:#0f172a; }
        .eh-dialog-actions .eh-dialog-confirm:hover { background:#1e293b; }
        .eh-dialog-actions .eh-dialog-confirm.eh-danger { background:#ef4444; border-color:#ef4444; }
        .eh-dialog-actions .eh-dialog-confirm.eh-danger:hover { background:#dc2626; }
    `;
    document.head.appendChild(style);
}

function confirmDialog(message, opts = {}) {
    _ehDialogStyles();
    return new Promise(resolve => {
        const overlay = document.createElement('div');
        overlay.className = 'eh-dialog-overlay';
        overlay.innerHTML = `
            <div class="eh-dialog-box">
                <div class="eh-dialog-icon eh-warn"><i class="ph-fill ph-warning-circle"></i></div>
                <p class="eh-dialog-msg"></p>
                <div class="eh-dialog-actions">
                    <button class="eh-dialog-cancel">${t('btn.cancel')}</button>
                    <button class="eh-dialog-confirm ${opts.danger === false ? '' : 'eh-danger'}">${t('btn.confirm')}</button>
                </div>
            </div>`;
        overlay.querySelector('.eh-dialog-msg').textContent = message;
        document.body.appendChild(overlay);
        requestAnimationFrame(() => overlay.classList.add('eh-open'));

        const close = result => {
            overlay.classList.remove('eh-open');
            setTimeout(() => overlay.remove(), 180);
            resolve(result);
            document.removeEventListener('keydown', onKey);
        };
        const onKey = e => { if (e.key === 'Escape') close(false); };
        overlay.querySelector('.eh-dialog-cancel').onclick  = () => close(false);
        overlay.querySelector('.eh-dialog-confirm').onclick = () => close(true);
        overlay.addEventListener('click', e => { if (e.target === overlay) close(false); });
        document.addEventListener('keydown', onKey);
    });
}

function alertDialog(message, opts = {}) {
    _ehDialogStyles();
    return new Promise(resolve => {
        const overlay = document.createElement('div');
        overlay.className = 'eh-dialog-overlay';
        overlay.innerHTML = `
            <div class="eh-dialog-box">
                <div class="eh-dialog-icon eh-success"><i class="ph-fill ph-check-circle"></i></div>
                <p class="eh-dialog-msg"></p>
                ${opts.copyValue ? `<div class="eh-dialog-copy"><code></code><button title="${t('btn.copy')}"><i class="ph ph-copy"></i></button></div>` : ''}
                <div class="eh-dialog-actions"><button class="eh-dialog-confirm">OK</button></div>
            </div>`;
        overlay.querySelector('.eh-dialog-msg').textContent = message;
        if (opts.copyValue) {
            overlay.querySelector('.eh-dialog-copy code').textContent = opts.copyValue;
            overlay.querySelector('.eh-dialog-copy button').onclick = () => {
                navigator.clipboard?.writeText(opts.copyValue);
                toast(t('toast.copied'));
            };
        }
        document.body.appendChild(overlay);
        requestAnimationFrame(() => overlay.classList.add('eh-open'));

        const close = () => {
            overlay.classList.remove('eh-open');
            setTimeout(() => overlay.remove(), 180);
            resolve();
            document.removeEventListener('keydown', onKey);
        };
        const onKey = e => { if (e.key === 'Escape') close(); };
        overlay.querySelector('.eh-dialog-confirm').onclick = close;
        overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
        document.addEventListener('keydown', onKey);
    });
}

// ── Modal helpers ────────────────────────────────────────
function abrirModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function fecharModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

document.addEventListener('click', e => {
    if (e.target.classList?.contains('modal-overlay')) {
        fecharModal(e.target.id);
    }
});

// ── Notificações ─────────────────────────────────────────
let lastNotifCount = 0;

async function carregarNotificacoes() {
    try {
        const r = await API.get('notificacoes.php');
        if (r.status !== 'ok') return;
        const notifs = r.data || [];

        const badge = document.getElementById('notif-badge');
        const lista  = document.getElementById('notif-lista');

        if (badge) {
            badge.textContent   = notifs.length;
            badge.style.display = notifs.length ? 'flex' : 'none';
        }

        if (lista) {
            lista.innerHTML = notifs.length
                ? notifs.map(n => `
                    <div class="notif-item" data-id="${n.id_notificacao}">
                        <div class="notif-icon-wrap">${notifIcon(n.tipo)}</div>
                        <div class="notif-body">
                            <p class="notif-msg">${esc(n.mensagem)}</p>
                            <span class="notif-meta">${n.nome_evento ? esc(n.nome_evento) + ' · ' : ''}${formatDateTime(n.data_hora)}</span>
                        </div>
                        <button class="notif-dismiss" onclick="dispensarNotif(${n.id_notificacao})"><i class="ph ph-x"></i></button>
                    </div>`).join('')
                : `<p class="notif-empty">${t('notif.empty')}</p>`;
        }

        // Popups para novas notificações
        if (notifs.length > lastNotifCount) {
            const newNotifs = notifs.slice(0, notifs.length - lastNotifCount);
            for (const notif of newNotifs) {
                showAttentionPopup(notif.mensagem, notif.id_notificacao);
            }
        }
        lastNotifCount = notifs.length;

    } catch (e) { console.error(e); }
}

function showAttentionPopup(msg, notifId) {
    const popupId = 'popup_' + Date.now() + '_' + (notifId || Math.random());
    const popup = document.createElement('div');
    popup.id = popupId;
    popup.className = 'notif-attention-popup';
    popup.innerHTML = `
        <div class="popup-icon"><i class="ph ph-bell-fill"></i></div>
        <div class="popup-content">
            <p class="popup-msg">${esc(msg)}</p>
            <button class="popup-dismiss" onclick="this.closest('.notif-attention-popup').remove()">
                <i class="ph ph-x"></i> Dispensar
            </button>
        </div>`;
    document.body.appendChild(popup);
    setTimeout(() => popup.classList.add('show'), 10);
}

function notifIcon(tipo) {
    const map = {
        tarefa:       '<i class="ph ph-clipboard-text" style="color:#f97316"></i>',
        conclusao:    '<i class="ph-fill ph-check-circle" style="color:#22c55e"></i>',
        confirmacao:  '<i class="ph-fill ph-calendar-check" style="color:#0d9488"></i>',
        convidado:    '<i class="ph ph-user-plus" style="color:#3b82f6"></i>',
        atualizacao:  '<i class="ph ph-pencil-simple" style="color:#64748b"></i>',
        lembrete:     '<i class="ph ph-bell" style="color:#f97316"></i>',
    };
    return map[tipo] || '<i class="ph ph-bell"></i>';
}

async function dispensarNotif(id) {
    await API.delete(`notificacoes.php?id=${id}`);
    document.querySelector(`.notif-item[data-id="${id}"]`)?.remove();
    carregarNotificacoes();
}

async function limparTodasNotifs() {
    await API.delete('notificacoes.php');
    carregarNotificacoes();
    toast(t('toast.notifsCleared'));
}

function toggleNotifPanel() {
    document.getElementById('notif-panel')?.classList.toggle('open');
}

// Fechar painel ao clicar fora
document.addEventListener('click', e => {
    const panel   = document.getElementById('notif-panel');
    const wrapper = e.target.closest('.notif-wrapper');
    if (panel && panel.classList.contains('open') && !wrapper) {
        panel.classList.remove('open');
    }
});

// Polling
setInterval(carregarNotificacoes, 30000);

// ── Perfil ───────────────────────────────────────────────
async function carregarPerfil() {
    try {
        const r = await API.get('perfil.php');
        if (r.status !== 'ok') return;
        const u = r.data;
        setVal('perfil-nome', u.nome || '');
        setVal('perfil-email', u.email || '');
        setVal('perfil-telefone', u.telefone || '');
        setVal('perfil-role', u.nome_role || '');
        const src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(u.nome || '')}`;
        document.querySelectorAll('.avatar, #perfil-avatar').forEach(img => img.src = src);
    } catch (e) { console.error(e); }
}

async function guardarPerfil(e) {
    if (e) e.preventDefault();
    const body = {
        nome:          getVal('perfil-nome'),
        telefone:      getVal('perfil-telefone'),
        password:      getVal('perfil-pw-atual'),
        nova_password: getVal('perfil-pw-nova'),
    };
    const r = await API.put('perfil.php', body);
    if (r.status === 'ok') {
        toast(t('toast.profileUpdated'));
        carregarPerfil();
    } else {
        toast('❌ ' + (r.msg || 'Erro'), 'error');
    }
}

// ── Estatísticas ─────────────────────────────────────────
async function carregarEstatisticas() {
    try {
        const [evR, tR, conR] = await Promise.all([
            API.get('eventos.php'),
            API.get('tarefas.php'),
            API.get('convidados.php'),
        ]);
        if (evR?.status === 'ok')  setStat('stat-eventos', evR.data?.length || 0);
        if (conR?.status === 'ok') setStat('stat-convidados', conR.data?.length || 0);
        if (tR?.status === 'ok') {
            const pendentes = (tR.data || []).filter(t => t.estado === 'pendente').length;
            setStat('stat-tarefas', pendentes);
        }
    } catch (e) { console.error(e); }
}

// ── Eventos ──────────────────────────────────────────────
async function carregarEventos() {
    const r = await API.get('eventos.php');
    return r.status === 'ok' ? (r.data || []) : [];
}

function preencherSelectEventos(eventos) {
    document.querySelectorAll('.select-evento').forEach(sel => {
        const cur = sel.value;
        sel.innerHTML = `<option value="">${t('select.event')}</option>` +
            eventos.map(e => `<option value="${e.id_evento}" ${cur == e.id_evento ? 'selected' : ''}>${esc(e.nome_evento)}</option>`).join('');
    });
}

async function carregarEventosGrid() {
    const eventos = await carregarEventos();
    const grid = document.getElementById('events-grid');
    if (!grid) return;
    preencherSelectEventos(eventos);
    if (!eventos.length) {
        grid.innerHTML = `<div class="empty-state"><i class="ph ph-calendar-x"></i><p>${t('dyn.noEvents')}</p></div>`;
        return;
    }
    const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
    grid.innerHTML = eventos.map(e => {
        const status     = new Date(e.data + 'T00:00:00') >= hoje ? 'ativo' : 'inativo';
        const badgeClass = status === 'ativo' ? 'badge-purple' : 'badge-muted';
        return `
        <div class="event-card" data-id="${e.id_evento}" data-status="${status}">
            <div class="event-card-header">
                <span class="badge ${badgeClass}">${status === 'ativo' ? t('dyn.active') : t('dyn.past')}</span>
                <div class="event-actions">
                    <a class="btn-icon" href="guest.php?id_evento=${e.id_evento}" title="${t('btn.viewGuestPage')}" target="_blank"><i class="ph ph-eye"></i></a>
                    <button class="btn-icon" onclick="abrirEditarEvento(${e.id_evento})" title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                    <button class="btn-icon delete" onclick="eliminarEvento(${e.id_evento})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
                </div>
            </div>
            <h3 class="event-name">${esc(e.nome_evento)}</h3>
            <div class="event-meta">
                <span><i class="ph ph-calendar"></i> ${formatDateSimple(e.data)}</span>
                <span><i class="ph ph-clock"></i> ${e.hora ? e.hora.slice(0, 5) : '—'}</span>
                <span><i class="ph ph-map-pin"></i> ${esc(e.local || '—')}</span>
                ${e.dresscode ? `<span><i class="ph ph-shirt"></i> ${esc(e.dresscode)}</span>` : ''}
            </div>
            ${e.descricao ? `<p class="event-desc">${esc(e.descricao)}</p>` : ''}
            <div class="event-card-footer">
                <span class="event-guests"><i class="ph ph-users"></i> ${t('dyn.viewGuests')}</span>
            </div>
        </div>`;
    }).join('');
}

async function salvarEvento(e) {
    if (e) e.preventDefault();
    const id   = getVal('ev-id');
    const body = {
        nome_evento: getVal('ev-nome'),
        local:       getVal('ev-local'),
        data:        getVal('ev-data'),
        hora:        getVal('ev-hora'),
        dresscode:   getVal('ev-dresscode'),
        descricao:   getVal('ev-descricao'),
        tipo_evento: getVal('ev-tipo')    || '',
        id_cliente:  getVal('ev-cliente') || null,
    };
    if (!body.nome_evento || !body.data || !body.hora) {
        toast(t('toast.errRequired'), 'error');
        return;
    }
    const url = id ? `eventos.php?id=${id}` : 'eventos.php';
    const r   = id ? await API.put(url, body) : await API.post(url, body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.eventUpdated') : t('toast.eventCreated'));
        fecharModal('modal-evento');
        document.getElementById('ev-id').value = '';
        document.getElementById('modal-evento-titulo').textContent = t('modal.newEvent');
        carregarEventosGrid();
        carregarEstatisticas();
        carregarNotificacoes();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function abrirEditarEvento(id) {
    const r = await API.get(`eventos.php?id=${id}`);
    if (r.status !== 'ok') { toast('Erro ao carregar evento', 'error'); return; }
    const e = r.data;
    setVal('ev-id',        e.id_evento);
    setVal('ev-nome',      e.nome_evento);
    setVal('ev-local',     e.local || '');
    setVal('ev-data',      e.data);
    setVal('ev-hora',      e.hora ? e.hora.slice(0, 5) : '');
    setVal('ev-dresscode', e.dresscode   || '');
    setVal('ev-descricao', e.descricao   || '');
    setVal('ev-tipo',      e.tipo_evento || '');
    setVal('ev-cliente',   e.id_cliente  || '');
    const titulo = document.getElementById('modal-evento-titulo');
    if (titulo) titulo.textContent = t('modal.editEvent');
    abrirModal('modal-evento');
}

async function eliminarEvento(id) {
    if (!await confirmDialog(t('confirm.deleteEvent'))) return;
    const r = await API.delete(`eventos.php?id=${id}`);
    if (r?.status === 'ok') {
        toast(t('toast.eventDeleted'));
        carregarEventosGrid();
        carregarEstatisticas();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

// ── Convidados ───────────────────────────────────────────
async function carregarConvidados() {
    const r     = await API.get('convidados.php');
    const tbody = document.getElementById('convidados-tbody');
    if (!tbody || r.status !== 'ok') {
        if (tbody) tbody.innerHTML = `<tr><td colspan="5" class="td-empty">${t('dyn.noGuests')}</td></tr>`;
        return;
    }
    // Handle both response formats: direct array or wrapped in 'convidados'
    const convidados = Array.isArray(r.data) ? r.data : (r.data?.convidados || []);
    if (!convidados.length) {
        tbody.innerHTML = `<tr><td colspan="5" class="td-empty">${t('dyn.noGuests')}</td></tr>`;
        return;
    }
    tbody.innerHTML = convidados.map(c => {
        const qrUrl = c.qr_code
            ? `https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(c.qr_code)}`
            : null;
        const qrCell = qrUrl
            ? `<img src="${qrUrl}" alt="QR" title="${esc(c.nome)}" style="width:36px;height:36px;border-radius:4px;cursor:pointer" onclick="verQRGrande(${jsStr(c.nome)},${jsStr(c.qr_code)})">`
            : `<button class="btn-icon" style="font-size:12px" onclick="gerarQRParaConvidado(${c.id_guest},${c.id_evento})" title="${t('btn.genQRShort')}"><i class="ph ph-qr-code"></i></button>`;
        return `
        <tr>
            <td><strong>${esc(c.nome)}</strong></td>
            <td>${esc(c.nome_evento || '—')}</td>
            <td>${c.num_mesa ? t('dyn.tablePrefix') + c.num_mesa : '—'}</td>
            <td><span class="badge ${rsvpBadge(c.estado_rsvp)}">${tRsvp(c.estado_rsvp)}</span></td>
            <td>${qrCell}</td>
            <td>
                <button class="btn-icon" onclick="abrirEditarConvidado(${c.id_guest},${jsStr(c.nome)},${jsStr(c.email||'')},${jsStr(c.id_mesa||'')},${jsStr(c.estado_rsvp)},${c.id_evento || 0})" title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                ${c.email ? `<button class="btn-icon" onclick="enviarEmailConvidado(${c.id_guest},${c.id_evento},${jsStr(c.nome)})" title="${t('btn.sendAccess')}" style="color:#0d9488"><i class="ph ph-envelope-simple"></i></button>` : ''}
                <button class="btn-icon delete" onclick="eliminarConvidado(${c.id_guest},${c.id_evento})" title="${t('btn.remove')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function salvarConvidado(e) {
    if (e) e.preventDefault();
    const id    = getVal('cv-id');
    const email = getVal('cv-email');
    const body  = {
        nome:        getVal('cv-nome'),
        email,
        telefone:    getVal('cv-telefone'),
        id_evento:   getVal('cv-evento'),
        id_mesa:     getVal('cv-mesa') || null,
        estado_rsvp: getVal('cv-rsvp'),
    };
    if (!body.nome || !body.id_evento) { toast(t('toast.errNameGuest'), 'error'); return; }
    const submitBtn = document.querySelector('#modal-convidado button[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;
    let r;
    try {
        r = id ? await API.put(`convidados.php?id=${id}`, body) : await API.post('convidados.php', body);
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
    if (r?.status === 'ok') {
        let msg  = id ? t('toast.guestUpdated') : t('toast.guestAdded');
        let tipo = 'success';
        if (!id && email) {
            if (r.data?.email_enviado) {
                msg = t('toast.guestEmailSent');
            } else {
                msg  = t('toast.guestEmailFail');
                tipo = 'info';
            }
        }
        toast(msg, tipo);
        fecharModal('modal-convidado');
        setVal('cv-id', '');
        carregarConvidados();
        carregarEstatisticas();
        carregarNotificacoes();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarConvidado(id, nome, email, id_mesa, rsvp, id_evento) {
    setVal('cv-id',    id);
    setVal('cv-nome',  nome);
    setVal('cv-email', email);
    setVal('cv-rsvp',  rsvp);
    
    // set event and load mesas, then preselect mesa
    if (id_evento) {
        setVal('cv-evento', id_evento);
        // load mesas for this event and then select the guest's mesa
        carregarMesasParaEvento().then(() => {
            setVal('cv-mesa', id_mesa || '');
            abrirModal('modal-convidado');
        });
    } else {
        setVal('cv-mesa',  id_mesa);
        abrirModal('modal-convidado');
    }
    const titulo = document.getElementById('modal-convidado-titulo');
    if (titulo) titulo.textContent = t('modal.editGuest');
}

// Load mesas for the selected event in the "Adicionar Convidado" modal
async function carregarMesasParaEvento() {
    const idEvento = getVal('cv-evento');
    const mesaSelect = document.getElementById('cv-mesa');
    if (!mesaSelect) return;

    if (!idEvento) {
        mesaSelect.innerHTML = `<option value="">${t('select.noTable')}</option>`;
        return;
    }

    mesaSelect.innerHTML = `<option value="" disabled>${t('dyn.loadingTables')}</option>`;

    const r = await API.get(`mesas.php?id_evento=${idEvento}`);

    if (r.status === 'ok' && Array.isArray(r.data) && r.data.length > 0) {
        mesaSelect.innerHTML = `<option value="">${t('select.noTable')}</option>` +
            r.data.map(m => `<option value="${m.id_mesa}">${t('dyn.tablePrefix')}${m.numero} (cap: ${m.capacidade}${m.localizacao ? ' — ' + m.localizacao : ''})</option>`).join('');
    } else if (r.status !== 'ok') {
        console.warn('Erro ao carregar mesas:', r.msg);
        mesaSelect.innerHTML = `<option value="">${t('select.noTable')}</option>`;
    } else {
        mesaSelect.innerHTML = `<option value="">${t('dyn.noTablesForEvent')}</option>`;
    }
}

// Set up event listeners when modal is opened
document.addEventListener('DOMContentLoaded', function() {
    const cvEventoSelect = document.getElementById('cv-evento');
    if (cvEventoSelect) {
        cvEventoSelect.addEventListener('change', carregarMesasParaEvento);
    }
    const qrEventoSelect = document.getElementById('qr-evento');
    if (qrEventoSelect) {
        qrEventoSelect.addEventListener('change', carregarConvidadosParaQR);
    }
});

async function eliminarConvidado(idGuest, idEvento) {
    if (!await confirmDialog(t('confirm.deleteGuest'))) return;
    const r = await API.delete(`convidados.php?id_evento=${idEvento}&id_guest=${idGuest}`);
    if (r?.status === 'ok') {
        toast(t('toast.guestDeleted'));
        carregarConvidados();
        carregarEstatisticas();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function enviarEmailConvidado(idGuest, idEvento, nome) {
    if (!await confirmDialog(t('confirm.sendEmailGuest').replace('{0}', nome))) return;
    const r = await API.post('enviar_email_convidado.php', { id_guest: idGuest, id_evento: idEvento });
    if (r?.status === 'ok') {
        toast(`Email enviado para ${nome}!`);
        if (r.data?.password) {
            await alertDialog('Email enviado!\nPassword temporária gerada (esta informação não será mostrada novamente):', { copyValue: r.data.password });
        }
    } else {
        toast(r?.msg || 'Erro ao enviar email', 'error');
    }
}

// ── Mesas ────────────────────────────────────────────────
async function carregarMesas() {
    const r     = await API.get('mesas.php');
    const tbody = document.getElementById('mesas-tbody');
    if (!tbody) return;
    if (r.status !== 'ok' || !r.data) {
        tbody.innerHTML = `<tr><td colspan="6" class="td-empty">${t('dyn.noTables')}</td></tr>`;
        return;
    }
    const mesas = Array.isArray(r.data) ? r.data : [];
    if (!mesas.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="td-empty">${t('dyn.noTables')}</td></tr>`;
        return;
    }
    tbody.innerHTML = mesas.map(m => `
        <tr>
            <td><strong>${t('dyn.tablePrefix')}${m.numero}</strong></td>
            <td>${esc(m.nome || '—')}</td>
            <td>${esc(m.nome_evento || '—')}</td>
            <td>${m.capacidade} ${t('dyn.tablePeople').trim()}</td>
            <td><span class="badge badge-muted">${m.forma === 'round' ? t('shape.round') : t('shape.rectangle')}</span></td>
            <td>
                <button class="btn-icon" onclick='abrirEditarMesa(${JSON.stringify(m).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarMesa(${m.id_mesa})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function salvarMesa(e) {
    if (e) e.preventDefault();
    const id   = getVal('ms-id');
    const body = {
        nome:        getVal('ms-nome'),
        numero:      getVal('ms-numero'),
        capacidade:  getVal('ms-capacidade'),
        forma:       getVal('ms-forma') || 'round',
        localizacao: getVal('ms-local'),
        id_evento:   getVal('ms-evento'),
    };
    if (!body.numero || !body.capacidade || !body.id_evento) {
        toast(t('toast.errRequired'), 'error'); return;
    }
    const r = id ? await API.put(`mesas.php?id=${id}`, body) : await API.post('mesas.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.tableUpdated') : t('toast.tableCreated'));
        fecharModal('modal-mesa');
        setVal('ms-id', '');
        carregarMesas();
        carregarPlanta();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarMesa(m) {
    setVal('ms-id',         m.id_mesa);
    setVal('ms-nome',       m.nome || '');
    setVal('ms-numero',     m.numero);
    setVal('ms-capacidade', m.capacidade);
    setVal('ms-forma',      m.forma || 'round');
    setVal('ms-local',      m.localizacao || '');
    const titulo = document.getElementById('modal-mesa-titulo');
    if (titulo) titulo.textContent = t('modal.editTable');
    abrirModal('modal-mesa');
}

async function eliminarMesa(id) {
    if (!await confirmDialog(t('confirm.deleteTable'))) return;
    const r = await API.delete(`mesas.php?id=${id}`);
    if (r?.status === 'ok') { toast(t('toast.tableDeleted')); carregarMesas(); carregarPlanta(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

// ── Planta Visual de Mesas ───────────────────────────────

// SVG color themes per tablecloth color
function getMesaColors(m) {
    const nomeLC = (m.nome || '').toLowerCase();
    if (nomeLC.includes('honra') || nomeLC.includes('noiv') || nomeLC.includes('honour')) {
        return { cloth: '#fef3c7', border: '#d97706', text: '#78350f', chairFill: '#fde68a', chairStroke: '#f59e0b' };
    }
    const T = {
        teal:    { cloth: '#ccfbf1', border: '#0d9488', text: '#0f766e', chairFill: '#5eead4', chairStroke: '#0d9488' },
        rosa:    { cloth: '#fce7f3', border: '#db2777', text: '#9d174d', chairFill: '#fbcfe8', chairStroke: '#ec4899' },
        sage:    { cloth: '#dcfce7', border: '#15803d', text: '#14532d', chairFill: '#bbf7d0', chairStroke: '#22c55e' },
        marfim:  { cloth: '#fef9c3', border: '#ca8a04', text: '#713f12', chairFill: '#fef08a', chairStroke: '#eab308' },
        azul:    { cloth: '#dbeafe', border: '#2563eb', text: '#1e3a8a', chairFill: '#bfdbfe', chairStroke: '#3b82f6' },
        lavanda: { cloth: '#ede9fe', border: '#7c3aed', text: '#4c1d95', chairFill: '#ddd6fe', chairStroke: '#8b5cf6' },
    };
    return T[m.cor_toalha] || T.teal;
}

function escSvg(s) {
    return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function generateMesaSVG(m) {
    const c    = getMesaColors(m);
    const tam  = Math.max(1, Math.min(3, parseInt(m.tamanho) || 2));
    const cap  = parseInt(m.capacidade) || 6;
    const ocup = parseInt(m.ocupacao)   || 0;
    const nome = m.nome || ('Mesa ' + (m.numero || ''));
    const isRound = (m.forma || 'round') === 'round';
    return isRound ? svgMesaRedonda(c, tam, cap, ocup, nome) : svgMesaRect(c, tam, cap, ocup, nome);
}

function svgMesaRedonda(c, tam, cap, ocup, nome) {
    const R    = [32, 42, 54][tam - 1];
    const pad  = [26, 28, 30][tam - 1];
    const size = (R + pad) * 2;
    const cx   = size / 2, cy = size / 2;
    const N    = Math.min(cap, 12);

    let chairs = '';
    for (let i = 0; i < N; i++) {
        const angle = (360 / N) * i - 90;
        chairs += `<g transform="rotate(${angle},${cx},${cy})">
    <rect x="${cx - 7}" y="${cy - R - 13}" width="14" height="10" rx="3" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
    <rect x="${cx - 8.5}" y="${cy - R - 20}" width="17" height="6" rx="3.5" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
  </g>`;
    }

    const short = nome.length > 14 ? nome.slice(0, 13) + '…' : nome;
    const fs    = tam === 3 ? 11 : (tam === 2 ? 10 : 9);

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}">
  ${chairs}
  <circle cx="${cx}" cy="${cy}" r="${R}" fill="${c.cloth}" stroke="${c.border}" stroke-width="3"/>
  <circle cx="${cx}" cy="${cy}" r="${R - 10}" fill="none" stroke="${c.border}" stroke-width="1" stroke-dasharray="5 4" opacity="0.5"/>
  <circle cx="${cx}" cy="${cy}" r="${R - 19}" fill="none" stroke="${c.border}" stroke-width="0.7" opacity="0.25"/>
  <text x="${cx}" y="${cy - 5}" text-anchor="middle" font-family="Inter,sans-serif" font-size="${fs}" font-weight="700" fill="${c.text}">${escSvg(short)}</text>
  <text x="${cx}" y="${cy + 9}" text-anchor="middle" font-family="Inter,sans-serif" font-size="8.5" fill="${c.text}" opacity="0.65">${ocup}/${cap}</text>
</svg>`;
}

function svgMesaRect(c, tam, cap, ocup, nome) {
    const dims  = [[100, 60], [130, 80], [160, 100]][tam - 1];
    const cW = dims[0], cH = dims[1];
    const pX = 24, pY = 24;
    const sW = cW + pX * 2, sH = cH + pY * 2;
    const x0 = pX, y0 = pY;
    const cx = sW / 2, cy = sH / 2;

    const maxTop  = Math.max(1, Math.floor(cW / 28));
    const maxSide = Math.max(0, Math.floor(cH / 30));
    const numC    = Math.min(cap, maxTop * 2 + maxSide * 2, 16);
    const topC    = Math.min(Math.ceil(numC / 2), maxTop);
    const botC    = Math.min(numC - topC, maxTop);
    const rem     = numC - topC - botC;
    const leftC   = Math.min(Math.ceil(rem / 2), maxSide);
    const rightC  = Math.min(rem - leftC, maxSide);

    let ch = '';
    for (let i = 0; i < topC; i++) {
        const cx_c = x0 + (cW / (topC + 1)) * (i + 1);
        ch += `<rect x="${cx_c - 7}" y="${y0 - 13}" width="14" height="10" rx="3" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
  <rect x="${cx_c - 8.5}" y="${y0 - 20}" width="17" height="6" rx="3.5" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>`;
    }
    for (let i = 0; i < botC; i++) {
        const cx_c = x0 + (cW / (botC + 1)) * (i + 1);
        ch += `<rect x="${cx_c - 7}" y="${y0 + cH + 3}" width="14" height="10" rx="3" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
  <rect x="${cx_c - 8.5}" y="${y0 + cH + 14}" width="17" height="6" rx="3.5" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>`;
    }
    for (let i = 0; i < leftC; i++) {
        const cy_c = y0 + (cH / (leftC + 1)) * (i + 1);
        ch += `<rect x="${x0 - 13}" y="${cy_c - 7}" width="10" height="14" rx="3" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
  <rect x="${x0 - 20}" y="${cy_c - 8.5}" width="6" height="17" rx="3.5" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>`;
    }
    for (let i = 0; i < rightC; i++) {
        const cy_c = y0 + (cH / (rightC + 1)) * (i + 1);
        ch += `<rect x="${x0 + cW + 3}" y="${cy_c - 7}" width="10" height="14" rx="3" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>
  <rect x="${x0 + cW + 14}" y="${cy_c - 8.5}" width="6" height="17" rx="3.5" fill="${c.chairFill}" stroke="${c.chairStroke}" stroke-width="1.5"/>`;
    }

    const short = nome.length > 18 ? nome.slice(0, 17) + '…' : nome;
    const fs    = cH >= 90 ? 11 : (cH >= 70 ? 10 : 9);

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${sW}" height="${sH}">
  ${ch}
  <rect x="${x0}" y="${y0}" width="${cW}" height="${cH}" rx="10" fill="${c.cloth}" stroke="${c.border}" stroke-width="3"/>
  <rect x="${x0 + 8}" y="${y0 + 8}" width="${cW - 16}" height="${cH - 16}" rx="7" fill="none" stroke="${c.border}" stroke-width="1" stroke-dasharray="5 4" opacity="0.5"/>
  <rect x="${x0 + 15}" y="${y0 + 15}" width="${cW - 30}" height="${cH - 30}" rx="5" fill="none" stroke="${c.border}" stroke-width="0.7" opacity="0.25"/>
  <text x="${cx}" y="${cy - 5}" text-anchor="middle" font-family="Inter,sans-serif" font-size="${fs}" font-weight="700" fill="${c.text}">${escSvg(short)}</text>
  <text x="${cx}" y="${cy + 9}" text-anchor="middle" font-family="Inter,sans-serif" font-size="8.5" fill="${c.text}" opacity="0.65">${ocup}/${cap}</text>
</svg>`;
}

async function carregarPlanta() {
    const sel      = document.getElementById('planta-evento-select');
    const canvas   = document.getElementById('planta-canvas');
    const emptyMsg = document.getElementById('planta-empty');
    if (!canvas) return;

    const idEvento = sel?.value || '';

    if (sel && sel.innerHTML.trim() === '') {
        const evs = await carregarEventos();
        sel.innerHTML = `<option value="">${t('select.event')}</option>` +
            evs.map(e => `<option value="${e.id_evento}">${esc(e.nome_evento)}</option>`).join('');
    }

    if (!idEvento) {
        canvas.querySelectorAll('.planta-mesa').forEach(el => el.remove());
        if (emptyMsg) emptyMsg.style.display = 'flex';
        return;
    }

    const r = await API.get(`mesas.php?id_evento=${idEvento}`);
    canvas.querySelectorAll('.planta-mesa').forEach(el => el.remove());

    if (r.status !== 'ok' || !r.data?.length) {
        if (emptyMsg) { emptyMsg.style.display = 'flex'; emptyMsg.querySelector('p').textContent = t('floor.noTables'); }
        return;
    }

    if (emptyMsg) emptyMsg.style.display = 'none';

    const canvasRect = canvas.getBoundingClientRect();
    const maxX = Math.max(canvasRect.width  - 180, 200);
    const maxY = Math.max(canvasRect.height - 160, 200);

    r.data.forEach((m, idx) => {
        const el = criarElementoMesa(m, idx, maxX, maxY);
        canvas.appendChild(el);
        makeMesaDraggable(el, canvas);
    });

    initPlantaTema();
}

function criarElementoMesa(m, idx, maxX, maxY) {
    const el = document.createElement('div');
    el.className    = 'planta-mesa';
    el.dataset.id   = m.id_mesa;
    el.dataset.mesa = JSON.stringify(m);

    const posX = m.pos_x && m.pos_x > 0 ? Math.min(m.pos_x, maxX) : 60 + (idx % 4) * 170;
    const posY = m.pos_y && m.pos_y > 0 ? Math.min(m.pos_y, maxY) : 60 + Math.floor(idx / 4) * 170;
    el.style.left = posX + 'px';
    el.style.top  = posY + 'px';

    el.innerHTML = generateMesaSVG(m);
    return el;
}

function makeMesaDraggable(el, canvas) {
    let startX, startY, origLeft, origTop, moved;

    el.addEventListener('mousedown', function(e) {
        e.preventDefault();
        startX   = e.clientX;
        startY   = e.clientY;
        origLeft = parseInt(el.style.left) || 0;
        origTop  = parseInt(el.style.top)  || 0;
        moved    = false;
        el.classList.add('dragging');

        function onMove(e) {
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            if (!moved && (Math.abs(dx) > 5 || Math.abs(dy) > 5)) moved = true;
            if (moved) {
                const rect = canvas.getBoundingClientRect();
                const newX = Math.max(0, Math.min(origLeft + dx, rect.width  - el.offsetWidth));
                const newY = Math.max(0, Math.min(origTop  + dy, rect.height - el.offsetHeight));
                el.style.left = newX + 'px';
                el.style.top  = newY + 'px';
            }
        }

        async function onUp() {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup',   onUp);
            el.classList.remove('dragging');
            if (!moved) {
                try { abrirPainelMesa(JSON.parse(el.dataset.mesa)); } catch(ex) {}
            } else {
                const id = el.dataset.id;
                if (id) {
                    await API.put(`mesas.php?id=${id}`, {
                        pos_x: parseInt(el.style.left) || 0,
                        pos_y: parseInt(el.style.top)  || 0,
                    });
                }
            }
        }

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup',   onUp);
    });
}

// ── Planta — Canvas Theme Picker ─────────────────────────
function setPlantaTema(btn, tema) {
    const canvas = document.getElementById('planta-canvas');
    if (canvas) canvas.dataset.tema = tema;
    document.querySelectorAll('.planta-tema-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    localStorage.setItem('planta-tema', tema);
}

function initPlantaTema() {
    const saved  = localStorage.getItem('planta-tema') || '';
    const canvas = document.getElementById('planta-canvas');
    if (canvas) canvas.dataset.tema = saved;
    document.querySelectorAll('.planta-tema-btn').forEach(b => b.classList.remove('active'));
    const btn = document.querySelector(`.planta-tema-btn[data-tema="${saved}"]`);
    (btn || document.querySelector('.planta-tema-btn[data-tema=""]'))?.classList.add('active');
}

// ── Planta — Mesa Side Panel ─────────────────────────────
let panelCurrentForma = 'round';
let panelCurrentCor   = 'teal';
let panelCurrentMesa  = null;

function abrirPainelMesa(m) {
    panelCurrentMesa  = m;
    panelCurrentForma = m.forma || 'round';
    panelCurrentCor   = m.cor_toalha || 'teal';

    document.getElementById('msp-id').value     = m.id_mesa;
    document.getElementById('msp-nome').value   = m.nome || ('Mesa ' + m.numero);
    const tam = Math.max(1, Math.min(3, parseInt(m.tamanho) || 2));
    document.getElementById('msp-tamanho').value = tam;
    document.getElementById('msp-lugares').value  = m.capacidade || 8;
    document.getElementById('msp-lugares-val').textContent    = m.capacidade || 8;
    const tamLabels = ['', 'Pequeno', 'Médio', 'Grande'];
    document.getElementById('msp-tamanho-label').textContent  = tamLabels[tam];

    document.querySelectorAll('.msp-tipo-btn').forEach(b =>
        b.classList.toggle('active', b.dataset.forma === panelCurrentForma));
    document.querySelectorAll('.msp-swatch').forEach(b =>
        b.classList.toggle('active', b.dataset.cor === panelCurrentCor));

    atualizarPreviewPanel();
    document.getElementById('mesa-side-panel').classList.add('open');
    document.getElementById('msp-overlay').classList.add('open');
}

function fecharPainelMesa() {
    document.getElementById('mesa-side-panel').classList.remove('open');
    document.getElementById('msp-overlay').classList.remove('open');
}

function atualizarPreviewPanel() {
    const fakeM = {
        nome:       document.getElementById('msp-nome').value || 'Mesa',
        forma:      panelCurrentForma,
        capacidade: parseInt(document.getElementById('msp-lugares').value) || 6,
        cor_toalha: panelCurrentCor,
        tamanho:    parseInt(document.getElementById('msp-tamanho').value) || 2,
        ocupacao:   panelCurrentMesa?.ocupacao || 0,
        numero:     panelCurrentMesa?.numero   || 1,
    };
    const prev = document.getElementById('msp-preview');
    if (prev) prev.innerHTML = generateMesaSVG(fakeM);
}

function setFormaPanel(btn, forma) {
    panelCurrentForma = forma;
    document.querySelectorAll('.msp-tipo-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    atualizarPreviewPanel();
}

function setCorPanel(btn, cor) {
    panelCurrentCor = cor;
    document.querySelectorAll('.msp-swatch').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    atualizarPreviewPanel();
}

function onTamanhoChange(el) {
    const labels = ['', t('msp.sizeSmall'), t('msp.sizeMed'), t('msp.sizeLarge')];
    document.getElementById('msp-tamanho-label').textContent = labels[el.value] || '';
    atualizarPreviewPanel();
}

function onLugaresChange(el) {
    document.getElementById('msp-lugares-val').textContent = el.value;
    atualizarPreviewPanel();
}

async function guardarMesaPanel() {
    const id = document.getElementById('msp-id').value;
    if (!id) return;
    const body = {
        nome:       document.getElementById('msp-nome').value,
        forma:      panelCurrentForma,
        capacidade: parseInt(document.getElementById('msp-lugares').value) || 8,
        cor_toalha: panelCurrentCor,
        tamanho:    parseInt(document.getElementById('msp-tamanho').value) || 2,
    };
    const r = await API.put(`mesas.php?id=${id}`, body);
    if (r?.status === 'ok') {
        toast(t('toast.tableUpdated2'));
        fecharPainelMesa();
        refrescarPlantaAtual();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function eliminarMesaPanel() {
    const id = document.getElementById('msp-id').value;
    if (!id || !await confirmDialog(t('confirm.deleteTable'))) return;
    const r = await API.delete(`mesas.php?id=${id}`);
    if (r?.status === 'ok') {
        toast(t('toast.tableDeleted'));
        fecharPainelMesa();
        refrescarPlantaAtual();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function refrescarPlantaAtual() {
    if (document.getElementById('planta-canvas')) { carregarPlanta(); carregarMesas(); }
    if (window._clEventoAtualPlanta) renderPlantaCliente(window._clEventoAtualPlanta);
}

// ── Staff ────────────────────────────────────────────────
async function carregarStaffSelects() {
    const r = await API.get('staff.php');
    if (r.status !== 'ok') return;
    document.querySelectorAll('.select-staff').forEach(sel => {
        const cur = sel.value;
        sel.innerHTML = `<option value="">${t('select.staff')}</option>` +
            (r.data || []).map(s => `<option value="${s.id_utilizador}" ${cur == s.id_utilizador ? 'selected' : ''}>${esc(s.nome)}</option>`).join('');
    });
}

// ── Tarefas ──────────────────────────────────────────────
async function carregarTarefas() {
    const r = await API.get('tarefas.php');
    return r.status === 'ok' ? (r.data || []) : [];
}

async function carregarTarefasTabela() {
    const tarefas = await carregarTarefas();
    const tbody   = document.getElementById('tarefas-tbody');
    if (!tbody) return;
    if (!tarefas.length) {
        tbody.innerHTML = `<tr><td colspan="8" class="td-empty">${t('dyn.noTasks')}</td></tr>`;
        return;
    }
    tbody.innerHTML = tarefas.map(tarefa => `
        <tr>
            <td><strong>${esc(tarefa.descricao)}</strong></td>
            <td>${esc(tarefa.nome_evento || '—')}</td>
            <td>${esc(tarefa.nome_staff  || '—')}</td>
            <td>${tarefa.hora_inicio ? formatDateTime(tarefa.hora_inicio) : '—'}</td>
            <td>${tarefa.hora_fim    ? formatDateTime(tarefa.hora_fim)    : '—'}</td>
            <td><span class="badge ${prioridadeBadge(tarefa.prioridade)}">${tPrio(tarefa.prioridade || 'media')}</span></td>
            <td><span class="badge ${estadoBadgeTarefa(tarefa.estado)}">${tTaskState(tarefa.estado)}</span></td>
            <td>
                <button class="btn-icon" onclick='abrirEditarTarefa(${JSON.stringify(tarefa).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarTarefa(${tarefa.id_tarefa})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function salvarTarefa(e) {
    if (e) e.preventDefault();
    const id   = getVal('tr-id');
    const body = {
        descricao:   getVal('tr-descricao'),
        id_evento:   getVal('tr-evento'),
        id_staff:    getVal('tr-staff')    || null,
        hora_inicio: getVal('tr-inicio')   || null,
        hora_fim:    getVal('tr-fim')      || null,
        prioridade:  getVal('tr-prioridade'),
        estado:      getVal('tr-estado'),
    };
    if (!body.descricao || !body.id_evento) {
        toast(t('toast.errDescEvent'), 'error'); return;
    }
    const r = id ? await API.put(`tarefas.php?id=${id}`, body) : await API.post('tarefas.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.taskUpdated') : t('toast.taskCreated'));
        fecharModal('modal-tarefa');
        setVal('tr-id', '');
        carregarTarefasTabela();
        carregarEstatisticas();
        carregarNotificacoes();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarTarefa(tarefa) {
    setVal('tr-id',          tarefa.id_tarefa);
    setVal('tr-descricao',   tarefa.descricao);
    setVal('tr-evento',      tarefa.id_evento);
    setVal('tr-staff',       tarefa.id_staff || '');
    setVal('tr-inicio',      tarefa.hora_inicio ? tarefa.hora_inicio.slice(0, 16) : '');
    setVal('tr-fim',         tarefa.hora_fim    ? tarefa.hora_fim.slice(0, 16)    : '');
    setVal('tr-prioridade',  tarefa.prioridade  || 'media');
    setVal('tr-estado',      tarefa.estado      || 'pendente');
    const titulo = document.getElementById('modal-tarefa-titulo');
    if (titulo) titulo.textContent = t('modal.editTask');
    abrirModal('modal-tarefa');
}

async function eliminarTarefa(id) {
    if (!await confirmDialog(t('confirm.deleteTask'))) return;
    const r = await API.delete(`tarefas.php?id=${id}`);
    if (r?.status === 'ok') {
        toast(t('toast.taskDeleted'));
        carregarTarefasTabela();
        carregarEstatisticas();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

// ── Presentes ────────────────────────────────────────────
async function carregarPresentes() {
    const r     = await API.get('presentes.php');
    const tbody = document.getElementById('presentes-tbody');
    if (!tbody || r.status !== 'ok') return;
    const presentes = r.data || [];
    if (!presentes.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="td-empty">${t('dyn.noGifts')}</td></tr>`;
        return;
    }
    tbody.innerHTML = presentes.map(p => `
        <tr>
            <td><strong>${esc(p.nome_item)}</strong></td>
            <td>${esc(p.nome_evento || '—')}</td>
            <td>${esc(p.categoria  || '—')}</td>
            <td>€ ${parseFloat(p.preco_estimado || 0).toFixed(2)}</td>
            <td><span class="badge ${presenteBadge(p.estado)}">${tGiftState(p.estado)}</span></td>
            <td>${esc(p.nome_responsavel || '—')}</td>
            <td>
                <button class="btn-icon" onclick='abrirEditarPresente(${JSON.stringify(p).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarPresente(${p.id_presente})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function salvarPresente(e) {
    if (e) e.preventDefault();
    const id   = getVal('pr-id');
    const body = {
        nome_item:      getVal('pr-nome'),
        id_evento:      getVal('pr-evento'),
        categoria:      getVal('pr-categoria'),
        preco_estimado: getVal('pr-preco'),
        estado:         getVal('pr-estado'),
    };
    if (!body.nome_item || !body.id_evento) {
        toast(t('toast.errNameGift'), 'error'); return;
    }
    const r = id ? await API.put(`presentes.php?id=${id}`, body) : await API.post('presentes.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.giftUpdated') : t('toast.giftCreated'));
        fecharModal('modal-presente');
        setVal('pr-id', '');
        carregarPresentes();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarPresente(p) {
    setVal('pr-id',        p.id_presente);
    setVal('pr-nome',      p.nome_item);
    setVal('pr-categoria', p.categoria || '');
    setVal('pr-preco',     p.preco_estimado || '');
    setVal('pr-estado',    p.estado || 'pendente');
    const titulo = document.getElementById('modal-presente-titulo');
    if (titulo) titulo.textContent = t('modal.editGift');
    abrirModal('modal-presente');
}

async function eliminarPresente(id) {
    if (!await confirmDialog(t('confirm.deleteGift'))) return;
    const r = await API.delete(`presentes.php?id=${id}`);
    if (r?.status === 'ok') { toast(t('toast.giftDeleted')); carregarPresentes(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

// ── Recursos ─────────────────────────────────────────────
const entregaBadge = e => ({
    pendente:   'badge-warning',
    confirmado: 'badge-success',
    entregue:   'badge-success',
    cancelado:  'badge-danger',
    atrasado:   'badge-danger-soft',
}[e] || 'badge-muted');

async function carregarRecursos() {
    const r     = await API.get('recursos.php');
    const tbody = document.getElementById('recursos-tbody');
    if (!tbody || r.status !== 'ok') return;
    const recursos = r.data || [];
    if (!recursos.length) {
        tbody.innerHTML = `<tr><td colspan="9" class="td-empty">${t('dyn.noResources')}</td></tr>`;
        return;
    }
    tbody.innerHTML = recursos.map(rc => {
        const total = parseInt(rc.quantidade_total) || 0;
        const usado = parseInt(rc.quantidade_usada) || 0;

        const hoje       = new Date(); hoje.setHours(0,0,0,0);
        const prazo      = rc.prazo_confirmacao ? new Date(rc.prazo_confirmacao + 'T00:00:00') : null;
        const prazoClass = prazo && prazo < hoje && rc.estado_entrega === 'pendente' ? 'color:#dc2626;font-weight:700' : '';

        return `
        <tr>
            <td><strong>${esc(rc.nome)}</strong></td>
            <td>${esc(rc.nome_evento || '—')}</td>
            <td>${esc(rc.categoria  || '—')}</td>
            <td>${total} (${usado} usado)</td>
            <td>${esc(rc.fornecedor_nome || '—')}</td>
            <td>${rc.data_entrega ? formatDateSimple(rc.data_entrega) : '—'}</td>
            <td style="${prazoClass}">${rc.prazo_confirmacao ? formatDateSimple(rc.prazo_confirmacao) : '—'}</td>
            <td><span class="badge ${entregaBadge(rc.estado_entrega)}">${tDelivery(rc.estado_entrega || 'pendente')}</span></td>
            <td>
                <button class="btn-icon" onclick='abrirEditarRecurso(${JSON.stringify(rc).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarRecurso(${rc.id_recurso})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`;
    }).join('');
}

async function salvarRecurso(e) {
    if (e) e.preventDefault();
    const id   = getVal('rc-id');
    const body = {
        nome:              getVal('rc-nome'),
        id_evento:         getVal('rc-evento'),
        categoria:         getVal('rc-categoria'),
        quantidade_total:  getVal('rc-qtd-total'),
        quantidade_usada:  getVal('rc-qtd-usada'),
        id_fornecedor:     getVal('rc-fornecedor'),
        data_entrega:      getVal('rc-data-entrega')  || '',
        prazo_confirmacao: getVal('rc-prazo')         || '',
        estado_entrega:    getVal('rc-estado-entrega') || 'pendente',
    };
    if (!body.nome) { toast(t('toast.errNameResource'), 'error'); return; }
    const r = id ? await API.put(`recursos.php?id=${id}`, body) : await API.post('recursos.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.resourceUpdated') : t('toast.resourceCreated'));
        fecharModal('modal-recurso');
        setVal('rc-id', '');
        carregarRecursos();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarRecurso(rc) {
    setVal('rc-id',            rc.id_recurso);
    setVal('rc-nome',          rc.nome);
    setVal('rc-categoria',     rc.categoria           || '');
    setVal('rc-qtd-total',     rc.quantidade_total    || 0);
    setVal('rc-qtd-usada',     rc.quantidade_usada    || 0);
    setVal('rc-fornecedor',    rc.id_fornecedor       || '');
    setVal('rc-data-entrega',  rc.data_entrega        || '');
    setVal('rc-prazo',         rc.prazo_confirmacao   || '');
    setVal('rc-estado-entrega',rc.estado_entrega      || 'pendente');
    const titulo = document.getElementById('modal-recurso-titulo');
    if (titulo) titulo.textContent = t('modal.editResource');
    abrirModal('modal-recurso');
}

async function eliminarRecurso(id) {
    if (!await confirmDialog(t('confirm.deleteResource'))) return;
    const r = await API.delete(`recursos.php?id=${id}`);
    if (r?.status === 'ok') { toast(t('toast.resourceDeleted')); carregarRecursos(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

// ── QR Codes ─────────────────────────────────────────────
async function carregarQRCodes() {
    const r    = await API.get('qrcodes.php');
    const grid = document.getElementById('qr-grid');
    if (!grid || r.status !== 'ok') return;
    const qrs = r.data || [];
    if (!qrs.length) {
        grid.innerHTML = `<div class="empty-state"><i class="ph ph-qr-code"></i><p>${t('dyn.noQR')}</p></div>`;
        return;
    }
    grid.innerHTML = qrs.map(q => {
        const imgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(q.qr_code)}`;
        return `
        <div class="qr-card">
            <div class="qr-card-header">
                <div>
                    <h3>${esc(q.nome_guest)}</h3>
                    <p>${esc(q.nome_evento)}</p>
                </div>
                <span class="badge badge-success">${t('dyn.active')}</span>
            </div>
            <div class="qr-code-box" style="display:flex;justify-content:center;padding:12px 0;">
                <img src="${imgUrl}" alt="${esc(q.qr_code)}" style="width:140px;height:140px;border-radius:6px;" loading="lazy">
            </div>
            <div class="qr-card-footer">
                <span class="qr-code-text" style="font-size:11px;">${esc(q.qr_code)}</span>
                <div class="qr-actions">
                    <a href="${imgUrl}" download="qr-${esc(q.qr_code)}.png" class="btn-icon" title="${t('btn.download')}">
                        <i class="ph ph-download-simple"></i>
                    </a>
                    <button class="btn-icon delete" onclick="eliminarQR(${q.id_evento},${q.id_guest})" title="${t('btn.delete')}">
                        <i class="ph ph-trash"></i>
                    </button>
                </div>
            </div>
        </div>`;
    }).join('');
}

// Load guests into the QR modal when an event is selected
async function carregarConvidadosParaQR() {
    const idEvento = document.getElementById('qr-evento')?.value;
    const guestSel = document.getElementById('qr-guest');
    if (!guestSel) return;

    // Reset preview
    const preview = document.getElementById('qr-preview');
    if (preview) preview.style.display = 'none';

    if (!idEvento) {
        guestSel.innerHTML = `<option value="">${t('qr.selectEventFirst')}</option>`;
        return;
    }

    guestSel.innerHTML = `<option value="">${t('dyn.loading')}</option>`;
    const r = await API.get(`qrcodes.php?id_evento=${idEvento}`);
    if (r.status === 'ok' && r.data?.length) {
        guestSel.innerHTML = `<option value="">${t('select.event')}</option>` +
            r.data.map(g => `<option value="${g.id_guest}">${esc(g.nome)}${g.qr_code ? ' ✓' : ''}</option>`).join('');
    } else {
        guestSel.innerHTML = `<option value="">${t('opt.noGuests')}</option>`;
    }
}

async function gerarQRCode() {
    const id_evento = document.getElementById('qr-evento')?.value;
    const id_guest  = document.getElementById('qr-guest')?.value;
    if (!id_evento || !id_guest) { toast(t('toast.errSelectQR'), 'error'); return; }

    const r = await API.post('qrcodes.php', { id_evento, id_guest });
    if (r?.status === 'ok') {
        const codigo = r.data?.codigo;
        if (codigo) {
            const imgUrl   = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(codigo)}`;
            const preview  = document.getElementById('qr-preview');
            const img      = document.getElementById('qr-preview-img');
            const codeText = document.getElementById('qr-preview-code');
            if (preview && img) {
                img.src = imgUrl;
                if (codeText) codeText.textContent = codigo;
                preview.style.display = 'block';
            }
        }
        toast(t('toast.qrGenerated'));
        carregarQRCodes();
        // Refresh guest list to show ✓ marker
        carregarConvidadosParaQR();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function eliminarQR(id_evento, id_guest) {
    if (!await confirmDialog(t('confirm.deleteQR'))) return;
    const r = await API.delete(`qrcodes.php?id_evento=${id_evento}&id_guest=${id_guest}`);
    if (r?.status === 'ok') { toast(t('toast.qrDeleted')); carregarQRCodes(); carregarConvidados(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

// Quick-generate QR from guest list row
async function gerarQRParaConvidado(id_guest, id_evento) {
    if (!id_evento) { toast(t('toast.errEventUnknown'), 'error'); return; }
    const r = await API.post('qrcodes.php', { id_evento, id_guest });
    if (r?.status === 'ok') {
        toast(t('toast.qrGenerated'));
        carregarConvidados();
        carregarQRCodes();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

// Show QR in a lightbox overlay
function verQRGrande(nome, qrCode) {
    const existing = document.getElementById('qr-lightbox');
    if (existing) existing.remove();

    const imgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrCode)}`;
    const box = document.createElement('div');
    box.id = 'qr-lightbox';
    box.style.cssText = `position:fixed;inset:0;background:rgba(15,23,42,.75);z-index:99998;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px)`;
    box.innerHTML = `
        <div style="background:#fff;border-radius:20px;padding:32px;text-align:center;max-width:380px;width:90%;box-shadow:0 25px 60px rgba(0,0,0,.3)">
            <h3 style="font-size:18px;font-weight:800;color:#0f172a;margin-bottom:6px">${esc(nome)}</h3>
            <p style="font-size:13px;color:#64748b;margin-bottom:20px">${t('qr.accessCode')}</p>
            <img src="${imgUrl}" alt="QR Code" style="width:240px;height:240px;border-radius:8px;border:4px solid #f0fdfa">
            <p style="font-size:10px;color:#94a3b8;margin-top:12px;font-family:monospace;word-break:break-all">${esc(qrCode)}</p>
            <button onclick="document.getElementById('qr-lightbox').remove()" style="margin-top:16px;padding:10px 28px;background:#0d9488;color:#fff;border:none;border-radius:10px;font-weight:700;cursor:pointer;font-size:14px">${t('btn.close')}</button>
        </div>`;
    box.addEventListener('click', e => { if (e.target === box) box.remove(); });
    document.body.appendChild(box);
}

// ── Decoração ────────────────────────────────────────────
const decorIconMap = tipo => {
    const t = (tipo || '').toLowerCase();
    if (t.includes('flor') || t.includes('arranjo')) return { cls: 'flowers', icon: 'ph-flower' };
    if (t.includes('luz') || t.includes('ilumina')) return { cls: 'lights', icon: 'ph-sun' };
    if (t.includes('mesa') || t.includes('centro')) return { cls: 'tables', icon: 'ph-table' };
    return { cls: 'other', icon: 'ph-star' };
};

const decorEstadoBadge = e => ({
    pendente:   'badge-warning',
    confirmado: 'badge-success',
    entregue:   'badge-entregue',
    cancelado:  'badge-danger',
}[e] || 'badge-muted');

async function carregarDecoracao() {
    const filtroEvento = document.getElementById('decor-evento-filter')?.value || '';
    const url = filtroEvento ? `decoracao.php?id_evento=${filtroEvento}` : 'decoracao.php';
    const r   = await API.get(url);
    const grid = document.getElementById('decor-grid');
    if (!grid || r.status !== 'ok') return;

    const items = r.data || [];
    if (!items.length) {
        grid.innerHTML = `<div class="empty-state"><i class="ph ph-flower"></i><p>${t('dyn.noDecor')}</p></div>`;
        return;
    }

    const temaLabel = {
        casamento:   t('dyn.temaLabel.casamento'),
        baby_shower: t('dyn.temaLabel.baby_shower'),
        aniversario: t('dyn.temaLabel.aniversario'),
        batizado:    t('dyn.temaLabel.batizado'),
        outro:       t('dyn.temaLabel.outro'),
    };

    grid.innerHTML = items.map(d => {
        const { cls, icon } = decorIconMap(d.tipo);
        const total = (parseFloat(d.preco_unitario) || 0) * (parseInt(d.quantidade) || 1);
        return `
        <div class="decor-card">
            <div class="decor-card-header">
                <div class="decor-icon ${cls}"><i class="ph ${icon}"></i></div>
                <span class="badge ${decorEstadoBadge(d.estado)}">${tDelivery(d.estado)}</span>
            </div>
            <div>
                <div class="decor-title">${esc(d.tipo)}</div>
                ${d.tema ? `<span class="event-tipo-tag" style="margin-top:4px">${temaLabel[d.tema] || d.tema}</span>` : ''}
            </div>
            <div class="decor-meta">
                <span><i class="ph ph-calendar"></i> ${t('dyn.delivery')}${d.data_entrega ? formatDateSimple(d.data_entrega) : '—'}</span>
                <span><i class="ph ph-buildings"></i> ${esc(d.fornecedor_nome || '—')}</span>
                <span><i class="ph ph-stack"></i> ${t('dyn.qty')}${d.quantidade} × €${parseFloat(d.preco_unitario || 0).toFixed(2)} = €${total.toFixed(2)}</span>
                ${d.descricao ? `<span><i class="ph ph-note"></i> ${esc(d.descricao)}</span>` : ''}
            </div>
            <div class="decor-footer">
                <span style="font-size:12px;color:var(--text-muted)">${esc(d.nome_evento || '—')}</span>
                <div style="display:flex;gap:6px">
                    <button class="btn-icon" onclick='abrirEditarDecoracao(${JSON.stringify(d).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                    <button class="btn-icon delete" onclick="eliminarDecoracao(${d.id_decoracao})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
                </div>
            </div>
        </div>`;
    }).join('');
}

async function salvarDecoracao(e) {
    if (e) e.preventDefault();
    const id   = getVal('dc-id');
    const body = {
        tipo:           getVal('dc-tipo'),
        id_evento:      getVal('dc-evento'),
        tema:           getVal('dc-tema')         || '',
        id_fornecedor:  getVal('dc-fornecedor')   || '',
        quantidade:     getVal('dc-quantidade')   || 1,
        preco_unitario: getVal('dc-preco')        || '',
        data_entrega:   getVal('dc-data-entrega') || '',
        estado:         getVal('dc-estado')       || 'pendente',
        descricao:      getVal('dc-descricao')    || '',
    };
    if (!body.tipo || !body.id_evento) { toast(t('toast.errDecor'), 'error'); return; }
    const r = id ? await API.put(`decoracao.php?id=${id}`, body) : await API.post('decoracao.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.decorUpdated') : t('toast.decorCreated'));
        fecharModal('modal-decoracao');
        setVal('dc-id', '');
        carregarDecoracao();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarDecoracao(d) {
    setVal('dc-id',          d.id_decoracao);
    setVal('dc-tipo',        d.tipo);
    setVal('dc-evento',      d.id_evento);
    setVal('dc-tema',        d.tema         || '');
    setVal('dc-fornecedor',  d.id_fornecedor || '');
    setVal('dc-quantidade',  d.quantidade   || 1);
    setVal('dc-preco',       d.preco_unitario || '');
    setVal('dc-data-entrega',d.data_entrega || '');
    setVal('dc-estado',      d.estado       || 'pendente');
    setVal('dc-descricao',   d.descricao    || '');
    const titulo = document.getElementById('modal-decoracao-titulo');
    if (titulo) titulo.textContent = t('modal.editDecor');
    abrirModal('modal-decoracao');
}

async function eliminarDecoracao(id) {
    if (!await confirmDialog(t('confirm.deleteDecor'))) return;
    const r = await API.delete(`decoracao.php?id=${id}`);
    if (r?.status === 'ok') { toast(t('toast.decorDeleted')); carregarDecoracao(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

// ── Fornecedores ─────────────────────────────────────────
async function carregarFornecedoresTabela() {
    const r     = await API.get('fornecedores.php');
    const tbody = document.getElementById('fornecedores-tbody');
    if (!tbody || r.status !== 'ok') return;
    const fornecedores = r.data || [];
    if (!fornecedores.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="td-empty">${t('dyn.noFornecedores')}</td></tr>`;
        return;
    }
    tbody.innerHTML = fornecedores.map(f => `
        <tr>
            <td><strong>${esc(f.nome)}</strong></td>
            <td>${esc(f.categoria || '—')}</td>
            <td>${esc(f.contacto || '—')}</td>
            <td>${esc(f.telefone || '—')}</td>
            <td>${esc(f.email || '—')}</td>
            <td>
                <button class="btn-icon" onclick='abrirEditarFornecedor(${JSON.stringify(f).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarFornecedor(${f.id_fornecedor})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function salvarFornecedor(e) {
    if (e) e.preventDefault();
    const id   = getVal('fr-id');
    const body = {
        nome:        getVal('fr-nome'),
        categoria:   getVal('fr-categoria')   || '',
        contacto:    getVal('fr-contacto')    || '',
        telefone:    getVal('fr-telefone')    || '',
        email:       getVal('fr-email')       || '',
        observacoes: getVal('fr-observacoes') || '',
    };
    if (!body.nome) { toast(t('toast.errNameFornecedor'), 'error'); return; }
    const r = id ? await API.put(`fornecedores.php?id=${id}`, body) : await API.post('fornecedores.php', body);
    if (r?.status === 'ok') {
        toast(id ? t('toast.fornecedorUpdated') : t('toast.fornecedorCreated'));
        fecharModal('modal-fornecedor');
        setVal('fr-id', '');
        carregarFornecedoresTabela();
        preencherSelectFornecedores();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

function abrirEditarFornecedor(f) {
    setVal('fr-id',          f.id_fornecedor);
    setVal('fr-nome',        f.nome);
    setVal('fr-categoria',   f.categoria   || '');
    setVal('fr-contacto',    f.contacto    || '');
    setVal('fr-telefone',    f.telefone    || '');
    setVal('fr-email',       f.email       || '');
    setVal('fr-observacoes', f.observacoes || '');
    const titulo = document.getElementById('modal-fornecedor-titulo');
    if (titulo) titulo.textContent = t('modal.editFornecedor');
    abrirModal('modal-fornecedor');
}

async function eliminarFornecedor(id) {
    if (!await confirmDialog(t('confirm.deleteFornecedor'))) return;
    const r = await API.delete(`fornecedores.php?id=${id}`);
    if (r?.status === 'ok') { toast(t('toast.fornecedorDeleted')); carregarFornecedoresTabela(); preencherSelectFornecedores(); }
    else toast('❌ ' + (r?.msg || 'Erro'), 'error');
}

async function preencherSelectFornecedores() {
    const r = await API.get('fornecedores.php');
    if (r.status !== 'ok') return;
    document.querySelectorAll('.select-fornecedor').forEach(sel => {
        const cur = sel.value;
        sel.innerHTML = `<option value="">${t('select.noFornecedor')}</option>` +
            (r.data || []).map(f => `<option value="${f.id_fornecedor}" ${cur == f.id_fornecedor ? 'selected' : ''}>${esc(f.nome)}</option>`).join('');
    });
}

// ── Clientes ─────────────────────────────────────────────
async function preencherSelectClientes() {
    const r = await API.get('staff.php?role=cliente');
    if (r.status !== 'ok') return;
    document.querySelectorAll('.select-cliente').forEach(sel => {
        const cur = sel.value;
        sel.innerHTML = `<option value="">${t('select.noClient')}</option>` +
            (r.data || []).map(c => `<option value="${c.id_utilizador}" ${cur == c.id_utilizador ? 'selected' : ''}>${esc(c.nome)} (${esc(c.email)})</option>`).join('');
    });
}

async function carregarClientesTabela() {
    const r     = await API.get('staff.php?role=cliente');
    const tbody = document.getElementById('clientes-tbody');
    if (!tbody) return;
    if (r.status !== 'ok' || !(r.data || []).length) {
        tbody.innerHTML = `<tr><td colspan="6" class="td-empty">${t('dyn.noClients')}</td></tr>`;
        return;
    }
    tbody.innerHTML = r.data.map(c => `
        <tr>
            <td><strong>${esc(c.nome)}</strong></td>
            <td>${esc(c.email || '—')}</td>
            <td>${esc(c.telefone || '—')}</td>
            <td>${c.nome_evento ? esc(c.nome_evento) : `<span class="td-empty">${t('select.noEvent', '—')}</span>`}</td>
            <td><span class="badge ${c.estado_conta === 'ativo' ? 'badge-success' : 'badge-muted'}">${c.estado_conta === 'ativo' ? t('dyn.active') : capitalize(c.estado_conta || 'ativo')}</span></td>
            <td>
                <a class="btn-icon" href="cliente-dashboard.php?preview_id=${c.id_utilizador}" target="_blank" title="${t('btn.viewClient')}"><i class="ph ph-eye"></i></a>
                <button class="btn-icon" onclick='abrirEditarCliente(${JSON.stringify(c).replace(/'/g, "\\'")})' title="${t('btn.edit')}"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-icon" onclick="enviarEmailCliente(${c.id_utilizador},${jsStr(c.nome)})" title="${t('btn.sendAccess')}" style="color:#0d9488"><i class="ph ph-envelope-simple"></i></button>
                <button class="btn-icon delete" onclick="eliminarCliente(${c.id_utilizador})" title="${t('btn.delete')}"><i class="ph ph-trash"></i></button>
            </td>
        </tr>`).join('');
}

async function eliminarCliente(id) {
    if (!await confirmDialog(t('confirm.deleteClient'))) return;
    const r = await API.delete(`criar_utilizador.php?id=${id}`);
    if (r?.status === 'ok') {
        toast(t('toast.clientDeleted'));
        carregarClientesTabela();
        preencherSelectClientes();
        carregarEventosGrid();
    } else {
        toast('❌ ' + (r?.msg || 'Erro'), 'error');
    }
}

async function enviarEmailCliente(idCliente, nome) {
    if (!await confirmDialog(t('confirm.sendEmail').replace('{0}', nome))) return;
    const r = await API.post('enviar_email_cliente.php', { id_cliente: idCliente });
    if (r?.status === 'ok') {
        toast(`Email enviado para ${nome}!`);
        if (r.data?.password) {
            await alertDialog('Email enviado!\nPassword temporária gerada (esta informação não será mostrada novamente):', { copyValue: r.data.password });
        }
    } else {
        toast(r?.msg || 'Erro ao enviar email', 'error');
    }
}

function abrirNovoCliente() {
    setVal('cl-id', '');
    setVal('cl-evento-anterior', '');
    setVal('cl-nome', '');
    setVal('cl-email', '');
    setVal('cl-telefone', '');
    setVal('cl-password', '');
    setVal('cl-evento', '');
    const emailInput = document.getElementById('cl-email');
    if (emailInput) emailInput.disabled = false;
    const titulo = document.getElementById('modal-cliente-titulo');
    if (titulo) titulo.textContent = t('modal.newClient');
    const btn = document.getElementById('cl-submit-btn');
    if (btn) btn.textContent = t('btn.createClient');
    const res = document.getElementById('cliente-result');
    if (res) res.style.display = 'none';
    abrirModal('modal-cliente');
}

function abrirEditarCliente(c) {
    setVal('cl-id', c.id_utilizador);
    setVal('cl-evento-anterior', c.id_evento || '');
    setVal('cl-nome', c.nome || '');
    setVal('cl-email', c.email || '');
    setVal('cl-telefone', c.telefone || '');
    setVal('cl-password', '');
    setVal('cl-evento', c.id_evento || '');
    const emailInput = document.getElementById('cl-email');
    if (emailInput) emailInput.disabled = true;
    const titulo = document.getElementById('modal-cliente-titulo');
    if (titulo) titulo.textContent = t('modal.editClient');
    const btn = document.getElementById('cl-submit-btn');
    if (btn) btn.textContent = t('btn.saveChanges');
    const res = document.getElementById('cliente-result');
    if (res) res.style.display = 'none';
    abrirModal('modal-cliente');
}

async function salvarCliente(e) {
    if (e) e.preventDefault();
    const id               = getVal('cl-id');
    const nome              = document.getElementById('cl-nome')?.value?.trim();
    const email             = document.getElementById('cl-email')?.value?.trim();
    const telefone          = document.getElementById('cl-telefone')?.value?.trim();
    const password          = document.getElementById('cl-password')?.value?.trim();
    const idEvento          = getVal('cl-evento') || '';
    const idEventoAnterior  = getVal('cl-evento-anterior') || '';
    if (!nome || !email) { toast(t('toast.errClientName'), 'error'); return; }

    const body = { nome, email, telefone, role: 'cliente' };
    if (password) body.password = password;

    const r = await API.post('criar_utilizador.php', body);
    if (r?.status !== 'ok') { toast('❌ ' + (r?.msg || 'Erro'), 'error'); return; }

    const idCliente = id || r.data?.id_utilizador;
    if (idEvento !== idEventoAnterior) {
        if (idEventoAnterior) await API.patch(`eventos.php?id=${idEventoAnterior}`, { id_cliente: null });
        if (idEvento) await API.patch(`eventos.php?id=${idEvento}`, { id_cliente: idCliente });
    }

    const res = document.getElementById('cliente-result');
    if (res) {
        res.style.display = 'block';
        res.innerHTML = id
            ? `✅ ${t('toast.clientUpdated')}`
            : `✅ Contratante criado! ${r.data?.password ? `<br>Palavra-passe: <strong>${esc(r.data.password)}</strong>` : ''}`;
    }
    toast(id ? t('toast.clientUpdated') : t('toast.clientCreated'));
    carregarClientesTabela();
    preencherSelectClientes();
    carregarEventosGrid();
    if (!id) {
        document.getElementById('cl-nome').value = '';
        document.getElementById('cl-email').value = '';
        document.getElementById('cl-telefone').value = '';
        document.getElementById('cl-password').value = '';
        setVal('cl-evento', '');
    }
}
