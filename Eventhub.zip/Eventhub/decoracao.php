<?php
// decoracao.php — CRUD Decorações
// DB: gestao_eventos
// Table: decoracao (id_decoracao, id_evento, tipo, descricao, id_fornecedor, quantidade, preco_unitario, data_entrega, estado, tema)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $id_evento = (int)($_GET['id_evento'] ?? 0);
    if ($id_evento) {
        $role = $_SESSION['role'] ?? '';
        $uid  = (int)$_SESSION['id_utilizador'];
        if ($role === 'organizador') {
            $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
            $evChk->execute([$id_evento, $uid]);
        } elseif ($role === 'cliente') {
            $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
            $evChk->execute([$id_evento, $uid]);
        } else {
            jsonErro('Sem permissão', 403);
        }
        if (!$evChk->fetch()) jsonErro('Sem permissão', 403);
        $stmt = $pdo->prepare("
            SELECT d.*, e.nome_evento, f.nome AS fornecedor_nome
            FROM decoracao d
            JOIN evento e ON e.id_evento = d.id_evento
            LEFT JOIN fornecedor f ON f.id_fornecedor = d.id_fornecedor
            WHERE d.id_evento = ?
            ORDER BY d.data_entrega ASC, d.tipo ASC
        ");
        $stmt->execute([$id_evento]);
    } else {
        requireRole(['organizador']);
        $stmt = $pdo->prepare("
            SELECT d.*, e.nome_evento, f.nome AS fornecedor_nome
            FROM decoracao d
            JOIN evento e ON e.id_evento = d.id_evento
            LEFT JOIN fornecedor f ON f.id_fornecedor = d.id_fornecedor
            WHERE e.id_organizador = ?
            ORDER BY d.data_entrega ASC, d.tipo ASC
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
    }
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador']);
    $d = getBody();
    if (empty($d['tipo']) || empty($d['id_evento'])) {
        jsonErro('Campos obrigatórios: tipo, id_evento');
    }
    $pdo->prepare("
        INSERT INTO decoracao (id_evento, tipo, descricao, id_fornecedor, quantidade, preco_unitario, data_entrega, estado, tema)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        (int)$d['id_evento'],
        $d['tipo'],
        $d['descricao'] ?? '',
        !empty($d['id_fornecedor'])  ? (int)$d['id_fornecedor']       : null,
        !empty($d['quantidade'])     ? (int)$d['quantidade']          : 1,
        !empty($d['preco_unitario']) ? (float)$d['preco_unitario']    : null,
        !empty($d['data_entrega'])   ? $d['data_entrega']             : null,
        $d['estado'] ?? 'pendente',
        $d['tema']    ?? '',
    ]);
    jsonOk(['id_decoracao' => (int)$pdo->lastInsertId()], 'Item de decoração criado');
    break;

case 'PUT':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $putChk = $pdo->prepare('
        SELECT d.id_decoracao FROM decoracao d
        JOIN evento e ON e.id_evento = d.id_evento
        WHERE d.id_decoracao = ? AND e.id_organizador = ?
    ');
    $putChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$putChk->fetch()) jsonErro('Sem permissão.', 403);
    $d = getBody();
    $pdo->prepare("
        UPDATE decoracao
        SET tipo=?, descricao=?, id_fornecedor=?, quantidade=?, preco_unitario=?,
            data_entrega=?, estado=?, tema=?
        WHERE id_decoracao=?
    ")->execute([
        $d['tipo'],
        $d['descricao'] ?? '',
        !empty($d['id_fornecedor'])  ? (int)$d['id_fornecedor']    : null,
        !empty($d['quantidade'])     ? (int)$d['quantidade']       : 1,
        !empty($d['preco_unitario']) ? (float)$d['preco_unitario'] : null,
        !empty($d['data_entrega'])   ? $d['data_entrega']          : null,
        $d['estado'] ?? 'pendente',
        $d['tema']    ?? '',
        $id,
    ]);
    jsonOk([], 'Decoração atualizada');
    break;

case 'DELETE':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $delChk = $pdo->prepare('
        SELECT d.id_decoracao FROM decoracao d
        JOIN evento e ON e.id_evento = d.id_evento
        WHERE d.id_decoracao = ? AND e.id_organizador = ?
    ');
    $delChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("DELETE FROM decoracao WHERE id_decoracao=?")->execute([$id]);
    jsonOk([], 'Item de decoração eliminado');
    break;
}
