<?php
// reset_db.php - CORRIGIR/ELIMINAR A BASE DE DADOS
// ATENÇÃO: Este script vai ELIMINAR TODOS OS DADOS!

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

require_once __DIR__ . '/auth.php';
requireRole(['administrador']);

require_once __DIR__ . '/db.php';

try {
    $pdo = new PDO(
        'mysql:host=localhost;charset=utf8mb4',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // Eliminar a base de dados se existir
    $pdo->exec("DROP DATABASE IF EXISTS gestao_eventos");
    echo "✅ Base de dados 'gestao_eventos' eliminada com sucesso!<br>";
    
    // Criar a base de dados novamente
    $pdo->exec("CREATE DATABASE gestao_eventos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "✅ Base de dados 'gestao_eventos' criada com sucesso!<br>";
    
    // Usar a base de dados
    $pdo->exec("USE gestao_eventos");
    
    // Criar todas as tabelas
    $sql = file_get_contents(__DIR__ . '/scripts_bd.sql');
    $pdo->exec($sql);
    echo "✅ Todas as tabelas foram criadas com sucesso!<br>";
    echo "✅ Dados de demonstração inseridos!<br>";
    echo "<hr>";
    echo "<p style='color:green;font-weight:bold'>🎉 Base de dados recriada com sucesso!</p>";
    echo "<a href='index.html'>Ir para o site</a>";
    
} catch (PDOException $e) {
    echo "<p style='color:red'>Erro: " . $e->getMessage() . "</p>";
}
?>