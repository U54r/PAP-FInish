<?php
require_once __DIR__ . '/auth.php';
requireLogin();
$user = getCurrentUser();

$preview_id = 0;
if (in_array($user['nome_role'], ['organizador', 'administrador']) && !empty($_GET['preview_id'])) {
    $preview_id = (int)$_GET['preview_id'];
}

if ($user['nome_role'] !== 'cliente' && !$preview_id) {
    if ($user['nome_role'] === 'organizador') header('Location: dashboard.php');
    elseif ($user['nome_role'] === 'staff')   header('Location: staff-dashboard.php');
    else                                       header('Location: login.php');
    exit;
}

$clienteId = $preview_id ?: (int)$user['id_utilizador'];

$pdo = getDB();

// Verify that the previewed client belongs to this organizer
if ($preview_id && $user['nome_role'] === 'organizador') {
    $stmtPreviewChk = $pdo->prepare(
        "SELECT id_utilizador FROM utilizador WHERE id_utilizador = ? AND id_organizador = ?"
    );
    $stmtPreviewChk->execute([$preview_id, $user['id_utilizador']]);
    if (!$stmtPreviewChk->fetch()) {
        header('Location: dashboard.php');
        exit;
    }
}

$stmtEvs = $pdo->prepare("
    SELECT e.*, u.nome AS nome_organizador
    FROM evento e
    JOIN utilizador u ON u.id_utilizador = e.id_organizador
    WHERE e.id_cliente = ?
    ORDER BY e.data ASC
");
$stmtEvs->execute([$clienteId]);
$eventos = $stmtEvs->fetchAll();

if ($preview_id) {
    $stmtCl = $pdo->prepare("SELECT * FROM utilizador WHERE id_utilizador=?");
    $stmtCl->execute([$preview_id]);
    $clienteInfo = $stmtCl->fetch();
} else {
    $clienteInfo = $user;
}

$tipoEmoji = [
    'casamento'      => '💒',
    'baby_shower'    => '🍼',
    'aniversario'    => '🎂',
    'batizado'       => '✝️',
    'jantar_empresa' => '🍽️',
    'conferencia'    => '🎤',
    'outro'          => '🎉',
];
$tipoLabel = [
    'casamento'      => 'Casamento',
    'baby_shower'    => 'Baby Shower',
    'aniversario'    => 'Aniversário',
    'batizado'       => 'Batizado',
    'jantar_empresa' => 'Jantar de Empresa',
    'conferencia'    => 'Conferência',
    'outro'          => 'Outro',
];
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Cliente — Event Hub</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <style>
        /* ── Client Portal specific styles ── */
        .cl-wrapper {
            max-width: 900px;
            margin: 0 auto;
        }

        .cl-portal-header {
            background: var(--white);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 40px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: var(--shadow-sm);
        }

        .cl-logo { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 18px; color: var(--text-dark); }
        .cl-logo i { color: var(--primary); font-size: 24px; }

        .cl-user-pill {
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--bg-light);
            border: 1px solid var(--border-color);
            border-radius: 99px;
            padding: 8px 16px 8px 10px;
            font-size: 14px;
            font-weight: 600;
            color: var(--text-dark);
        }

        .cl-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 13px;
            font-weight: 800;
            flex-shrink: 0;
        }

        .cl-main { padding: 40px; }

        .cl-hero {
            text-align: center;
            padding: 40px 0 32px;
        }

        .cl-hero-greeting {
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--primary);
            margin-bottom: 10px;
        }

        .cl-hero h1 {
            font-size: 32px;
            font-weight: 900;
            color: var(--text-dark);
            letter-spacing: -0.03em;
            margin-bottom: 8px;
        }

        .cl-hero p {
            font-size: 15px;
            color: var(--text-muted);
        }

        /* Event card */
        .cl-event-card {
            background: var(--white);
            border: 1.5px solid var(--border-color);
            border-radius: 24px;
            overflow: hidden;
            margin-bottom: 28px;
            box-shadow: var(--shadow-md);
            transition: var(--transition);
        }

        .cl-event-card:hover { box-shadow: var(--shadow-lg); }

        .cl-event-banner {
            padding: 28px 32px;
            background: var(--gradient-primary);
            color: white;
            position: relative;
            overflow: hidden;
        }

        .cl-event-banner::after {
            content: '';
            position: absolute;
            right: -30px;
            top: -30px;
            width: 160px;
            height: 160px;
            background: rgba(255,255,255,0.08);
            border-radius: 50%;
        }

        .cl-event-type-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.2);
            border-radius: 99px;
            padding: 4px 14px;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 12px;
            backdrop-filter: blur(4px);
        }

        .cl-event-banner h2 {
            font-size: 24px;
            font-weight: 900;
            letter-spacing: -0.02em;
            margin-bottom: 14px;
        }

        .cl-event-details {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .cl-event-detail {
            display: flex;
            align-items: center;
            gap: 7px;
            font-size: 13px;
            font-weight: 500;
            opacity: 0.9;
        }

        .cl-event-detail i { font-size: 16px; opacity: 0.8; }

        .cl-event-actions {
            position: absolute;
            top: 20px;
            right: 24px;
            z-index: 2;
        }

        .cl-btn-view {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
            backdrop-filter: blur(4px);
        }

        .cl-btn-view:hover { background: rgba(255,255,255,0.3); }

        .cl-event-body { padding: 24px 32px; }

        /* Tabs */
        .cl-tabs {
            display: flex;
            gap: 2px;
            background: var(--bg-light);
            border: 1.5px solid var(--border-color);
            border-radius: 14px;
            padding: 4px;
            margin-bottom: 24px;
        }

        .cl-tab {
            flex: 1;
            padding: 10px 16px;
            border-radius: 10px;
            border: none;
            background: transparent;
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            white-space: nowrap;
        }

        .cl-tab.active {
            background: var(--white);
            color: var(--text-dark);
            box-shadow: var(--shadow-sm);
        }

        .cl-tab-content { display: none; }
        .cl-tab-content.active { display: block; animation: sectionIn 0.18s ease; }

        /* Invite form */
        .invite-form {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: var(--bg-light);
            border: 1.5px solid var(--border-color);
            border-radius: 16px;
            padding: 16px;
        }

        .invite-form input {
            flex: 1;
            min-width: 160px;
            padding: 10px 14px;
            border: 1.5px solid var(--border-color);
            border-radius: 10px;
            font-size: 14px;
            outline: none;
            background: var(--white);
            transition: var(--transition);
            font-family: 'Inter', sans-serif;
        }

        .invite-form input:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(13,148,136,0.1); }

        /* Gift cards */
        .gift-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 14px;
        }

        .gift-card {
            background: var(--white);
            border: 1.5px solid var(--border-color);
            border-radius: 16px;
            padding: 18px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            transition: var(--transition);
        }

        .gift-card:hover { box-shadow: var(--shadow-md); }

        .gift-card.reservado {
            background: var(--bg-light);
            opacity: 0.75;
        }

        .gift-card-title {
            font-size: 15px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .gift-card-meta {
            display: flex;
            gap: 10px;
            align-items: center;
            font-size: 13px;
            color: var(--text-muted);
        }

        .gift-price {
            font-size: 18px;
            font-weight: 800;
            color: var(--primary);
        }

        /* QR section */
        .qr-grid-cl {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 14px;
        }

        .qr-invite-card {
            background: var(--white);
            border: 1.5px solid var(--border-color);
            border-radius: 18px;
            padding: 18px;
            display: flex;
            gap: 16px;
            align-items: center;
            transition: var(--transition);
        }

        .qr-invite-card:hover { box-shadow: var(--shadow-md); border-color: rgba(13,148,136,0.3); }

        .qr-invite-card img { border-radius: 10px; flex-shrink: 0; }

        .qr-invite-name { font-size: 15px; font-weight: 700; color: var(--text-dark); }
        .qr-invite-meta { font-size: 12px; color: var(--text-muted); margin-top: 3px; }

        /* Floor plan (read-only) — styles now in style.css .planta-ro-* */

        /* Preview banner */
        .preview-banner {
            background: #fef9c3;
            border: 1.5px solid #fde68a;
            border-radius: 14px;
            padding: 12px 20px;
            font-size: 13px;
            color: #78350f;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .no-events {
            text-align: center;
            padding: 80px 20px;
            color: var(--text-muted);
        }

        .no-events i { font-size: 56px; display: block; margin-bottom: 16px; opacity: 0.3; }

        @media (max-width: 640px) {
            .cl-main { padding: 20px 16px; }
            .cl-event-banner { padding: 20px; }
            .cl-event-body { padding: 16px 20px; }
            .cl-portal-header { padding: 14px 20px; }
        }
    </style>
</head>
<body style="background:var(--bg-body);min-height:100vh;">

<!-- Portal Header -->
<header class="cl-portal-header">
    <div class="cl-logo">
        <i class="ph-fill ph-calendar-check"></i>
        <span>Event Hub</span>
    </div>
    <div style="display:flex;align-items:center;gap:12px">
        <?php if ($preview_id): ?>
        <a href="dashboard.php" class="btn-cancel" style="font-size:13px;display:flex;align-items:center;gap:6px;padding:9px 16px;text-decoration:none">
            <i class="ph ph-arrow-left"></i> Voltar ao Dashboard
        </a>
        <?php else: ?>
        <div class="cl-user-pill">
            <div class="cl-avatar"><?= strtoupper(substr($clienteInfo['nome'] ?? 'C', 0, 1)) ?></div>
            <span><?= htmlspecialchars($clienteInfo['nome'] ?? 'Cliente') ?></span>
        </div>
        <a href="logout.php" class="btn-cancel" style="font-size:13px;display:flex;align-items:center;gap:6px;padding:9px 16px;text-decoration:none;color:#ef4444;border-color:#fecaca">
            <i class="ph ph-sign-out"></i> Sair
        </a>
        <?php endif; ?>
    </div>
</header>

<main class="cl-main">
<div class="cl-wrapper">

    <?php if ($preview_id): ?>
    <div class="preview-banner">
        <i class="ph ph-eye"></i>
        Modo de pré-visualização — a ver o painel de <strong><?= htmlspecialchars($clienteInfo['nome'] ?? '') ?></strong>
    </div>
    <?php endif; ?>

    <!-- Hero -->
    <div class="cl-hero">
        <div class="cl-hero-greeting">Bem-vindo ao seu portal de eventos</div>
        <h1>Olá, <?= htmlspecialchars(explode(' ', $clienteInfo['nome'] ?? 'Cliente')[0]) ?>!</h1>
        <p>Acompanhe, personalize e gerencie tudo relacionado ao seu evento a partir daqui.</p>
    </div>

    <?php if (empty($eventos)): ?>
    <div class="no-events">
        <i class="ph ph-calendar-x"></i>
        <p style="font-size:17px;font-weight:700;margin-bottom:8px">Nenhum evento atribuído</p>
        <p style="font-size:14px">O seu organizador ainda não associou nenhum evento a esta conta.</p>
    </div>

    <?php else: foreach ($eventos as $ev):
        $tipo      = $ev['tipo_evento'] ?? 'outro';
        $emoji     = $tipoEmoji[$tipo]  ?? '🎉';
        $tipoNome  = $tipoLabel[$tipo]  ?? 'Evento';
        $dataFormt = date('d \d\e F \d\e Y', strtotime($ev['data']));
    ?>

    <div class="cl-event-card" id="event-card-<?= $ev['id_evento'] ?>">

        <!-- Banner -->
        <div class="cl-event-banner">
            <a href="guest.php?id_evento=<?= $ev['id_evento'] ?>" target="_blank" class="cl-btn-view cl-event-actions">
                <i class="ph ph-eye"></i> Ver Página
            </a>
            <div class="cl-event-type-badge"><?= $emoji ?> <?= htmlspecialchars($tipoNome) ?></div>
            <h2><?= htmlspecialchars($ev['nome_evento']) ?></h2>
            <div class="cl-event-details">
                <div class="cl-event-detail"><i class="ph ph-calendar-blank"></i> <?= $dataFormt ?></div>
                <div class="cl-event-detail"><i class="ph ph-clock"></i> <?= substr($ev['hora'], 0, 5) ?></div>
                <?php if ($ev['local']): ?>
                <div class="cl-event-detail"><i class="ph ph-map-pin"></i> <?= htmlspecialchars($ev['local']) ?></div>
                <?php endif; ?>
                <?php if ($ev['dresscode']): ?>
                <div class="cl-event-detail"><i class="ph ph-shirt"></i> <?= htmlspecialchars($ev['dresscode']) ?></div>
                <?php endif; ?>
                <div class="cl-event-detail"><i class="ph ph-user"></i> <?= htmlspecialchars($ev['nome_organizador']) ?></div>
            </div>
        </div>

        <!-- Body with Tabs -->
        <div class="cl-event-body">
            <div class="cl-tabs">
                <button class="cl-tab active" onclick="clTab(this,'convidados-<?= $ev['id_evento'] ?>')">
                    <i class="ph ph-users"></i> Convidados
                </button>
                <button class="cl-tab" onclick="clTab(this,'presentes-<?= $ev['id_evento'] ?>')">
                    <i class="ph ph-gift"></i> Presentes
                </button>
                <button class="cl-tab" onclick="clTab(this,'qrcodes-<?= $ev['id_evento'] ?>')">
                    <i class="ph ph-qr-code"></i> QR Codes
                </button>
                <button class="cl-tab" onclick="clTab(this,'planta-<?= $ev['id_evento'] ?>', <?= $ev['id_evento'] ?>)">
                    <i class="ph ph-squares-four"></i> Planta
                </button>
            </div>

            <!-- Convidados -->
            <div id="convidados-<?= $ev['id_evento'] ?>" class="cl-tab-content active">
                <div class="invite-form">
                    <input type="text"  id="inv-nome-<?= $ev['id_evento'] ?>"  placeholder="Nome do convidado *">
                    <input type="email" id="inv-email-<?= $ev['id_evento'] ?>" placeholder="Email (para enviar convite)">
                    <button class="btn-primary-sm" onclick="convidarGuest(<?= $ev['id_evento'] ?>)">
                        <i class="ph ph-user-plus"></i> Convidar
                    </button>
                </div>
                <div id="lista-convidados-<?= $ev['id_evento'] ?>">
                    <p style="color:var(--text-muted);font-size:14px">A carregar...</p>
                </div>
            </div>

            <!-- Presentes -->
            <div id="presentes-<?= $ev['id_evento'] ?>" class="cl-tab-content">
                <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px">
                    Os convidados só veem os presentes <strong>disponíveis</strong>. Reserve um presente em nome de alguém ou deixe que os próprios convidados o façam.
                </p>
                <div class="invite-form">
                    <input type="text"   id="pr-nome-<?= $ev['id_evento'] ?>"      placeholder="Nome do presente *">
                    <input type="text"   id="pr-categoria-<?= $ev['id_evento'] ?>" placeholder="Categoria">
                    <input type="number" id="pr-preco-<?= $ev['id_evento'] ?>"     placeholder="Preço estimado (€)" min="0" step="0.01">
                    <button class="btn-primary-sm" onclick="adicionarPresenteCliente(<?= $ev['id_evento'] ?>)">
                        <i class="ph ph-plus"></i> Adicionar
                    </button>
                </div>
                <div id="lista-presentes-<?= $ev['id_evento'] ?>">
                    <p style="color:var(--text-muted);font-size:14px">A carregar...</p>
                </div>
            </div>

            <!-- QR Codes -->
            <div id="qrcodes-<?= $ev['id_evento'] ?>" class="cl-tab-content">
                <p style="font-size:13px;color:var(--text-muted);margin-bottom:16px">
                    QR Codes gerados automaticamente por convidado. Partilhe-os para check-in no evento.
                </p>
                <div id="lista-qrcodes-<?= $ev['id_evento'] ?>" class="qr-grid-cl">
                    <p style="color:var(--text-muted);font-size:14px">A carregar...</p>
                </div>
            </div>

            <!-- Planta da Sala -->
            <div id="planta-<?= $ev['id_evento'] ?>" class="cl-tab-content">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;gap:10px">
                    <p style="font-size:13px;color:var(--text-muted);margin:0">
                        Disposição visual das mesas do seu evento. Arraste para reposicionar ou clique numa mesa para editar.
                    </p>
                    <button class="btn-primary-sm" style="flex-shrink:0" onclick="adicionarMesaCliente(<?= $ev['id_evento'] ?>)">
                        <i class="ph ph-plus"></i> Adicionar Mesa
                    </button>
                </div>
                <div class="planta-canvas" id="planta-canvas-<?= $ev['id_evento'] ?>">
                    <div class="planta-empty" id="planta-empty-<?= $ev['id_evento'] ?>">
                        <i class="ph ph-squares-four"></i>
                        <span>Ainda sem mesas configuradas</span>
                    </div>
                </div>
                <!-- Legend -->
                <p style="margin-top:10px;font-size:12px;color:var(--text-muted)">
                    <i class="ph ph-cursor-click" style="margin-right:4px"></i>Clique numa mesa para editar &nbsp;·&nbsp; <i class="ph ph-arrows-out-cardinal" style="margin-right:4px"></i>Arraste para reposicionar
                </p>
            </div>
        </div>
    </div>

    <?php endforeach; endif; ?>

</div>
</main>

<script src="app.js?v=<?= filemtime(__DIR__.'/app.js') ?>"></script>
<script>
const eventosCliente = <?= json_encode(array_column($eventos, 'id_evento')) ?>;

document.addEventListener('DOMContentLoaded', async () => {
    for (const id of eventosCliente) {
        await carregarConvidadosCliente(id);
        await carregarPresentesCliente(id);
        await carregarQRsCliente(id);
        // Floor plan loaded lazily on tab click
    }
});

function clTab(btn, targetId, idEvento) {
    const card = btn.closest('.cl-event-card');
    card.querySelectorAll('.cl-tab').forEach(t => t.classList.remove('active'));
    card.querySelectorAll('.cl-tab-content').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    const el = document.getElementById(targetId);
    if (el) el.classList.add('active');

    // Lazy-load floor plan on first open
    if (idEvento && el && !el.dataset.loaded) {
        el.dataset.loaded = '1';
        renderPlantaCliente(idEvento);
    }
}

async function renderPlantaCliente(idEvento) {
    window._clEventoAtualPlanta = idEvento;
    const canvas   = document.getElementById(`planta-canvas-${idEvento}`);
    const emptyMsg = document.getElementById(`planta-empty-${idEvento}`);
    if (!canvas) return;

    const r = await API.get(`mesas.php?id_evento=${idEvento}`);
    canvas.querySelectorAll('.planta-mesa').forEach(el => el.remove());

    if (r.status !== 'ok' || !r.data?.length) {
        if (emptyMsg) emptyMsg.style.display = 'flex';
        return;
    }

    if (emptyMsg) emptyMsg.style.display = 'none';

    const rect = canvas.getBoundingClientRect();
    const maxX = Math.max(rect.width  - 180, 200);
    const maxY = Math.max(rect.height - 160, 200);

    r.data.forEach((m, idx) => {
        const el = criarElementoMesa(m, idx, maxX, maxY);
        canvas.appendChild(el);
        makeMesaDraggable(el, canvas);
    });
}

async function adicionarMesaCliente(idEvento) {
    const r0 = await API.get(`mesas.php?id_evento=${idEvento}`);
    const existentes = r0.status === 'ok' ? (r0.data || []) : [];
    const proximoNumero = existentes.reduce((max, m) => Math.max(max, parseInt(m.numero) || 0), 0) + 1;

    const r = await API.post('mesas.php', {
        numero: proximoNumero, capacidade: 8, forma: 'round', id_evento: idEvento
    });
    if (r?.status === 'ok') {
        toast('Mesa adicionada!');
        renderPlantaCliente(idEvento);
    } else {
        toast(r?.msg || 'Erro', 'error');
    }
}

async function carregarConvidadosCliente(idEvento) {
    const r  = await API.get(`convidados.php?id_evento=${idEvento}`);
    const el = document.getElementById(`lista-convidados-${idEvento}`);
    if (!el) return;
    const lista = Array.isArray(r.data) ? r.data : (r.data?.convidados || []);
    if (!lista.length) {
        el.innerHTML = '<p style="color:var(--text-muted);font-size:14px">Sem convidados adicionados ainda.</p>';
        return;
    }
    el.innerHTML = `<div class="table-wrapper"><table>
        <thead><tr><th>Nome</th><th>Email</th><th>Mesa</th><th>RSVP</th></tr></thead>
        <tbody>${lista.map(c => `
            <tr>
                <td><strong>${esc(c.nome)}</strong></td>
                <td>${esc(c.email || '—')}</td>
                <td>${c.num_mesa ? 'Mesa ' + c.num_mesa : '—'}</td>
                <td><span class="badge ${rsvpBadge(c.estado_rsvp)}">${capitalize(c.estado_rsvp)}</span></td>
            </tr>`).join('')}
        </tbody></table></div>`;
}

async function carregarPresentesCliente(idEvento) {
    const r  = await API.get(`presentes.php?id_evento=${idEvento}`);
    const el = document.getElementById(`lista-presentes-${idEvento}`);
    if (!el) return;
    const lista = r.data || [];
    if (!lista.length) {
        el.innerHTML = '<p style="color:var(--text-muted);font-size:14px">Sem presentes na lista.</p>';
        return;
    }

    const disponivel = lista.filter(p => p.estado === 'pendente');
    const reservados = lista.filter(p => p.estado !== 'pendente');

    let html = '';

    if (disponivel.length) {
        html += `<p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text-muted);margin-bottom:12px">
            Disponíveis (${disponivel.length})</p>
        <div class="gift-grid" style="margin-bottom:24px">${disponivel.map(p => `
            <div class="gift-card">
                <div class="gift-card-title">${esc(p.nome_item)}</div>
                <div class="gift-card-meta">
                    <span class="badge badge-muted">${esc(p.categoria || 'Geral')}</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <span class="gift-price">€${parseFloat(p.preco_estimado || 0).toFixed(2)}</span>
                    <button class="btn-primary-sm" style="font-size:12px;padding:8px 14px" onclick="reservarPresente(${p.id_presente},${idEvento})">
                        <i class="ph ph-heart"></i> Reservar
                    </button>
                </div>
            </div>`).join('')}</div>`;
    }

    if (reservados.length) {
        html += `<p style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text-muted);margin-bottom:12px">
            Já Reservados (${reservados.length})</p>
        <div class="gift-grid">${reservados.map(p => `
            <div class="gift-card reservado">
                <div class="gift-card-title">${esc(p.nome_item)}</div>
                <div class="gift-card-meta">
                    <span class="badge badge-muted">${esc(p.categoria || 'Geral')}</span>
                    <span class="badge badge-success">Reservado</span>
                </div>
                <span class="gift-price" style="font-size:15px">€${parseFloat(p.preco_estimado || 0).toFixed(2)}</span>
            </div>`).join('')}</div>`;
    }

    el.innerHTML = html;
}

async function carregarQRsCliente(idEvento) {
    const r  = await API.get(`qrcodes.php?id_evento=${idEvento}`);
    const el = document.getElementById(`lista-qrcodes-${idEvento}`);
    if (!el) return;
    const lista = r.data || [];
    if (!lista.length) {
        el.innerHTML = '<p style="color:var(--text-muted);font-size:14px">Sem QR Codes gerados ainda.</p>';
        return;
    }
    el.innerHTML = lista.map(q => {
        const imgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(q.qr_code)}`;
        return `
        <div class="qr-invite-card">
            <img src="${imgUrl}" width="72" height="72" alt="QR">
            <div style="flex:1;min-width:0">
                <div class="qr-invite-name">${esc(q.nome_guest)}</div>
                <div class="qr-invite-meta" style="font-family:monospace;font-size:10px;word-break:break-all;margin-top:4px">${esc(q.qr_code)}</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0">
                <button onclick="verQRGrande(${jsStr(q.nome_guest)},${jsStr(q.qr_code)})" class="btn-icon" title="Ver em grande"><i class="ph ph-magnifying-glass-plus"></i></button>
                <a href="${imgUrl}" download="qr-${esc(q.nome_guest)}.png" class="btn-icon" style="display:flex;align-items:center;justify-content:center" title="Download"><i class="ph ph-download-simple"></i></a>
            </div>
        </div>`;
    }).join('');
}

async function convidarGuest(idEvento) {
    const nome  = document.getElementById(`inv-nome-${idEvento}`)?.value?.trim();
    const email = document.getElementById(`inv-email-${idEvento}`)?.value?.trim();
    if (!nome) { toast('Nome é obrigatório', 'error'); return; }
    const r = await API.post('convidados.php', { nome, email, id_evento: idEvento, estado_rsvp: 'pendente' });
    if (r?.status === 'ok') {
        toast(email ? 'Convidado adicionado e convite enviado!' : 'Convidado adicionado!');
        document.getElementById(`inv-nome-${idEvento}`).value  = '';
        document.getElementById(`inv-email-${idEvento}`).value = '';
        carregarConvidadosCliente(idEvento);
    } else {
        toast(r?.msg || 'Erro', 'error');
    }
}

async function adicionarPresenteCliente(idEvento) {
    const nome      = document.getElementById(`pr-nome-${idEvento}`)?.value?.trim();
    const categoria = document.getElementById(`pr-categoria-${idEvento}`)?.value?.trim();
    const preco     = document.getElementById(`pr-preco-${idEvento}`)?.value?.trim();
    if (!nome) { toast('Nome do presente é obrigatório', 'error'); return; }
    const r = await API.post('presentes.php', {
        nome_item: nome, categoria, preco_estimado: preco, id_evento: idEvento
    });
    if (r?.status === 'ok') {
        toast('Presente adicionado!');
        document.getElementById(`pr-nome-${idEvento}`).value      = '';
        document.getElementById(`pr-categoria-${idEvento}`).value = '';
        document.getElementById(`pr-preco-${idEvento}`).value     = '';
        carregarPresentesCliente(idEvento);
    } else {
        toast(r?.msg || 'Erro', 'error');
    }
}

async function reservarPresente(idPresente, idEvento) {
    const r = await API.put(`presentes.php?id=${idPresente}`, { estado: 'reservado' });
    if (r?.status === 'ok') {
        toast('Presente reservado!');
        carregarPresentesCliente(idEvento);
    } else {
        toast(r?.msg || 'Erro', 'error');
    }
}
</script>

<!-- MESA SIDE PANEL -->
<div id="msp-overlay" class="msp-overlay" onclick="fecharPainelMesa()"></div>
<div id="mesa-side-panel" class="mesa-side-panel">
    <div class="msp-header">
        <div>
            <h3>Editar Mesa</h3>
            <p>Clique em Guardar para confirmar</p>
        </div>
        <button class="msp-close" onclick="fecharPainelMesa()"><i class="ph ph-x"></i></button>
    </div>
    <!-- Live preview -->
    <div class="msp-preview" id="msp-preview"></div>
    <div class="msp-body">
        <input type="hidden" id="msp-id">
        <div class="msp-field">
            <label class="msp-label">Nome</label>
            <input type="text" id="msp-nome" class="msp-input" placeholder="Ex: Mesa dos Noivos" oninput="atualizarPreviewPanel()">
        </div>
        <div class="msp-field">
            <label class="msp-label">Forma</label>
            <div class="msp-tipo-toggle">
                <button class="msp-tipo-btn active" data-forma="round" onclick="setFormaPanel(this,'round')">
                    <i class="ph ph-circle"></i> <span>Redonda</span>
                </button>
                <button class="msp-tipo-btn" data-forma="rect" onclick="setFormaPanel(this,'rect')">
                    <i class="ph ph-rectangle"></i> <span>Retangular</span>
                </button>
            </div>
        </div>
        <div class="msp-field">
            <label class="msp-label">Tamanho &mdash; <span id="msp-tamanho-label">Médio</span></label>
            <input type="range" id="msp-tamanho" class="msp-slider" min="1" max="3" step="1" value="2" oninput="onTamanhoChange(this)">
            <div class="msp-slider-marks"><span>P</span><span>M</span><span>G</span></div>
        </div>
        <div class="msp-field">
            <label class="msp-label">Lugares &mdash; <span id="msp-lugares-val">8</span></label>
            <input type="range" id="msp-lugares" class="msp-slider" min="1" max="24" value="8" oninput="onLugaresChange(this)">
        </div>
        <div class="msp-field">
            <label class="msp-label">Cor da Toalha</label>
            <div class="msp-swatches">
                <button class="msp-swatch" data-cor="teal"    onclick="setCorPanel(this,'teal')"    title="Teal"    style="background:#ccfbf1;border-color:#0d9488"></button>
                <button class="msp-swatch" data-cor="rosa"    onclick="setCorPanel(this,'rosa')"    title="Rosa"    style="background:#fce7f3;border-color:#ec4899"></button>
                <button class="msp-swatch" data-cor="sage"    onclick="setCorPanel(this,'sage')"    title="Sage"    style="background:#dcfce7;border-color:#15803d"></button>
                <button class="msp-swatch" data-cor="marfim"  onclick="setCorPanel(this,'marfim')"  title="Marfim"  style="background:#fef9c3;border-color:#ca8a04"></button>
                <button class="msp-swatch" data-cor="azul"    onclick="setCorPanel(this,'azul')"    title="Azul"    style="background:#dbeafe;border-color:#2563eb"></button>
                <button class="msp-swatch" data-cor="lavanda" onclick="setCorPanel(this,'lavanda')" title="Lavanda" style="background:#ede9fe;border-color:#7c3aed"></button>
            </div>
        </div>
    </div>
    <div class="msp-footer">
        <button class="msp-btn-save" onclick="guardarMesaPanel()">
            <i class="ph ph-floppy-disk"></i> <span>Guardar</span>
        </button>
        <button class="msp-btn-del" onclick="eliminarMesaPanel()" title="Eliminar mesa">
            <i class="ph ph-trash"></i>
        </button>
    </div>
</div>
</body>
</html>
