<?php
// layouts/classic.php
// Variáveis disponíveis: $event, $settings, $guestName
$primaryColor  = $settings['primary_color'] ?? '#c9a96e';
$bgColor       = $settings['bg_color']      ?? '#faf7f2';
$textColor     = $settings['text_color']    ?? '#2c2416';
$goldLt        = lightenColor($primaryColor, 25);
$goldDk        = darkenColor($primaryColor, 15);

$eventName     = htmlspecialchars($event['nome_evento'] ?? '');
$eventDate     = !empty($event['data'])  ? date('d \d\e F \d\e Y', strtotime($event['data'])) : '';
$eventLocation = htmlspecialchars($event['local'] ?? '');
$eventHour     = $settings['ceremony_time'] ?? ($event['hora'] ?? '');
$receptionHour = $settings['reception_time'] ?? '';

$locName    = htmlspecialchars($settings['location_name']    ?? $eventLocation);
$locAddress = nl2br(htmlspecialchars($settings['location_address']     ?? ''));
$locMap     = $settings['location_map_url']     ?? '';
if (!preg_match('/^https:\/\//', $locMap)) $locMap = '';
$locParking = nl2br(htmlspecialchars($settings['location_parking_info'] ?? ''));

$dcTitle     = htmlspecialchars($settings['dresscode_title']     ?? 'Formal');
$dcSuggested = nl2br(htmlspecialchars($settings['dresscode_suggested'] ?? ''));
$dcAvoid     = nl2br(htmlspecialchars($settings['dresscode_avoid']     ?? ''));
$dcPalette   = nl2br(htmlspecialchars($settings['dresscode_palette']   ?? ''));
$dcImg1      = $settings['dresscode_image1'] ?? '';
$dcImg2      = $settings['dresscode_image2'] ?? '';
$dcImg3      = $settings['dresscode_image3'] ?? '';

$guestDisplay = htmlspecialchars($guestName ?? '');
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $eventName ?> — Convite</title>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        :root {
            --gold:    <?= $primaryColor ?>;
            --gold-lt: <?= $goldLt ?>;
            --gold-dk: <?= $goldDk ?>;
            --cream:   <?= $bgColor ?>;
            --text:    <?= $textColor ?>;
            --dark:    #1a1209;
            --warm:    #f5ede0;
            --muted:   #8a7560;
            --border:  #e8ddd0;
            --white:   #ffffff;
        }

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        html { scroll-behavior: smooth; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--cream);
            color: var(--text);
            font-size: 16px;
            line-height: 1.6;
        }

        /* ─── NAV ─── */
        .nav {
            position: fixed;
            top: 0; left: 0; right: 0;
            background: rgba(26, 18, 9, 0.92);
            backdrop-filter: blur(8px);
            padding: .75rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            z-index: 100;
            border-bottom: 1px solid rgba(201,169,110,.2);
        }
        .nav-brand {
            font-family: 'Cormorant Garamond', serif;
            font-size: 1.25rem;
            color: var(--gold);
            letter-spacing: .08em;
        }
        .nav-links {
            display: flex;
            gap: 2rem;
            list-style: none;
        }
        .nav-links a {
            color: rgba(255,255,255,.75);
            text-decoration: none;
            font-size: .8rem;
            letter-spacing: .1em;
            text-transform: uppercase;
            transition: color .2s;
        }
        .nav-links a:hover { color: var(--gold); }

        /* ─── HERO ─── */
        .hero {
            min-height: 100vh;
            background: var(--dark);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        .hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 60% at 30% 40%, rgba(201,169,110,.08) 0%, transparent 60%),
                radial-gradient(ellipse 40% 50% at 70% 70%, rgba(201,169,110,.05) 0%, transparent 60%);
        }
        .hero-ornament {
            position: absolute;
            color: var(--gold);
            opacity: .07;
            font-size: 32rem;
            pointer-events: none;
            line-height: 1;
            font-family: 'Cormorant Garamond', serif;
            font-style: italic;
            bottom: -4rem;
            right: -2rem;
        }
        .hero-content {
            position: relative;
            text-align: center;
            padding: 2rem;
            max-width: 640px;
        }
        .hero-label {
            font-size: .75rem;
            letter-spacing: .25em;
            text-transform: uppercase;
            color: var(--gold);
            margin-bottom: 2rem;
        }
        .hero-divider {
            display: flex;
            align-items: center;
            gap: 1rem;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .hero-divider span { height: 1px; width: 60px; background: var(--gold); opacity: .5; }
        .hero-divider i { color: var(--gold); font-size: 1rem; }
        .hero-names {
            font-family: 'Cormorant Garamond', serif;
            font-size: clamp(2.8rem, 8vw, 5rem);
            font-weight: 300;
            color: var(--white);
            line-height: 1.1;
            margin-bottom: 1.5rem;
        }
        .hero-date {
            font-size: .9rem;
            letter-spacing: .2em;
            text-transform: uppercase;
            color: rgba(255,255,255,.6);
            margin-bottom: .75rem;
        }
        .hero-location {
            display: inline-flex;
            align-items: center;
            gap: .4rem;
            color: var(--gold);
            font-size: .9rem;
            margin-bottom: 3rem;
        }
        .hero-guest {
            display: inline-block;
            border: 1px solid rgba(201,169,110,.35);
            padding: .5rem 1.5rem;
            border-radius: 2rem;
            font-size: .85rem;
            color: rgba(255,255,255,.7);
            margin-bottom: 2.5rem;
            letter-spacing: .05em;
        }
        .hero-guest strong { color: var(--gold); font-weight: 500; }
        .hero-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn-primary {
            background: var(--gold);
            color: var(--dark);
            padding: .8rem 2rem;
            border-radius: .375rem;
            font-size: .85rem;
            letter-spacing: .1em;
            text-transform: uppercase;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            transition: background .2s, transform .15s;
            border: none;
            cursor: pointer;
        }
        .btn-primary:hover { background: var(--gold-lt); transform: translateY(-1px); }
        .btn-outline {
            background: transparent;
            color: rgba(255,255,255,.8);
            padding: .8rem 2rem;
            border-radius: .375rem;
            font-size: .85rem;
            letter-spacing: .1em;
            text-transform: uppercase;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            border: 1px solid rgba(255,255,255,.25);
            transition: border-color .2s, color .2s;
            cursor: pointer;
            background: none;
        }
        .btn-outline:hover { border-color: var(--gold); color: var(--gold); }

        /* ─── SECTIONS ─── */
        section { padding: 5rem 1.5rem; }
        .section-inner { max-width: 860px; margin: 0 auto; }
        .section-label {
            font-size: .7rem;
            letter-spacing: .25em;
            text-transform: uppercase;
            color: var(--gold);
            margin-bottom: .75rem;
        }
        .section-title {
            font-family: 'Cormorant Garamond', serif;
            font-size: clamp(1.8rem, 4vw, 2.6rem);
            font-weight: 300;
            line-height: 1.2;
            margin-bottom: 1.25rem;
        }
        .section-subtitle {
            color: var(--muted);
            font-size: .95rem;
            max-width: 540px;
        }
        .section-hr {
            border: none;
            border-top: 1px solid var(--border);
            margin: 3rem 0;
        }

        /* ─── COUNTDOWN ─── */
        .countdown-section { background: var(--dark); }
        .countdown-section .section-title,
        .countdown-section .section-label { color: var(--white); }
        .countdown-section .section-title { color: var(--white); }
        .countdown-grid {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
            margin-top: 2.5rem;
        }
        .countdown-item {
            flex: 1 1 90px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(201,169,110,.2);
            border-radius: .5rem;
            padding: 1.5rem 1rem;
            text-align: center;
        }
        .countdown-number {
            font-family: 'Cormorant Garamond', serif;
            font-size: 3rem;
            font-weight: 300;
            color: var(--gold);
            line-height: 1;
            display: block;
        }
        .countdown-label {
            font-size: .7rem;
            letter-spacing: .15em;
            text-transform: uppercase;
            color: rgba(255,255,255,.45);
            margin-top: .4rem;
            display: block;
        }

        /* ─── SCHEDULE ─── */
        .schedule-list { margin-top: 2rem; display: flex; flex-direction: column; gap: 1rem; }
        .schedule-item {
            display: flex;
            align-items: flex-start;
            gap: 1.25rem;
            padding: 1.25rem 1.5rem;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: .5rem;
        }
        .schedule-time {
            font-family: 'Cormorant Garamond', serif;
            font-size: 1.3rem;
            font-weight: 400;
            color: var(--gold);
            min-width: 75px;
        }
        .schedule-info h4 {
            font-size: .95rem;
            font-weight: 600;
            margin-bottom: .2rem;
            color: var(--text);
        }
        .schedule-info p { font-size: .85rem; color: var(--muted); }

        /* ─── DRESS CODE ─── */
        .dresscode-section { background: var(--warm); }
        .dresscode-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5rem;
            margin-top: 2.5rem;
        }
        .dresscode-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: .5rem;
            padding: 1.5rem;
        }
        .dresscode-card h4 {
            display: flex;
            align-items: center;
            gap: .5rem;
            font-size: .8rem;
            letter-spacing: .1em;
            text-transform: uppercase;
            color: var(--gold);
            margin-bottom: .75rem;
        }
        .dresscode-card p { font-size: .88rem; color: var(--muted); line-height: 1.6; }
        .dresscode-images {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: .75rem;
            margin-top: 2rem;
        }
        .dresscode-images img {
            width: 100%;
            aspect-ratio: 3/4;
            object-fit: cover;
            border-radius: .375rem;
            border: 1px solid var(--border);
        }

        /* ─── LOCATION ─── */
        .location-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
            margin-top: 2.5rem;
        }
        @media (max-width: 640px) { .location-grid { grid-template-columns: 1fr; } }
        .location-info h3 {
            font-family: 'Cormorant Garamond', serif;
            font-size: 1.5rem;
            font-weight: 400;
            margin-bottom: .75rem;
        }
        .location-info p { font-size: .9rem; color: var(--muted); line-height: 1.7; }
        .location-detail {
            display: flex;
            align-items: flex-start;
            gap: .6rem;
            margin-top: 1rem;
            font-size: .88rem;
            color: var(--muted);
        }
        .location-detail i { color: var(--gold); margin-top: .1rem; flex-shrink: 0; }
        .map-container {
            border-radius: .5rem;
            overflow: hidden;
            border: 1px solid var(--border);
            height: 280px;
        }
        .map-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        .map-placeholder {
            width: 100%;
            height: 100%;
            background: var(--warm);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            color: var(--muted);
            font-size: .9rem;
        }
        .map-placeholder i { font-size: 2rem; color: var(--gold); }

        /* ─── RSVP ─── */
        .rsvp-section { background: var(--dark); text-align: center; }
        .rsvp-section .section-title { color: var(--white); }
        .rsvp-section .section-label { color: var(--gold); }
        .rsvp-subtitle { color: rgba(255,255,255,.55); font-size: .95rem; margin-bottom: 2.5rem; }
        .rsvp-form {
            max-width: 500px;
            margin: 0 auto;
        }
        .rsvp-options {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        .rsvp-btn {
            flex: 1 1 160px;
            padding: 1rem;
            border-radius: .5rem;
            border: 1px solid;
            cursor: pointer;
            font-size: .85rem;
            letter-spacing: .08em;
            font-family: inherit;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: .4rem;
            transition: all .2s;
        }
        .rsvp-btn i { font-size: 1.4rem; }
        .rsvp-btn.accept {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark);
        }
        .rsvp-btn.accept:hover { background: var(--gold-lt); border-color: var(--gold-lt); }
        .rsvp-btn.decline {
            background: transparent;
            border-color: rgba(255,255,255,.25);
            color: rgba(255,255,255,.7);
        }
        .rsvp-btn.decline:hover { border-color: #c0392b; color: #c0392b; }
        .rsvp-status {
            margin-top: 1.5rem;
            padding: 1rem 1.5rem;
            border-radius: .5rem;
            font-size: .9rem;
            display: none;
        }
        .rsvp-status.success { background: rgba(201,169,110,.15); border: 1px solid rgba(201,169,110,.4); color: var(--gold); }
        .rsvp-status.error   { background: rgba(192,57,43,.1); border: 1px solid rgba(192,57,43,.35); color: #e74c3c; }

        /* ─── QR ─── */
        .qr-section { text-align: center; }
        #qrcode { display: inline-block; padding: 1rem; background: var(--white); border: 1px solid var(--border); border-radius: .5rem; margin-top: 2rem; }

        /* ─── FOOTER ─── */
        footer {
            background: var(--dark);
            color: rgba(255,255,255,.4);
            text-align: center;
            padding: 2rem;
            font-size: .8rem;
            border-top: 1px solid rgba(201,169,110,.15);
        }
        footer span { color: var(--gold); }

        /* ─── RESPONSIVE ─── */
        @media (max-width: 640px) {
            .nav-links { display: none; }
            .hero-actions { flex-direction: column; align-items: center; }
            .dresscode-images { grid-template-columns: repeat(2, 1fr); }
            .dresscode-images img:last-child:nth-child(odd) { grid-column: 1/-1; }
        }

        /* ─── TOAST ─── */
        .toast {
            position: fixed; bottom: 2rem; left: 50%; transform: translateX(-50%);
            background: var(--dark); color: var(--white);
            padding: .75rem 1.5rem; border-radius: 2rem;
            font-size: .85rem; z-index: 999;
            border: 1px solid rgba(201,169,110,.3);
            opacity: 0; transition: opacity .3s;
            pointer-events: none;
        }
        .toast.show { opacity: 1; }
    </style>
</head>
<body>

<!-- NAV -->
<nav class="nav">
    <span class="nav-brand"><?= $eventName ?></span>
    <ul class="nav-links">
        <li><a href="#countdown">Contagem</a></li>
        <li><a href="#schedule">Programa</a></li>
        <li><a href="#dresscode">Dress Code</a></li>
        <li><a href="#location">Local</a></li>
        <li><a href="#rsvp">RSVP</a></li>
    </ul>
</nav>

<!-- HERO -->
<section class="hero" id="hero">
    <div class="hero-ornament">&</div>
    <div class="hero-content">
        <p class="hero-label">Tens um convite especial</p>
        <div class="hero-divider">
            <span></span>
            <i class="ph ph-flower-tulip"></i>
            <span></span>
        </div>
        <h1 class="hero-names"><em><?= $eventName ?></em></h1>
        <?php if ($eventDate): ?>
        <p class="hero-date"><?= $eventDate ?></p>
        <?php endif; ?>
        <?php if ($locName): ?>
        <p class="hero-location"><i class="ph ph-map-pin"></i> <?= $locName ?></p>
        <?php endif; ?>
        <?php if ($guestDisplay): ?>
        <div class="hero-guest">Convite de <strong><?= $guestDisplay ?></strong></div>
        <?php endif; ?>
        <div class="hero-actions">
            <a href="#rsvp" class="btn-primary"><i class="ph ph-check-circle"></i> Confirmar Presença</a>
            <a href="#location" class="btn-outline"><i class="ph ph-map-trifold"></i> Ver Local</a>
        </div>
    </div>
</section>

<!-- COUNTDOWN -->
<?php if (!empty($event['data'])): ?>
<section class="countdown-section" id="countdown">
    <div class="section-inner">
        <p class="section-label">Faltam apenas</p>
        <h2 class="section-title" style="color:var(--white)">Contagem Decrescente</h2>
        <div class="countdown-grid">
            <div class="countdown-item"><span class="countdown-number" id="cd-days">--</span><span class="countdown-label">Dias</span></div>
            <div class="countdown-item"><span class="countdown-number" id="cd-hours">--</span><span class="countdown-label">Horas</span></div>
            <div class="countdown-item"><span class="countdown-number" id="cd-mins">--</span><span class="countdown-label">Minutos</span></div>
            <div class="countdown-item"><span class="countdown-number" id="cd-secs">--</span><span class="countdown-label">Segundos</span></div>
        </div>
    </div>
</section>
<script>
(function(){
    var target = new Date(<?= json_encode(($event['data'] ?? '') . ($eventHour ? ' '.$eventHour : ' 00:00:00')) ?>);
    function tick(){
        var diff = target - Date.now();
        if(diff < 0){ diff = 0; }
        var d = Math.floor(diff/86400000);
        var h = Math.floor((diff%86400000)/3600000);
        var m = Math.floor((diff%3600000)/60000);
        var s = Math.floor((diff%60000)/1000);
        document.getElementById('cd-days').textContent  = String(d).padStart(2,'0');
        document.getElementById('cd-hours').textContent = String(h).padStart(2,'0');
        document.getElementById('cd-mins').textContent  = String(m).padStart(2,'0');
        document.getElementById('cd-secs').textContent  = String(s).padStart(2,'0');
    }
    tick(); setInterval(tick, 1000);
})();
</script>
<?php endif; ?>

<!-- SCHEDULE -->
<?php if ($eventHour || $receptionHour): ?>
<section id="schedule">
    <div class="section-inner">
        <p class="section-label">Programa</p>
        <h2 class="section-title">O Dia do Evento</h2>
        <div class="schedule-list">
            <?php if ($eventHour): ?>
            <div class="schedule-item">
                <div class="schedule-time"><?= htmlspecialchars(substr($eventHour,0,5)) ?></div>
                <div class="schedule-info">
                    <h4>Cerimónia</h4>
                    <p><?= $locName ?: 'A definir' ?></p>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($receptionHour): ?>
            <div class="schedule-item">
                <div class="schedule-time"><?= htmlspecialchars(substr($receptionHour,0,5)) ?></div>
                <div class="schedule-info">
                    <h4>Receção</h4>
                    <p>Cocktail e jantar de gala</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<hr class="section-hr" style="max-width:860px;margin:0 auto;">
<?php endif; ?>

<!-- DRESS CODE -->
<section class="dresscode-section" id="dresscode">
    <div class="section-inner">
        <p class="section-label">Dress Code</p>
        <h2 class="section-title"><?= $dcTitle ?></h2>
        <div class="dresscode-grid">
            <?php if ($dcSuggested): ?>
            <div class="dresscode-card">
                <h4><i class="ph ph-check-circle"></i> Sugerido</h4>
                <p><?= $dcSuggested ?></p>
            </div>
            <?php endif; ?>
            <?php if ($dcAvoid): ?>
            <div class="dresscode-card">
                <h4><i class="ph ph-x-circle"></i> Evitar</h4>
                <p><?= $dcAvoid ?></p>
            </div>
            <?php endif; ?>
            <?php if ($dcPalette): ?>
            <div class="dresscode-card">
                <h4><i class="ph ph-palette"></i> Paleta de Cores</h4>
                <p><?= $dcPalette ?></p>
            </div>
            <?php endif; ?>
        </div>
        <?php if ($dcImg1 || $dcImg2 || $dcImg3): ?>
        <div class="dresscode-images">
            <?php foreach ([$dcImg1,$dcImg2,$dcImg3] as $img): ?>
                <?php if ($img): ?><img src="<?= htmlspecialchars($img) ?>" alt="Dress code" loading="lazy"><?php endif; ?>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- LOCATION -->
<?php if ($locName || $locAddress): ?>
<section id="location">
    <div class="section-inner">
        <p class="section-label">Como Chegar</p>
        <h2 class="section-title">Local do Evento</h2>
        <div class="location-grid">
            <div class="location-info">
                <h3><?= $locName ?></h3>
                <?php if ($locAddress): ?>
                <div class="location-detail"><i class="ph ph-map-pin"></i><p><?= $locAddress ?></p></div>
                <?php endif; ?>
                <?php if ($eventHour): ?>
                <div class="location-detail"><i class="ph ph-clock"></i><p>Cerimónia às <?= htmlspecialchars(substr($eventHour,0,5)) ?></p></div>
                <?php endif; ?>
                <?php if ($locParking): ?>
                <div class="location-detail"><i class="ph ph-car"></i><p><?= $locParking ?></p></div>
                <?php endif; ?>
                <?php if ($locMap): ?>
                <a href="<?= htmlspecialchars($locMap) ?>" target="_blank" class="btn-primary" style="margin-top:1.25rem;display:inline-flex;">
                    <i class="ph ph-navigation-arrow"></i> Abrir no Google Maps
                </a>
                <?php endif; ?>
            </div>
            <div class="map-container">
                <?php if ($locMap): ?>
                <iframe src="<?= htmlspecialchars($locMap) ?>" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                <?php else: ?>
                <div class="map-placeholder">
                    <i class="ph ph-map-trifold"></i>
                    <span>Mapa não configurado</span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- RSVP -->
<section class="rsvp-section" id="rsvp">
    <div class="section-inner">
        <p class="section-label">A Sua Resposta</p>
        <h2 class="section-title">Vai Estar Presente?</h2>
        <p class="rsvp-subtitle">A sua confirmação é muito importante para nós.</p>
        <div class="rsvp-form">
            <div class="rsvp-options">
                <button class="rsvp-btn accept" onclick="submitRSVP('confirmado')">
                    <i class="ph ph-check-fat"></i>
                    <strong>Sim, Confirmo!</strong>
                    <span style="font-size:.78rem;opacity:.8">Estarei presente</span>
                </button>
                <button class="rsvp-btn decline" onclick="submitRSVP('recusado')">
                    <i class="ph ph-x-square"></i>
                    <strong>Não Poderei Ir</strong>
                    <span style="font-size:.78rem;opacity:.7">Lamento a ausência</span>
                </button>
            </div>
            <div class="rsvp-status" id="rsvp-status"></div>
        </div>
    </div>
</section>

<?php if (!empty($guestQrCode)): ?>
<!-- QR CODE -->
<section class="qr-section" id="qr">
    <div class="section-inner">
        <p class="section-label">O Seu Código</p>
        <h2 class="section-title">QR de Entrada</h2>
        <p class="section-subtitle" style="margin:0 auto;">Apresente este código na entrada do evento.</p>
        <div id="qrcode">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=<?= urlencode($guestQrCode) ?>"
                 alt="QR Code de Entrada" width="160" height="160"
                 style="border-radius:6px;">
            <p style="margin-top:.75rem;font-family:monospace;font-size:.8rem;color:var(--muted);">
                <?= htmlspecialchars($guestQrCode) ?>
            </p>
        </div>
    </div>
</section>
<?php endif; ?>

<footer>
    <p>Feito com ❤️ para <span><?= $guestDisplay ?: 'você' ?></span></p>
    <p style="margin-top:.4rem;">© <?= date('Y') ?> <?= $eventName ?></p>
</footer>

<div class="toast" id="toast"></div>

<script>
// RSVP
async function submitRSVP(resposta) {
    try {
        const res = await fetch('api/rsvp.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ resposta })
        });
        const data = await res.json();
        const el = document.getElementById('rsvp-status');
        el.style.display = 'block';
        if (data.status === 'ok') {
            el.className = 'rsvp-status success';
            el.innerHTML = '<i class="ph ph-check-circle"></i> ' +
                (resposta === 'confirmado' ? 'Presença confirmada! Até breve 🎉' : 'Resposta registada. Até uma próxima!');
        } else {
            el.className = 'rsvp-status error';
            el.textContent = data.msg || 'Erro ao registar resposta.';
        }
    } catch(e) {
        showToast('Erro de ligação.'); 
    }
}

function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
}
</script>
</body>
</html>
