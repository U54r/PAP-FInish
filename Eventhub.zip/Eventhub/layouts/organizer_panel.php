<?php
// layouts/organizer_panel.php — Painel de edição flutuante (organizador ou cliente do evento)
// Variáveis disponíveis: $event, $settings, $_SESSION
$orgEventId   = (int) $event['id_evento'];
$orgEventName = htmlspecialchars($event['nome_evento'] ?? '', ENT_QUOTES, 'UTF-8');
$orgBackUrl   = htmlspecialchars($editorBackUrl   ?? 'dashboard.php',     ENT_QUOTES, 'UTF-8');
$orgBackLabel = htmlspecialchars($editorBackLabel   ?? '← Dashboard',     ENT_QUOTES, 'UTF-8');
$orgBanner    = htmlspecialchars($editorBannerLabel ?? 'Pré-visualização', ENT_QUOTES, 'UTF-8');
?>
<style>
/* ── Banner de pré-visualização ─────────────────────────────────────────── */
#org-banner {
    position: fixed; top: 0; left: 0; right: 0; height: 46px;
    background: #111827; color: #fff;
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 20px; z-index: 10001; font-size: 13px;
    border-bottom: 2px solid #c9a96e; box-shadow: 0 2px 12px rgba(0,0,0,.4);
}
#org-banner .banner-left { display: flex; align-items: center; gap: 10px; }
#org-banner .banner-pill {
    background: #c9a96e; color: #111827; font-size: 10px; font-weight: 700;
    letter-spacing: .12em; text-transform: uppercase;
    padding: 3px 10px; border-radius: 20px;
}
#org-banner .banner-event { color: #d1d5db; font-size: 13px; }
#org-banner .banner-right { display: flex; align-items: center; gap: 10px; }
.org-btn-edit {
    background: #c9a96e; color: #111827; border: none;
    padding: 6px 16px; border-radius: 6px; font-size: 12px; font-weight: 700;
    cursor: pointer; display: flex; align-items: center; gap: 6px;
    transition: background .15s;
}
.org-btn-edit:hover { background: #b8975e; }
.org-btn-back {
    color: #9ca3af; text-decoration: none; font-size: 12px;
    padding: 6px 12px; border-radius: 6px; border: 1px solid #374151;
    transition: color .15s, border-color .15s;
}
.org-btn-back:hover { color: #fff; border-color: #6b7280; }

/* ── Painel lateral ─────────────────────────────────────────────────────── */
#org-panel {
    position: fixed; top: 0; right: -460px; width: 460px; bottom: 0;
    background: #111827; z-index: 10002; overflow-y: auto;
    transition: right .3s cubic-bezier(.4,0,.2,1);
    border-left: 2px solid #c9a96e;
    box-shadow: -4px 0 24px rgba(0,0,0,.5);
    display: flex; flex-direction: column;
}
#org-panel.open { right: 0; }

#org-panel-head {
    position: sticky; top: 0; background: #111827;
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 20px; border-bottom: 1px solid #1f2937; z-index: 1;
}
#org-panel-head h2 { font-size: 15px; font-weight: 700; color: #fff; margin: 0; }
#org-panel-close {
    background: none; border: none; color: #6b7280; cursor: pointer;
    font-size: 20px; line-height: 1; padding: 2px 6px;
    border-radius: 4px; transition: color .15s;
}
#org-panel-close:hover { color: #fff; }

#org-panel-body { padding: 16px 20px 40px; flex: 1; }

/* Form fields */
.org-section {
    margin-bottom: 4px; padding: 16px 0;
    border-bottom: 1px solid #1f2937;
}
.org-section:last-of-type { border-bottom: none; }
.org-section-title {
    font-size: 10px; font-weight: 700; letter-spacing: .18em;
    text-transform: uppercase; color: #c9a96e; margin-bottom: 14px;
}
.org-label {
    display: block; font-size: 11px; color: #9ca3af;
    margin: 12px 0 4px; letter-spacing: .05em;
}
.org-label:first-of-type { margin-top: 0; }
.org-input, .org-select, .org-textarea {
    width: 100%; background: #1f2937; border: 1px solid #374151;
    color: #f9fafb; border-radius: 6px; padding: 8px 11px;
    font-size: 13px; font-family: inherit; box-sizing: border-box;
    transition: border-color .15s;
}
.org-input:focus, .org-select:focus, .org-textarea:focus {
    outline: none; border-color: #c9a96e;
}
.org-textarea { resize: vertical; min-height: 72px; }
.org-color-row { display: flex; gap: 8px; align-items: center; }
.org-color-swatch {
    width: 38px; height: 34px; border-radius: 6px;
    border: 1px solid #374151; cursor: pointer; padding: 2px; flex-shrink: 0;
    background: none;
}
.org-color-row .org-input { flex: 1; }

/* Save button */
.org-save-btn {
    width: 100%; background: #c9a96e; color: #111827;
    border: none; padding: 13px; border-radius: 8px;
    font-size: 14px; font-weight: 700; cursor: pointer; margin-top: 20px;
    transition: background .15s; letter-spacing: .03em;
}
.org-save-btn:hover { background: #b8975e; }
.org-save-btn:disabled { opacity: .6; cursor: default; }
#org-save-status {
    margin-top: 10px; text-align: center;
    font-size: 12px; min-height: 18px;
}

/* Layout template thumbnails */
.layout-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 4px; }
.layout-option { position: relative; }
.layout-option input[type=radio] { display: none; }
.layout-option label {
    display: block; padding: 10px 8px; border: 1px solid #374151;
    border-radius: 8px; cursor: pointer; text-align: center;
    font-size: 12px; color: #9ca3af; transition: all .15s;
    margin: 0;
}
.layout-option input:checked + label {
    border-color: #c9a96e; color: #c9a96e; background: rgba(201,169,110,.08);
}
.layout-option label:hover { border-color: #6b7280; color: #d1d5db; }

/* Push content down */
body { padding-top: 46px !important; }
.nav { top: 46px !important; }
</style>

<!-- Banner de pré-visualização -->
<div id="org-banner">
    <div class="banner-left">
        <span class="banner-pill"><?= $orgBanner ?></span>
        <span class="banner-event"><?= $orgEventName ?></span>
    </div>
    <div class="banner-right">
        <button class="org-btn-edit" onclick="orgTogglePanel()">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            Editar Página
        </button>
        <a href="<?= $orgBackUrl ?>" class="org-btn-back"><?= $orgBackLabel ?></a>
    </div>
</div>

<!-- Painel lateral de edição -->
<div id="org-panel">
    <div id="org-panel-head">
        <h2>Configurar Página</h2>
        <button id="org-panel-close" onclick="orgTogglePanel()" title="Fechar">✕</button>
    </div>
    <div id="org-panel-body">

        <div class="org-section">
            <div class="org-section-title">Aparência</div>

            <span class="org-label">Template</span>
            <div class="layout-grid">
                <div class="layout-option">
                    <input type="radio" name="layout_template" id="tpl-classic" value="classic">
                    <label for="tpl-classic">Clássico</label>
                </div>
                <div class="layout-option">
                    <input type="radio" name="layout_template" id="tpl-modern" value="modern">
                    <label for="tpl-modern">Moderno</label>
                </div>
                <div class="layout-option">
                    <input type="radio" name="layout_template" id="tpl-elegant" value="elegant">
                    <label for="tpl-elegant">Elegante</label>
                </div>
                <div class="layout-option">
                    <input type="radio" name="layout_template" id="tpl-rustic" value="rustic">
                    <label for="tpl-rustic">Rústico</label>
                </div>
            </div>

            <span class="org-label">Cor Principal</span>
            <div class="org-color-row">
                <input type="color" class="org-color-swatch" id="swatch-primary" value="#c9a96e"
                       oninput="document.getElementById('f-primary').value=this.value">
                <input type="text" class="org-input" name="primary_color" id="f-primary" value="#c9a96e"
                       oninput="document.getElementById('swatch-primary').value=this.value">
            </div>

            <span class="org-label">Cor de Fundo</span>
            <div class="org-color-row">
                <input type="color" class="org-color-swatch" id="swatch-bg" value="#faf7f2"
                       oninput="document.getElementById('f-bg').value=this.value">
                <input type="text" class="org-input" name="bg_color" id="f-bg" value="#faf7f2"
                       oninput="document.getElementById('swatch-bg').value=this.value">
            </div>

            <span class="org-label">Cor do Texto</span>
            <div class="org-color-row">
                <input type="color" class="org-color-swatch" id="swatch-text" value="#2c2416"
                       oninput="document.getElementById('f-text').value=this.value">
                <input type="text" class="org-input" name="text_color" id="f-text" value="#2c2416"
                       oninput="document.getElementById('swatch-text').value=this.value">
            </div>
        </div>

        <div class="org-section">
            <div class="org-section-title">Horários</div>
            <span class="org-label">Hora da Cerimónia</span>
            <input type="time" class="org-input" name="ceremony_time" id="f-ceremony">
            <span class="org-label">Hora da Receção / Festa</span>
            <input type="time" class="org-input" name="reception_time" id="f-reception">
        </div>

        <div class="org-section">
            <div class="org-section-title">Localização</div>
            <span class="org-label">Nome do Espaço</span>
            <input type="text" class="org-input" name="location_name" id="f-loc-name" placeholder="ex: Quinta das Flores">
            <span class="org-label">Morada completa</span>
            <textarea class="org-textarea" name="location_address" id="f-loc-address" placeholder="Rua, nº, Código Postal, Localidade"></textarea>
            <span class="org-label">Informação de Estacionamento</span>
            <textarea class="org-textarea" name="location_parking_info" id="f-loc-parking" placeholder="ex: Parque gratuito disponível no local"></textarea>
            <span class="org-label">Link Google Maps (iframe embed)</span>
            <input type="url" class="org-input" name="location_map_url" id="f-loc-map"
                   placeholder="https://www.google.com/maps/embed?pb=...">
            <p style="font-size:11px;color:#6b7280;margin-top:6px;line-height:1.5;">
                No Google Maps: Partilhar → Incorporar mapa → copiar o URL do src="" do iframe.
            </p>
        </div>

        <div class="org-section">
            <div class="org-section-title">Dress Code</div>
            <span class="org-label">Título</span>
            <input type="text" class="org-input" name="dresscode_title" id="f-dc-title" placeholder="ex: Formal, Smart Casual…">
            <span class="org-label">Sugerido</span>
            <textarea class="org-textarea" name="dresscode_suggested" id="f-dc-suggested"
                      placeholder="Descreva o vestuário recomendado..."></textarea>
            <span class="org-label">Evitar</span>
            <textarea class="org-textarea" name="dresscode_avoid" id="f-dc-avoid"
                      placeholder="O que os convidados devem evitar..."></textarea>
            <span class="org-label">Paleta de Cores</span>
            <textarea class="org-textarea" name="dresscode_palette" id="f-dc-palette" style="min-height:56px;"
                      placeholder="ex: Tons neutros, azul marinho, verde esmeralda…"></textarea>
        </div>

        <button class="org-save-btn" id="org-save-btn" onclick="orgSaveSettings()">
            Guardar e Atualizar Pré-visualização
        </button>
        <div id="org-save-status"></div>
    </div>
</div>

<script>
(function () {
    const EVENT_ID = <?= $orgEventId ?>;

    window.orgTogglePanel = function () {
        const panel = document.getElementById('org-panel');
        panel.classList.toggle('open');
    };

    async function orgLoadSettings() {
        try {
            const r = await fetch('api/guest_page_settings.php?id_evento=' + EVENT_ID);
            const d = await r.json();
            if (d.status !== 'ok') return;
            const s = d.data || {};

            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el && val != null) el.value = val;
            };
            const setColor = (swatchId, inputId, val) => {
                if (!val) return;
                setVal(swatchId, val);
                setVal(inputId, val);
            };

            // Template
            const tpl = s.layout_template || 'classic';
            const tplInput = document.getElementById('tpl-' + tpl);
            if (tplInput) tplInput.checked = true;

            setColor('swatch-primary', 'f-primary', s.primary_color);
            setColor('swatch-bg',      'f-bg',      s.bg_color);
            setColor('swatch-text',    'f-text',    s.text_color);

            setVal('f-ceremony',    s.ceremony_time    || '');
            setVal('f-reception',   s.reception_time   || '');
            setVal('f-loc-name',    s.location_name    || '');
            setVal('f-loc-address', s.location_address || '');
            setVal('f-loc-parking', s.location_parking_info || '');
            setVal('f-loc-map',     s.location_map_url || '');
            setVal('f-dc-title',    s.dresscode_title  || '');
            setVal('f-dc-suggested',s.dresscode_suggested || '');
            setVal('f-dc-avoid',    s.dresscode_avoid  || '');
            setVal('f-dc-palette',  s.dresscode_palette|| '');
        } catch (e) { console.error('[OrgPanel] load error', e); }
    }

    window.orgSaveSettings = async function () {
        const btn    = document.getElementById('org-save-btn');
        const status = document.getElementById('org-save-status');
        btn.disabled = true;
        status.style.color = '#9ca3af';
        status.textContent = 'A guardar…';

        // Collect form data
        const data = {};
        document.querySelectorAll('#org-panel-body [name]').forEach(el => {
            if (el.type === 'radio') { if (el.checked) data[el.name] = el.value; }
            else data[el.name] = el.value;
        });

        try {
            const r = await fetch('api/guest_page_settings.php?id_evento=' + EVENT_ID, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });
            const d = await r.json();
            if (d.status === 'ok') {
                status.style.color = '#86efac';
                status.textContent = '✓ Guardado! A recarregar…';
                setTimeout(() => location.reload(), 700);
            } else {
                status.style.color = '#fca5a5';
                status.textContent = 'Erro: ' + (d.msg || 'Falha ao guardar');
                btn.disabled = false;
            }
        } catch (e) {
            status.style.color = '#fca5a5';
            status.textContent = 'Erro de ligação.';
            btn.disabled = false;
        }
    };

    // Load settings when page is ready
    orgLoadSettings();
})();
</script>
