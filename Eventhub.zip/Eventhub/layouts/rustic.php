<?php
// layouts/rustic.php
$primaryColor  = $settings['primary_color'] ?? '#8b5e3c';
$bgColor       = $settings['bg_color']      ?? '#fdf6ec';
$textColor     = $settings['text_color']    ?? '#3b2a1a';
$goldLt        = lightenColor($primaryColor, 30);
$goldDk        = darkenColor($primaryColor, 15);

$eventName     = htmlspecialchars($event['nome_evento'] ?? '');
$eventDate     = !empty($event['data'])  ? date('d \d\e F \d\e Y', strtotime($event['data'])) : '';
$eventLocation = htmlspecialchars($event['local'] ?? '');
$eventHour     = $settings['ceremony_time']  ?? ($event['hora'] ?? '');
$receptionHour = $settings['reception_time'] ?? '';
$locName       = htmlspecialchars($settings['location_name'] ?? $eventLocation);
$locAddress    = nl2br(htmlspecialchars($settings['location_address'] ?? ''));
$locMap        = $settings['location_map_url'] ?? '';
if (!preg_match('/^https:\/\//', $locMap)) $locMap = '';
$locParking    = nl2br(htmlspecialchars($settings['location_parking_info'] ?? ''));
$dcTitle       = htmlspecialchars($settings['dresscode_title']    ?? 'Casual Elegante');
$dcSuggested   = nl2br(htmlspecialchars($settings['dresscode_suggested'] ?? ''));
$dcAvoid       = nl2br(htmlspecialchars($settings['dresscode_avoid']     ?? ''));
$dcPalette     = nl2br(htmlspecialchars($settings['dresscode_palette']   ?? ''));
$dcImg1        = $settings['dresscode_image1'] ?? '';
$dcImg2        = $settings['dresscode_image2'] ?? '';
$dcImg3        = $settings['dresscode_image3'] ?? '';
$guestDisplay  = htmlspecialchars($guestName ?? '');
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= $eventName ?> — Convite</title>
    <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;1,400;1,600&family=Nunito:wght@300;400;500;600&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        :root{
            --brown:  <?= $primaryColor ?>;
            --br-l:   <?= $goldLt ?>;
            --br-d:   <?= $goldDk ?>;
            --bg:     <?= $bgColor ?>;
            --text:   <?= $textColor ?>;
            --warm2:  #f5e9d5;
            --warm3:  #eedfc4;
            --muted:  #8a6a4e;
            --border: #dcc9ae;
            --white:  #fff;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        html{scroll-behavior:smooth;}
        body{font-family:'Nunito',sans-serif;background:var(--bg);color:var(--text);font-size:16px;line-height:1.65;overflow-x:hidden;}

        /* — PAPER TEXTURE — */
        body::after{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400'%3E%3Cfilter id='p'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='400' height='400' filter='url(%23p)' opacity='.035'/%3E%3C/svg%3E");pointer-events:none;z-index:0;}

        /* — NAV — */
        .nav{position:fixed;top:0;left:0;right:0;display:flex;align-items:center;justify-content:space-between;padding:.8rem 2rem;background:rgba(253,246,236,.93);backdrop-filter:blur(10px);border-bottom:2px solid var(--warm3);z-index:200;}
        .nav-brand{font-family:'Lora',serif;font-size:1rem;color:var(--brown);letter-spacing:.04em;}
        .nav-links{list-style:none;display:flex;gap:2rem;}
        .nav-links a{color:var(--muted);text-decoration:none;font-size:.8rem;font-weight:500;transition:color .2s;}
        .nav-links a:hover{color:var(--brown);}

        /* — HERO — */
        .hero{min-height:100vh;background:var(--warm2);display:flex;align-items:center;justify-content:center;padding:5rem 1.5rem;position:relative;overflow:hidden;}
        .hero-wreath{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:.06;}
        .hero-wreath svg{width:min(90vw,600px);height:auto;}
        .hero-content{position:relative;z-index:1;text-align:center;max-width:580px;}
        .hero-ribbon{display:inline-block;background:var(--brown);color:#fff;font-size:.68rem;letter-spacing:.2em;text-transform:uppercase;padding:.35rem 1.5rem;border-radius:.2rem;margin-bottom:2rem;}
        .hero-branch{color:var(--brown);opacity:.4;font-size:1.4rem;margin-bottom:.75rem;display:block;}
        .hero-title{font-family:'Lora',serif;font-size:clamp(2.4rem,7vw,4.5rem);font-weight:400;font-style:italic;line-height:1.15;color:var(--text);margin-bottom:1.5rem;}
        .hero-meta{display:flex;flex-direction:column;align-items:center;gap:.5rem;margin-bottom:2rem;}
        .hero-meta-row{display:inline-flex;align-items:center;gap:.5rem;font-size:.9rem;color:var(--muted);}
        .hero-meta-row i{color:var(--brown);}
        .hero-sep{color:var(--brown);opacity:.4;font-size:1.2rem;margin:1rem 0;}
        .hero-guest-card{display:inline-block;background:var(--white);border:1.5px solid var(--border);border-radius:.375rem;padding:.6rem 1.5rem;font-size:.85rem;color:var(--muted);margin-bottom:2.25rem;box-shadow:0 2px 8px rgba(139,94,60,.08);}
        .hero-guest-card strong{color:var(--text);}
        .hero-ctas{display:flex;gap:.85rem;justify-content:center;flex-wrap:wrap;}
        .btn-r{display:inline-flex;align-items:center;gap:.5rem;padding:.75rem 1.75rem;border-radius:.375rem;font-size:.88rem;font-family:'Nunito',sans-serif;font-weight:600;text-decoration:none;cursor:pointer;transition:all .2s;border:none;}
        .btn-r-fill{background:var(--brown);color:#fff;}
        .btn-r-fill:hover{background:var(--br-d);}
        .btn-r-soft{background:var(--white);color:var(--text);border:1.5px solid var(--border);}
        .btn-r-soft:hover{border-color:var(--brown);color:var(--brown);}

        /* — SECTIONS — */
        .sec{padding:5rem 1.5rem;}
        .sec-inner{max-width:820px;margin:0 auto;}
        .sec-tag{display:inline-flex;align-items:center;gap:.4rem;font-size:.72rem;letter-spacing:.15em;text-transform:uppercase;color:var(--brown);margin-bottom:.6rem;}
        .sec-title{font-family:'Lora',serif;font-size:clamp(1.6rem,3.5vw,2.3rem);font-weight:500;margin-bottom:.5rem;}
        .sec-sub{font-size:.9rem;color:var(--muted);max-width:480px;}

        /* — COUNTDOWN — */
        .cd-row{display:flex;gap:1rem;flex-wrap:wrap;margin-top:2.5rem;}
        .cd-item{flex:1 1 90px;background:var(--white);border:1.5px solid var(--border);border-radius:.5rem;padding:1.5rem 1rem;text-align:center;box-shadow:0 2px 10px rgba(139,94,60,.07);}
        .cd-num{font-family:'Lora',serif;font-size:2.6rem;font-weight:500;color:var(--brown);display:block;line-height:1;}
        .cd-lbl{font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);margin-top:.4rem;display:block;}

        /* — SCHEDULE — */
        .sched-sec{background:var(--warm2);}
        .sched-list{margin-top:2.25rem;display:flex;flex-direction:column;gap:.85rem;}
        .sched-item{display:flex;gap:1.25rem;align-items:flex-start;background:var(--white);border:1.5px solid var(--border);border-radius:.5rem;padding:1.25rem 1.5rem;box-shadow:0 2px 8px rgba(139,94,60,.06);}
        .sched-icon{width:2.25rem;height:2.25rem;background:var(--warm2);border:1.5px solid var(--border);border-radius:.375rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:.1rem;}
        .sched-icon i{color:var(--brown);}
        .sched-time{font-size:.8rem;font-weight:700;color:var(--brown);letter-spacing:.05em;margin-bottom:.15rem;}
        .sched-name{font-size:.95rem;font-weight:600;}
        .sched-loc{font-size:.83rem;color:var(--muted);}

        /* — DRESS CODE — */
        .dc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.25rem;margin-top:2.25rem;}
        .dc-card{background:var(--white);border:1.5px solid var(--border);border-radius:.5rem;padding:1.5rem;box-shadow:0 2px 8px rgba(139,94,60,.06);}
        .dc-card-hd{display:flex;align-items:center;gap:.5rem;font-size:.78rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--brown);margin-bottom:.65rem;}
        .dc-card p{font-size:.88rem;color:var(--muted);line-height:1.65;}
        .dc-imgs{display:grid;grid-template-columns:repeat(3,1fr);gap:.85rem;margin-top:1.75rem;}
        .dc-imgs img{width:100%;aspect-ratio:3/4;object-fit:cover;border-radius:.375rem;border:1.5px solid var(--border);}

        /* — LOCATION — */
        .loc-grid{display:grid;grid-template-columns:1fr 1fr;gap:2rem;margin-top:2.25rem;}
        .loc-name{font-family:'Lora',serif;font-size:1.4rem;font-style:italic;margin-bottom:.85rem;}
        .loc-row{display:flex;align-items:flex-start;gap:.65rem;font-size:.88rem;color:var(--muted);margin-top:.65rem;line-height:1.6;}
        .loc-row i{color:var(--brown);margin-top:.1rem;flex-shrink:0;}
        .map-box{border-radius:.5rem;overflow:hidden;border:1.5px solid var(--border);height:280px;box-shadow:0 2px 12px rgba(139,94,60,.1);}
        .map-box iframe{width:100%;height:100%;border:none;}
        .map-empty{width:100%;height:100%;background:var(--warm2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.5rem;color:var(--muted);font-size:.9rem;}
        .map-empty i{font-size:2rem;color:var(--brown);}

        /* — RSVP — */
        .rsvp-sec{background:var(--warm2);}
        .rsvp-inner{background:var(--white);border:1.5px solid var(--border);border-radius:.75rem;padding:3rem 2rem;text-align:center;max-width:520px;margin:2.5rem auto 0;box-shadow:0 4px 20px rgba(139,94,60,.1);}
        .rsvp-inner .sec-title{margin-bottom:.5rem;}
        .rsvp-inner p{font-size:.9rem;color:var(--muted);margin-bottom:2rem;}
        .rsvp-btns{display:flex;gap:.85rem;justify-content:center;flex-wrap:wrap;}
        .rsvp-fb{margin-top:1.25rem;padding:.75rem 1rem;border-radius:.375rem;font-size:.9rem;display:none;}
        .rsvp-fb.ok{background:#f0fdf4;border:1px solid #86efac;color:#166534;}
        .rsvp-fb.err{background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;}

        /* — DIVIDER — */
        .rustic-divider{display:flex;align-items:center;gap:1rem;max-width:820px;margin:0 auto;padding:0 1.5rem;}
        .rustic-divider span{flex:1;height:1px;background:var(--border);}
        .rustic-divider i{color:var(--brown);font-size:1rem;opacity:.5;}

        footer{text-align:center;padding:2.5rem;font-size:.82rem;color:var(--muted);border-top:1.5px solid var(--border);}
        footer strong{color:var(--brown);}

        @media(max-width:640px){
            .loc-grid{grid-template-columns:1fr;}
            .dc-imgs{grid-template-columns:repeat(2,1fr);}
            .nav-links{display:none;}
        }
    </style>
</head>
<body>

<nav class="nav">
    <span class="nav-brand"><?= $eventName ?></span>
    <ul class="nav-links">
        <li><a href="#schedule">Programa</a></li>
        <li><a href="#dresscode">Dress Code</a></li>
        <li><a href="#location">Local</a></li>
        <li><a href="#rsvp">RSVP</a></li>
    </ul>
</nav>

<!-- HERO -->
<section class="hero" id="hero">
    <div class="hero-wreath">
        <svg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="<?= $primaryColor ?>" stroke-width="1">
            <circle cx="200" cy="200" r="160"/>
            <circle cx="200" cy="200" r="148"/>
            <?php for($i=0;$i<24;$i++): $a=$i*15; $r1=152; $r2=165; $x1=200+$r1*cos(deg2rad($a)); $y1=200+$r1*sin(deg2rad($a)); $x2=200+$r2*cos(deg2rad($a)); $y2=200+$r2*sin(deg2rad($a)); ?>
            <line x1="<?=$x1?>" y1="<?=$y1?>" x2="<?=$x2?>" y2="<?=$y2?>"/>
            <?php endfor; ?>
        </svg>
    </div>
    <div class="hero-content">
        <div class="hero-ribbon">Convite Especial</div>
        <span class="hero-branch">✦ ❧ ✦</span>
        <h1 class="hero-title"><?= $eventName ?></h1>
        <div class="hero-meta">
            <?php if ($eventDate): ?><div class="hero-meta-row"><i class="ph ph-calendar-dots"></i><?= $eventDate ?></div><?php endif; ?>
            <?php if ($locName): ?><div class="hero-meta-row"><i class="ph ph-map-pin"></i><?= $locName ?></div><?php endif; ?>
        </div>
        <span class="hero-sep">❧</span>
        <?php if ($guestDisplay): ?>
        <div class="hero-guest-card">✉ Com carinho para <strong><?= $guestDisplay ?></strong></div>
        <?php endif; ?>
        <div class="hero-ctas">
            <a href="#rsvp" class="btn-r btn-r-fill"><i class="ph ph-check-circle"></i> Confirmar Presença</a>
            <a href="#location" class="btn-r btn-r-soft"><i class="ph ph-map-trifold"></i> Ver Local</a>
        </div>
    </div>
</section>

<!-- COUNTDOWN -->
<?php if (!empty($event['data'])): ?>
<section class="sec" id="countdown">
    <div class="sec-inner">
        <p class="sec-tag"><i class="ph ph-timer"></i> Contagem Decrescente</p>
        <h2 class="sec-title">O Grande Dia Está a Chegar</h2>
        <div class="cd-row">
            <div class="cd-item"><span class="cd-num" id="r-d">--</span><span class="cd-lbl">Dias</span></div>
            <div class="cd-item"><span class="cd-num" id="r-h">--</span><span class="cd-lbl">Horas</span></div>
            <div class="cd-item"><span class="cd-num" id="r-m">--</span><span class="cd-lbl">Minutos</span></div>
            <div class="cd-item"><span class="cd-num" id="r-s">--</span><span class="cd-lbl">Segundos</span></div>
        </div>
    </div>
</section>
<script>
(function(){
    var t=new Date(<?= json_encode(($event['data'] ?? '') . ($eventHour ? ' '.$eventHour : ' 00:00:00')) ?>);
    function tick(){
        var diff=Math.max(0,t-Date.now());
        document.getElementById('r-d').textContent=String(Math.floor(diff/86400000)).padStart(2,'0');
        document.getElementById('r-h').textContent=String(Math.floor(diff%86400000/3600000)).padStart(2,'0');
        document.getElementById('r-m').textContent=String(Math.floor(diff%3600000/60000)).padStart(2,'0');
        document.getElementById('r-s').textContent=String(Math.floor(diff%60000/1000)).padStart(2,'0');
    }
    tick();setInterval(tick,1000);
})();
</script>
<?php endif; ?>

<div class="rustic-divider"><span></span><i class="ph ph-leaf"></i><span></span></div>

<!-- SCHEDULE -->
<?php if ($eventHour||$receptionHour): ?>
<section class="sec sched-sec" id="schedule">
    <div class="sec-inner">
        <p class="sec-tag"><i class="ph ph-sun"></i> Programa</p>
        <h2 class="sec-title">O Nosso Dia</h2>
        <div class="sched-list">
            <?php if ($eventHour): ?>
            <div class="sched-item">
                <div class="sched-icon"><i class="ph ph-heart"></i></div>
                <div><p class="sched-time"><?= htmlspecialchars(substr($eventHour,0,5)) ?></p><p class="sched-name">Cerimónia</p><p class="sched-loc"><?= $locName ?: 'Local a confirmar' ?></p></div>
            </div>
            <?php endif; ?>
            <?php if ($receptionHour): ?>
            <div class="sched-item">
                <div class="sched-icon"><i class="ph ph-wine"></i></div>
                <div><p class="sched-time"><?= htmlspecialchars(substr($receptionHour,0,5)) ?></p><p class="sched-name">Receção & Jantar</p><p class="sched-loc">Celebração em família</p></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<div class="rustic-divider"><span></span><i class="ph ph-flower-tulip"></i><span></span></div>
<?php endif; ?>

<!-- DRESS CODE -->
<section class="sec" id="dresscode">
    <div class="sec-inner">
        <p class="sec-tag"><i class="ph ph-coat-hanger"></i> Dress Code</p>
        <h2 class="sec-title"><?= $dcTitle ?></h2>
        <div class="dc-grid">
            <?php if ($dcSuggested): ?><div class="dc-card"><p class="dc-card-hd"><i class="ph ph-check"></i> Sugerido</p><p><?= $dcSuggested ?></p></div><?php endif; ?>
            <?php if ($dcAvoid): ?><div class="dc-card"><p class="dc-card-hd"><i class="ph ph-x"></i> Evitar</p><p><?= $dcAvoid ?></p></div><?php endif; ?>
            <?php if ($dcPalette): ?><div class="dc-card"><p class="dc-card-hd"><i class="ph ph-palette"></i> Paleta</p><p><?= $dcPalette ?></p></div><?php endif; ?>
        </div>
        <?php if ($dcImg1||$dcImg2||$dcImg3): ?>
        <div class="dc-imgs">
            <?php foreach([$dcImg1,$dcImg2,$dcImg3] as $img): if($img): ?><img src="<?= htmlspecialchars($img) ?>" alt="" loading="lazy"><?php endif; endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<div class="rustic-divider"><span></span><i class="ph ph-tree-evergreen"></i><span></span></div>

<!-- LOCATION -->
<?php if ($locName||$locAddress): ?>
<section class="sec" id="location">
    <div class="sec-inner">
        <p class="sec-tag"><i class="ph ph-map-pin"></i> Como Chegar</p>
        <h2 class="sec-title">O Local</h2>
        <div class="loc-grid">
            <div>
                <p class="loc-name"><?= $locName ?></p>
                <?php if ($locAddress): ?><div class="loc-row"><i class="ph ph-map-pin"></i><span><?= $locAddress ?></span></div><?php endif; ?>
                <?php if ($eventHour): ?><div class="loc-row"><i class="ph ph-clock"></i><span>Às <?= htmlspecialchars(substr($eventHour,0,5)) ?></span></div><?php endif; ?>
                <?php if ($locParking): ?><div class="loc-row"><i class="ph ph-car"></i><span><?= $locParking ?></span></div><?php endif; ?>
                <?php if ($locMap): ?><a href="<?= htmlspecialchars($locMap) ?>" target="_blank" class="btn-r btn-r-fill" style="margin-top:1.25rem;"><i class="ph ph-navigation-arrow"></i> Abrir no Mapa</a><?php endif; ?>
            </div>
            <div class="map-box">
                <?php if ($locMap): ?><iframe src="<?= htmlspecialchars($locMap) ?>" allowfullscreen loading="lazy"></iframe>
                <?php else: ?><div class="map-empty"><i class="ph ph-map-trifold"></i><span>Mapa não configurado</span></div><?php endif; ?>
            </div>
        </div>
    </div>
</section>
<div class="rustic-divider"><span></span><i class="ph ph-sun"></i><span></span></div>
<?php endif; ?>

<!-- RSVP -->
<section class="sec rsvp-sec" id="rsvp">
    <div class="sec-inner">
        <div class="rsvp-inner">
            <p class="sec-tag" style="justify-content:center;"><i class="ph ph-envelope-open"></i> A Sua Resposta</p>
            <h2 class="sec-title">Vai Estar Presente?</h2>
            <p>A sua presença tornaria este momento ainda mais especial.</p>
            <div class="rsvp-btns">
                <button class="btn-r btn-r-fill" onclick="submitRSVP('confirmado')"><i class="ph ph-check-fat"></i> Sim, Com Prazer!</button>
                <button class="btn-r btn-r-soft" onclick="submitRSVP('recusado')"><i class="ph ph-x"></i> Não Poderei Ir</button>
            </div>
            <div class="rsvp-fb" id="rsvp-fb"></div>
        </div>
    </div>
</section>

<footer>Feito com ❤️ para <strong><?= $guestDisplay ?: 'você' ?></strong> &nbsp;·&nbsp; © <?= date('Y') ?> <?= $eventName ?></footer>

<script>
async function submitRSVP(r){
    const el=document.getElementById('rsvp-fb');
    try{
        const res=await fetch('api/rsvp.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({resposta:r})});
        const d=await res.json();
        el.style.display='block';
        if(d.status==='ok'){el.className='rsvp-fb ok';el.textContent=r==='confirmado'?'🌿 Presença confirmada! Estamos ansiosos.':'Resposta registada. Muito obrigado.';}
        else{el.className='rsvp-fb err';el.textContent=d.msg||'Erro ao registar.';}
    }catch{el.style.display='block';el.className='rsvp-fb err';el.textContent='Erro de ligação.';}
}
</script>
</body>
</html>
