<?php
// layouts/modern.php
$primaryColor  = $settings['primary_color'] ?? '#6c63ff';
$bgColor       = $settings['bg_color']      ?? '#f8f9fc';
$textColor     = $settings['text_color']    ?? '#111827';
$accentLight   = lightenColor($primaryColor, 40);

$eventName     = htmlspecialchars($event['nome_evento'] ?? '');
$eventDate     = !empty($event['data'])  ? date('d/m/Y', strtotime($event['data'])) : '';
$eventLocation = htmlspecialchars($event['local'] ?? '');
$eventHour     = $settings['ceremony_time']  ?? ($event['hora'] ?? '');
$receptionHour = $settings['reception_time'] ?? '';
$locName       = htmlspecialchars($settings['location_name'] ?? $eventLocation);
$locAddress    = nl2br(htmlspecialchars($settings['location_address'] ?? ''));
$locMap        = $settings['location_map_url'] ?? '';
if (!preg_match('/^https:\/\//', $locMap)) $locMap = '';
$locParking    = nl2br(htmlspecialchars($settings['location_parking_info'] ?? ''));
$dcTitle       = htmlspecialchars($settings['dresscode_title']    ?? 'Dress Code');
$dcSuggested   = nl2br(htmlspecialchars($settings['dresscode_suggested'] ?? ''));
$dcAvoid       = nl2br(htmlspecialchars($settings['dresscode_avoid']     ?? ''));
$dcPalette     = nl2br(htmlspecialchars($settings['dresscode_palette']   ?? ''));
$dcImg1        = $settings['dresscode_image1'] ?? '';
$dcImg2        = $settings['dresscode_image2'] ?? '';
$dcImg3        = $settings['dresscode_image3'] ?? '';
$guestDisplay  = htmlspecialchars($guestName ?? '');
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= $eventName ?> — Convite</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        :root{
            --accent:  <?= $primaryColor ?>;
            --accent-l:<?= $accentLight ?>;
            --bg:      <?= $bgColor ?>;
            --text:    <?= $textColor ?>;
            --muted:   #6b7280;
            --border:  #e5e7eb;
            --white:   #ffffff;
            --card-bg: #ffffff;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        html{scroll-behavior:smooth;}
        body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);font-size:16px;line-height:1.6;}

        /* NAV */
        .nav{position:fixed;top:0;left:0;right:0;padding:.9rem 2rem;display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.88);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);z-index:100;}
        .nav-brand{font-family:'Playfair Display',serif;font-size:1.1rem;color:var(--text);}
        .nav-links{list-style:none;display:flex;gap:1.75rem;}
        .nav-links a{color:var(--muted);text-decoration:none;font-size:.8rem;font-weight:500;text-transform:uppercase;letter-spacing:.08em;transition:color .2s;}
        .nav-links a:hover{color:var(--accent);}

        /* HERO */
        .hero{min-height:100vh;display:grid;grid-template-columns:1fr 1fr;background:var(--white);}
        .hero-left{background:var(--accent);display:flex;align-items:center;justify-content:center;padding:6rem 3rem;position:relative;overflow:hidden;}
        .hero-left::after{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg width='60' height='60' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='30' cy='30' r='1' fill='rgba(255,255,255,0.08)'/%3E%3C/svg%3E") repeat;}
        .hero-left-text{position:relative;z-index:1;color:#fff;text-align:center;}
        .hero-tag{font-size:.7rem;letter-spacing:.2em;text-transform:uppercase;opacity:.75;margin-bottom:1.25rem;display:block;}
        .hero-big-date{font-family:'Playfair Display',serif;font-size:clamp(3rem,6vw,5.5rem);font-weight:700;line-height:.9;margin-bottom:1.25rem;}
        .hero-right{display:flex;align-items:center;justify-content:center;padding:6rem 3rem;padding-top:7rem;}
        .hero-right-inner{max-width:420px;}
        .hero-eyebrow{font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;color:var(--accent);margin-bottom:1rem;display:block;}
        .hero-name{font-family:'Playfair Display',serif;font-size:clamp(2rem,4vw,3.2rem);font-weight:400;line-height:1.15;margin-bottom:1.25rem;}
        .hero-meta{display:flex;flex-direction:column;gap:.5rem;margin-bottom:2.25rem;}
        .hero-meta-item{display:flex;align-items:center;gap:.6rem;font-size:.88rem;color:var(--muted);}
        .hero-meta-item i{color:var(--accent);font-size:1rem;}
        .hero-guest-pill{display:inline-flex;align-items:center;gap:.5rem;background:var(--bg);border:1px solid var(--border);border-radius:2rem;padding:.4rem 1rem;font-size:.82rem;color:var(--muted);margin-bottom:2rem;}
        .hero-guest-pill strong{color:var(--text);}
        .btn-mod{display:inline-flex;align-items:center;gap:.5rem;padding:.7rem 1.6rem;border-radius:.375rem;font-size:.85rem;font-weight:600;text-decoration:none;border:none;cursor:pointer;transition:all .2s;}
        .btn-mod-primary{background:var(--accent);color:#fff;}
        .btn-mod-primary:hover{filter:brightness(1.1);}
        .btn-mod-ghost{background:transparent;color:var(--text);border:1.5px solid var(--border);}
        .btn-mod-ghost:hover{border-color:var(--accent);color:var(--accent);}
        .hero-btns{display:flex;gap:.75rem;flex-wrap:wrap;}

        /* SECTIONS */
        section{padding:5rem 1.5rem;}
        .sec{max-width:900px;margin:0 auto;}
        .sec-eyebrow{font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;color:var(--accent);margin-bottom:.6rem;}
        .sec-title{font-family:'Playfair Display',serif;font-size:clamp(1.7rem,3.5vw,2.4rem);font-weight:400;margin-bottom:1rem;}
        .sec-desc{font-size:.92rem;color:var(--muted);max-width:520px;}

        /* CARDS */
        .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.25rem;margin-top:2.5rem;}
        .card{background:var(--card-bg);border:1px solid var(--border);border-radius:.75rem;padding:1.5rem;}
        .card-icon{width:2.5rem;height:2.5rem;background:var(--bg);border-radius:.5rem;display:flex;align-items:center;justify-content:center;margin-bottom:1rem;}
        .card-icon i{color:var(--accent);font-size:1.1rem;}
        .card h4{font-size:.85rem;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:.4rem;}
        .card p{font-size:.9rem;color:var(--text);line-height:1.65;}

        /* TIMELINE */
        .timeline{margin-top:2.5rem;display:flex;flex-direction:column;gap:0;}
        .tl-item{display:flex;gap:1.5rem;padding:1.25rem 0;border-bottom:1px solid var(--border);}
        .tl-item:last-child{border-bottom:none;}
        .tl-dot{width:2rem;height:2rem;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:.2rem;}
        .tl-dot i{color:#fff;font-size:.85rem;}
        .tl-time{font-size:.8rem;font-weight:700;letter-spacing:.1em;color:var(--accent);margin-bottom:.2rem;}
        .tl-label{font-size:.95rem;font-weight:600;}
        .tl-sub{font-size:.85rem;color:var(--muted);}

        /* DC IMAGES */
        .dc-imgs{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-top:2rem;}
        .dc-imgs img{width:100%;aspect-ratio:3/4;object-fit:cover;border-radius:.5rem;}

        /* MAP */
        .loc-grid{display:grid;grid-template-columns:1fr 1fr;gap:2rem;margin-top:2.5rem;}
        .map-wrap{border-radius:.75rem;overflow:hidden;border:1px solid var(--border);height:300px;}
        .map-wrap iframe{width:100%;height:100%;border:none;}
        .map-empty{width:100%;height:100%;background:var(--bg);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:.5rem;color:var(--muted);font-size:.9rem;}
        .map-empty i{font-size:2rem;color:var(--accent);}

        /* RSVP */
        .rsvp-wrap{background:var(--accent);border-radius:1rem;padding:3rem 2rem;text-align:center;margin-top:0;}
        .rsvp-wrap .sec-title,.rsvp-wrap .sec-eyebrow{color:#fff;}
        .rsvp-sub{color:rgba(255,255,255,.75);font-size:.9rem;margin:-.5rem 0 2rem;}
        .rsvp-btns{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;}
        .rsvp-btn-mod{padding:.85rem 2rem;border-radius:.5rem;font-size:.88rem;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:.5rem;font-family:inherit;transition:all .2s;}
        .rsvp-yes{background:#fff;color:var(--accent);}
        .rsvp-yes:hover{background:var(--bg);}
        .rsvp-no{background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.35);}
        .rsvp-no:hover{background:rgba(255,255,255,.25);}
        .rsvp-msg{margin-top:1.25rem;padding:.75rem 1rem;border-radius:.5rem;font-size:.9rem;display:none;}
        .rsvp-msg.ok{background:rgba(255,255,255,.2);color:#fff;border:1px solid rgba(255,255,255,.35);}
        .rsvp-msg.err{background:rgba(239,68,68,.2);color:#fca5a5;}

        footer{text-align:center;padding:2rem;font-size:.82rem;color:var(--muted);border-top:1px solid var(--border);}

        @media(max-width:700px){
            .hero{grid-template-columns:1fr;}
            .hero-left{padding:4rem 2rem;min-height:40vh;}
            .hero-right{padding:3rem 1.5rem;}
            .loc-grid{grid-template-columns:1fr;}
            .dc-imgs{grid-template-columns:repeat(2,1fr);}
            .nav-links{display:none;}
        }
    </style>
</head>
<body>
<nav class="nav">
    <span class="nav-brand"><?= $eventName ?></span>
    <ul class="nav-links">
        <li><a href="#schedule">Programa</a></li>
        <li><a href="#dresscode">Dress Code</a></li>
        <li><a href="#location">Local</a></li>
        <li><a href="#rsvp">RSVP</a></li>
    </ul>
</nav>

<section class="hero" id="hero">
    <div class="hero-left">
        <div class="hero-left-text">
            <span class="hero-tag"><?= $eventDate ?: 'Data a anunciar' ?></span>
            <div class="hero-big-date"><?= $eventDate ? date('d', strtotime($event['data'])) : '--' ?><br><span style="font-size:.45em;font-weight:300;"><?= $eventDate ? date('M Y', strtotime($event['data'])) : '' ?></span></div>
            <?php if ($eventHour): ?>
            <span style="font-size:.88rem;opacity:.8;">às <?= htmlspecialchars(substr($eventHour,0,5)) ?></span>
            <?php endif; ?>
        </div>
    </div>
    <div class="hero-right">
        <div class="hero-right-inner">
            <span class="hero-eyebrow">Convite Especial</span>
            <h1 class="hero-name"><?= $eventName ?></h1>
            <div class="hero-meta">
                <?php if ($locName): ?><div class="hero-meta-item"><i class="ph ph-map-pin"></i><?= $locName ?></div><?php endif; ?>
                <?php if ($eventDate): ?><div class="hero-meta-item"><i class="ph ph-calendar"></i><?= $eventDate ?></div><?php endif; ?>
            </div>
            <?php if ($guestDisplay): ?>
            <div class="hero-guest-pill"><i class="ph ph-user"></i>Para <strong><?= $guestDisplay ?></strong></div>
            <?php endif; ?>
            <div class="hero-btns">
                <a href="#rsvp" class="btn-mod btn-mod-primary"><i class="ph ph-check"></i> Confirmar</a>
                <a href="#location" class="btn-mod btn-mod-ghost"><i class="ph ph-map-trifold"></i> Local</a>
            </div>
        </div>
    </div>
</section>

<?php if ($eventHour || $receptionHour): ?>
<section id="schedule" style="background:var(--white);">
    <div class="sec">
        <p class="sec-eyebrow">Agenda</p>
        <h2 class="sec-title">Programa do Dia</h2>
        <div class="timeline">
            <?php if ($eventHour): ?>
            <div class="tl-item">
                <div class="tl-dot"><i class="ph ph-star"></i></div>
                <div><p class="tl-time"><?= htmlspecialchars(substr($eventHour,0,5)) ?></p><p class="tl-label">Cerimónia</p><p class="tl-sub"><?= $locName ?: 'Local a confirmar' ?></p></div>
            </div>
            <?php endif; ?>
            <?php if ($receptionHour): ?>
            <div class="tl-item">
                <div class="tl-dot"><i class="ph ph-champagne"></i></div>
                <div><p class="tl-time"><?= htmlspecialchars(substr($receptionHour,0,5)) ?></p><p class="tl-label">Receção e Jantar</p><p class="tl-sub">Cocktail e celebração</p></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="dresscode">
    <div class="sec">
        <p class="sec-eyebrow">Dress Code</p>
        <h2 class="sec-title"><?= $dcTitle ?></h2>
        <div class="cards">
            <?php if ($dcSuggested): ?>
            <div class="card"><div class="card-icon"><i class="ph ph-check-circle"></i></div><h4>Sugerido</h4><p><?= $dcSuggested ?></p></div>
            <?php endif; ?>
            <?php if ($dcAvoid): ?>
            <div class="card"><div class="card-icon"><i class="ph ph-prohibit"></i></div><h4>Evitar</h4><p><?= $dcAvoid ?></p></div>
            <?php endif; ?>
            <?php if ($dcPalette): ?>
            <div class="card"><div class="card-icon"><i class="ph ph-palette"></i></div><h4>Paleta</h4><p><?= $dcPalette ?></p></div>
            <?php endif; ?>
        </div>
        <?php if ($dcImg1||$dcImg2||$dcImg3): ?>
        <div class="dc-imgs">
            <?php foreach([$dcImg1,$dcImg2,$dcImg3] as $img): if($img): ?><img src="<?= htmlspecialchars($img) ?>" alt="" loading="lazy"><?php endif; endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php if ($locName||$locAddress): ?>
<section id="location" style="background:var(--white);">
    <div class="sec">
        <p class="sec-eyebrow">Local</p>
        <h2 class="sec-title">Como Chegar</h2>
        <div class="loc-grid">
            <div>
                <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;margin-bottom:.75rem;"><?= $locName ?></h3>
                <?php if ($locAddress): ?><p style="font-size:.9rem;color:var(--muted);margin-bottom:.75rem;"><?= $locAddress ?></p><?php endif; ?>
                <?php if ($locParking): ?><p style="font-size:.88rem;color:var(--muted);"><i class="ph ph-car" style="color:var(--accent);"></i> <?= $locParking ?></p><?php endif; ?>
                <?php if ($locMap): ?><a href="<?= htmlspecialchars($locMap) ?>" target="_blank" class="btn-mod btn-mod-primary" style="margin-top:1.25rem;"><i class="ph ph-navigation-arrow"></i> Google Maps</a><?php endif; ?>
            </div>
            <div class="map-wrap">
                <?php if($locMap): ?><iframe src="<?= htmlspecialchars($locMap) ?>" allowfullscreen loading="lazy"></iframe>
                <?php else: ?><div class="map-empty"><i class="ph ph-map-trifold"></i><span>Mapa não configurado</span></div><?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="rsvp">
    <div class="sec">
        <div class="rsvp-wrap">
            <p class="sec-eyebrow">A Sua Presença</p>
            <h2 class="sec-title">Vai Estar Connosco?</h2>
            <p class="rsvp-sub">A sua confirmação é muito importante.</p>
            <div class="rsvp-btns">
                <button class="rsvp-btn-mod rsvp-yes" onclick="submitRSVP('confirmado')"><i class="ph ph-check-fat"></i> Sim, Confirmo!</button>
                <button class="rsvp-btn-mod rsvp-no" onclick="submitRSVP('recusado')"><i class="ph ph-x"></i> Não Poderei Ir</button>
            </div>
            <div class="rsvp-msg" id="rsvp-msg"></div>
        </div>
    </div>
</section>

<footer>© <?= date('Y') ?> <?= $eventName ?> — Feito com ❤️ para <?= $guestDisplay ?: 'você' ?></footer>

<script>
async function submitRSVP(r){
    const el=document.getElementById('rsvp-msg');
    try{
        const res=await fetch('api/rsvp.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({resposta:r})});
        const d=await res.json();
        el.style.display='block';
        if(d.status==='ok'){el.className='rsvp-msg ok';el.textContent=r==='confirmado'?'✓ Presença confirmada! Até breve.':'Resposta registada. Obrigado!';}
        else{el.className='rsvp-msg err';el.textContent=d.msg||'Erro.';}
    }catch(e){el.style.display='block';el.className='rsvp-msg err';el.textContent='Erro de ligação.';}
}
</script>
</body>
</html>
