<?php
// layouts/elegant.php
$primaryColor  = $settings['primary_color'] ?? '#b8965a';
$bgColor       = $settings['bg_color']      ?? '#0d0b08';
$textColor     = $settings['text_color']    ?? '#f5f0e8';
$goldLt        = lightenColor($primaryColor, 30);
$goldDk        = darkenColor($primaryColor, 20);

$eventName     = htmlspecialchars($event['nome_evento'] ?? '');
$eventDate     = !empty($event['data'])  ? date('d \d\e F \d\e Y', strtotime($event['data'])) : '';
$eventLocation = htmlspecialchars($event['local'] ?? '');
$eventHour     = $settings['ceremony_time']  ?? ($event['hora'] ?? '');
$receptionHour = $settings['reception_time'] ?? '';
$locName       = htmlspecialchars($settings['location_name'] ?? $eventLocation);
$locAddress    = nl2br(htmlspecialchars($settings['location_address'] ?? ''));
$locMap        = $settings['location_map_url'] ?? '';
if (!preg_match('/^https:\/\//', $locMap)) $locMap = '';
$locParking    = nl2br(htmlspecialchars($settings['location_parking_info'] ?? ''));
$dcTitle       = htmlspecialchars($settings['dresscode_title']    ?? 'Black Tie');
$dcSuggested   = nl2br(htmlspecialchars($settings['dresscode_suggested'] ?? ''));
$dcAvoid       = nl2br(htmlspecialchars($settings['dresscode_avoid']     ?? ''));
$dcPalette     = nl2br(htmlspecialchars($settings['dresscode_palette']   ?? ''));
$dcImg1        = $settings['dresscode_image1'] ?? '';
$dcImg2        = $settings['dresscode_image2'] ?? '';
$dcImg3        = $settings['dresscode_image3'] ?? '';
$guestDisplay  = htmlspecialchars($guestName ?? '');
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?= $eventName ?> — Convite</title>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600&family=Raleway:ital,wght@0,300;0,400;0,500;1,300;1,400&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        :root{
            --gold:   <?= $primaryColor ?>;
            --gold-l: <?= $goldLt ?>;
            --gold-d: <?= $goldDk ?>;
            --bg:     <?= $bgColor ?>;
            --text:   <?= $textColor ?>;
            --surface:rgba(255,255,255,.04);
            --border: rgba(<?= implode(',', sscanf(ltrim($primaryColor,'#'),'%02x%02x%02x')) ?>, .25);
            --muted:  rgba(245,240,232,.5);
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        html{scroll-behavior:smooth;}
        body{font-family:'Raleway',sans-serif;background:var(--bg);color:var(--text);font-size:16px;line-height:1.7;overflow-x:hidden;}

        /* — NOISE TEXTURE — */
        body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");pointer-events:none;z-index:0;opacity:.4;}

        /* — NAV — */
        .nav{position:fixed;top:0;left:0;right:0;display:flex;align-items:center;justify-content:space-between;padding:.9rem 2.5rem;z-index:200;border-bottom:1px solid var(--border);}
        .nav::before{content:'';position:absolute;inset:0;background:linear-gradient(to bottom,rgba(13,11,8,.95),rgba(13,11,8,.85));backdrop-filter:blur(16px);z-index:-1;}
        .nav-brand{font-family:'Cinzel',serif;font-size:.95rem;letter-spacing:.2em;color:var(--gold);}
        .nav-links{list-style:none;display:flex;gap:2.5rem;}
        .nav-links a{color:rgba(245,240,232,.5);text-decoration:none;font-size:.72rem;letter-spacing:.18em;text-transform:uppercase;transition:color .25s;}
        .nav-links a:hover{color:var(--gold);}

        /* — HERO — */
        .hero{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;position:relative;overflow:hidden;}
        .hero-bg{position:absolute;inset:0;background:radial-gradient(ellipse 80% 60% at 50% 50%,rgba(184,150,90,.06) 0%,transparent 70%);}
        .hero-frame{position:absolute;inset:1.5rem;border:1px solid var(--border);pointer-events:none;}
        .hero-frame::before,.hero-frame::after{content:'';position:absolute;width:20px;height:20px;border-color:var(--gold);border-style:solid;opacity:.6;}
        .hero-frame::before{top:-1px;left:-1px;border-width:1px 0 0 1px;}
        .hero-frame::after{bottom:-1px;right:-1px;border-width:0 1px 1px 0;}
        .hero-content{position:relative;z-index:1;max-width:600px;}
        .hero-mono{font-size:.68rem;letter-spacing:.35em;text-transform:uppercase;color:var(--gold);margin-bottom:2.5rem;display:block;opacity:.8;}
        .hero-divider{display:flex;align-items:center;gap:1.2rem;justify-content:center;margin-bottom:2.5rem;}
        .hero-divider-line{height:1px;width:80px;background:linear-gradient(to right,transparent,var(--gold),transparent);}
        .hero-divider-gem{width:6px;height:6px;background:var(--gold);transform:rotate(45deg);}
        .hero-title{font-family:'Cinzel',serif;font-size:clamp(2.2rem,6vw,4.5rem);font-weight:400;letter-spacing:.08em;line-height:1.2;margin-bottom:1.75rem;color:var(--text);}
        .hero-date{font-size:.82rem;letter-spacing:.22em;text-transform:uppercase;color:var(--muted);margin-bottom:.5rem;}
        .hero-loc{display:inline-flex;align-items:center;gap:.4rem;font-size:.85rem;color:var(--gold);margin-bottom:2.75rem;letter-spacing:.05em;}
        .hero-guest{display:inline-flex;align-items:center;gap:.6rem;background:var(--surface);border:1px solid var(--border);padding:.5rem 1.5rem;border-radius:.25rem;font-size:.82rem;color:var(--muted);margin-bottom:2.75rem;letter-spacing:.05em;}
        .hero-guest em{color:var(--gold);font-style:normal;}
        .hero-ctas{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;}
        .btn-el{display:inline-flex;align-items:center;gap:.5rem;padding:.75rem 2rem;font-size:.75rem;letter-spacing:.18em;text-transform:uppercase;font-family:'Raleway',sans-serif;border-radius:.2rem;cursor:pointer;text-decoration:none;transition:all .25s;border:none;}
        .btn-el-fill{background:var(--gold);color:var(--bg);font-weight:600;}
        .btn-el-fill:hover{background:var(--gold-l);}
        .btn-el-outline{background:transparent;color:var(--text);border:1px solid var(--border);}
        .btn-el-outline:hover{border-color:var(--gold);color:var(--gold);}

        /* — SECTION BASE — */
        .section{padding:6rem 1.5rem;position:relative;}
        .sec-inner{max-width:840px;margin:0 auto;}
        .sec-mono{font-size:.68rem;letter-spacing:.3em;text-transform:uppercase;color:var(--gold);margin-bottom:1rem;display:block;opacity:.8;}
        .sec-title{font-family:'Cinzel',serif;font-size:clamp(1.6rem,3vw,2.4rem);font-weight:400;letter-spacing:.08em;margin-bottom:.5rem;}
        .sec-sub{font-size:.88rem;color:var(--muted);max-width:480px;letter-spacing:.02em;}
        .divider-thin{border:none;border-top:1px solid var(--border);margin:3.5rem 0;}

        /* — COUNTDOWN — */
        .countdown-row{display:flex;gap:1rem;flex-wrap:wrap;margin-top:2.75rem;}
        .cd-box{flex:1 1 90px;background:var(--surface);border:1px solid var(--border);border-radius:.25rem;padding:1.75rem 1rem;text-align:center;}
        .cd-num{font-family:'Cinzel',serif;font-size:2.8rem;font-weight:400;color:var(--gold);display:block;line-height:1;}
        .cd-lbl{font-size:.62rem;letter-spacing:.22em;text-transform:uppercase;color:var(--muted);margin-top:.5rem;display:block;}

        /* — PROGRAM — */
        .program-list{margin-top:2.5rem;display:flex;flex-direction:column;gap:.75rem;}
        .prog-item{display:flex;align-items:center;gap:1.5rem;padding:1.25rem 1.5rem;background:var(--surface);border:1px solid var(--border);border-radius:.25rem;transition:border-color .2s;}
        .prog-item:hover{border-color:rgba(184,150,90,.5);}
        .prog-time{font-family:'Cinzel',serif;font-size:1.25rem;color:var(--gold);min-width:70px;letter-spacing:.05em;}
        .prog-sep{width:1px;height:2rem;background:var(--border);}
        .prog-label{font-size:.88rem;font-weight:500;letter-spacing:.05em;}
        .prog-desc{font-size:.8rem;color:var(--muted);}

        /* — DRESS CODE — */
        .dc-section{background:linear-gradient(160deg,rgba(184,150,90,.04) 0%,transparent 50%);}
        .dc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:1.25rem;margin-top:2.5rem;}
        .dc-card{background:var(--surface);border:1px solid var(--border);border-radius:.25rem;padding:1.5rem;}
        .dc-card-head{display:flex;align-items:center;gap:.6rem;font-size:.68rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);margin-bottom:.85rem;}
        .dc-card p{font-size:.87rem;color:var(--muted);line-height:1.7;}
        .dc-imgs{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-top:2rem;}
        .dc-imgs img{width:100%;aspect-ratio:3/4;object-fit:cover;border-radius:.25rem;border:1px solid var(--border);filter:brightness(.92);transition:filter .25s;}
        .dc-imgs img:hover{filter:brightness(1);}

        /* — LOCATION — */
        .loc-grid{display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;margin-top:2.5rem;}
        .loc-name{font-family:'Cinzel',serif;font-size:1.4rem;font-weight:400;letter-spacing:.06em;margin-bottom:1rem;}
        .loc-detail{display:flex;align-items:flex-start;gap:.7rem;font-size:.87rem;color:var(--muted);margin-top:.75rem;line-height:1.6;}
        .loc-detail i{color:var(--gold);margin-top:.1rem;flex-shrink:0;}
        .map-frame{border-radius:.25rem;overflow:hidden;border:1px solid var(--border);height:300px;}
        .map-frame iframe{width:100%;height:100%;border:none;filter:grayscale(.5) brightness(.85);}
        .map-empty{width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.5rem;color:var(--muted);font-size:.9rem;}
        .map-empty i{font-size:2rem;color:var(--gold);}

        /* — RSVP — */
        .rsvp-section{text-align:center;}
        .rsvp-box{display:inline-block;max-width:500px;width:100%;}
        .rsvp-subtitle{font-size:.88rem;color:var(--muted);letter-spacing:.05em;margin-bottom:2.5rem;}
        .rsvp-btns-el{display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;}
        .rsvp-ans{padding:.85rem 2rem;font-size:.75rem;letter-spacing:.18em;text-transform:uppercase;font-family:'Raleway',sans-serif;border-radius:.2rem;cursor:pointer;display:inline-flex;align-items:center;gap:.5rem;transition:all .2s;font-weight:600;border:none;}
        .rsvp-yes-el{background:var(--gold);color:var(--bg);}
        .rsvp-yes-el:hover{background:var(--gold-l);}
        .rsvp-no-el{background:transparent;color:var(--text);border:1px solid var(--border);}
        .rsvp-no-el:hover{border-color:#ef4444;color:#ef4444;}
        .rsvp-feedback{margin-top:1.5rem;padding:.85rem 1.25rem;border-radius:.25rem;font-size:.88rem;display:none;letter-spacing:.03em;}
        .rsvp-feedback.ok{background:rgba(184,150,90,.1);border:1px solid rgba(184,150,90,.3);color:var(--gold);}
        .rsvp-feedback.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;}

        /* — FOOTER — */
        footer{border-top:1px solid var(--border);text-align:center;padding:2.5rem;font-size:.78rem;letter-spacing:.1em;color:var(--muted);text-transform:uppercase;}
        footer em{color:var(--gold);font-style:normal;}

        @media(max-width:640px){
            .hero-frame{inset:.75rem;}
            .loc-grid{grid-template-columns:1fr;}
            .dc-imgs{grid-template-columns:repeat(2,1fr);}
            .nav-links{display:none;}
        }
    </style>
</head>
<body>

<nav class="nav">
    <span class="nav-brand"><?= $eventName ?></span>
    <ul class="nav-links">
        <li><a href="#program">Programa</a></li>
        <li><a href="#dresscode">Dress Code</a></li>
        <li><a href="#location">Local</a></li>
        <li><a href="#rsvp">RSVP</a></li>
    </ul>
</nav>

<!-- HERO -->
<section class="hero" id="hero">
    <div class="hero-bg"></div>
    <div class="hero-frame"></div>
    <div class="hero-content">
        <span class="hero-mono">Convite Exclusivo</span>
        <div class="hero-divider">
            <div class="hero-divider-line"></div>
            <div class="hero-divider-gem"></div>
            <div class="hero-divider-line"></div>
        </div>
        <h1 class="hero-title"><?= $eventName ?></h1>
        <?php if ($eventDate): ?><p class="hero-date"><?= $eventDate ?></p><?php endif; ?>
        <?php if ($locName): ?><p class="hero-loc"><i class="ph ph-map-pin"></i><?= $locName ?></p><?php endif; ?>
        <?php if ($guestDisplay): ?>
        <div class="hero-guest"><i class="ph ph-envelope-open"></i>Para <em><?= $guestDisplay ?></em></div>
        <?php endif; ?>
        <div class="hero-ctas">
            <a href="#rsvp" class="btn-el btn-el-fill"><i class="ph ph-check"></i> Confirmar Presença</a>
            <a href="#location" class="btn-el btn-el-outline"><i class="ph ph-map-trifold"></i> Local</a>
        </div>
    </div>
</section>

<!-- COUNTDOWN -->
<?php if (!empty($event['data'])): ?>
<section class="section" id="countdown">
    <div class="sec-inner" style="text-align:center;">
        <span class="sec-mono">Contagem Decrescente</span>
        <h2 class="sec-title">Falta Pouco</h2>
        <div class="countdown-row">
            <div class="cd-box"><span class="cd-num" id="cd-d">--</span><span class="cd-lbl">Dias</span></div>
            <div class="cd-box"><span class="cd-num" id="cd-h">--</span><span class="cd-lbl">Horas</span></div>
            <div class="cd-box"><span class="cd-num" id="cd-m">--</span><span class="cd-lbl">Minutos</span></div>
            <div class="cd-box"><span class="cd-num" id="cd-s">--</span><span class="cd-lbl">Segundos</span></div>
        </div>
    </div>
</section>
<script>
(function(){
    var t=new Date(<?= json_encode(($event['data'] ?? '') . ($eventHour ? ' '.$eventHour : ' 00:00:00')) ?>);
    function tick(){
        var diff=Math.max(0,t-Date.now());
        document.getElementById('cd-d').textContent=String(Math.floor(diff/86400000)).padStart(2,'0');
        document.getElementById('cd-h').textContent=String(Math.floor(diff%86400000/3600000)).padStart(2,'0');
        document.getElementById('cd-m').textContent=String(Math.floor(diff%3600000/60000)).padStart(2,'0');
        document.getElementById('cd-s').textContent=String(Math.floor(diff%60000/1000)).padStart(2,'0');
    }
    tick();setInterval(tick,1000);
})();
</script>
<?php endif; ?>

<hr class="divider-thin" style="max-width:840px;margin:0 auto;">

<!-- PROGRAM -->
<?php if ($eventHour || $receptionHour): ?>
<section class="section" id="program">
    <div class="sec-inner">
        <span class="sec-mono">Agenda</span>
        <h2 class="sec-title">Programa do Dia</h2>
        <div class="program-list">
            <?php if ($eventHour): ?>
            <div class="prog-item">
                <div class="prog-time"><?= htmlspecialchars(substr($eventHour,0,5)) ?></div>
                <div class="prog-sep"></div>
                <div><p class="prog-label">Cerimónia</p><p class="prog-desc"><?= $locName ?: 'Local a confirmar' ?></p></div>
            </div>
            <?php endif; ?>
            <?php if ($receptionHour): ?>
            <div class="prog-item">
                <div class="prog-time"><?= htmlspecialchars(substr($receptionHour,0,5)) ?></div>
                <div class="prog-sep"></div>
                <div><p class="prog-label">Receção & Jantar de Gala</p><p class="prog-desc">Cocktail, celebração e jantar formal</p></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<hr class="divider-thin" style="max-width:840px;margin:0 auto;">
<?php endif; ?>

<!-- DRESS CODE -->
<section class="section dc-section" id="dresscode">
    <div class="sec-inner">
        <span class="sec-mono">Dress Code</span>
        <h2 class="sec-title"><?= $dcTitle ?></h2>
        <div class="dc-grid">
            <?php if ($dcSuggested): ?>
            <div class="dc-card"><div class="dc-card-head"><i class="ph ph-check-circle"></i> Sugerido</div><p><?= $dcSuggested ?></p></div>
            <?php endif; ?>
            <?php if ($dcAvoid): ?>
            <div class="dc-card"><div class="dc-card-head"><i class="ph ph-x-circle"></i> Evitar</div><p><?= $dcAvoid ?></p></div>
            <?php endif; ?>
            <?php if ($dcPalette): ?>
            <div class="dc-card"><div class="dc-card-head"><i class="ph ph-palette"></i> Paleta</div><p><?= $dcPalette ?></p></div>
            <?php endif; ?>
        </div>
        <?php if ($dcImg1||$dcImg2||$dcImg3): ?>
        <div class="dc-imgs">
            <?php foreach([$dcImg1,$dcImg2,$dcImg3] as $img): if($img): ?>
            <img src="<?= htmlspecialchars($img) ?>" alt="Dress code inspiration" loading="lazy">
            <?php endif; endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<hr class="divider-thin" style="max-width:840px;margin:0 auto;">

<!-- LOCATION -->
<?php if ($locName||$locAddress): ?>
<section class="section" id="location">
    <div class="sec-inner">
        <span class="sec-mono">Localização</span>
        <h2 class="sec-title">O Espaço</h2>
        <div class="loc-grid">
            <div>
                <p class="loc-name"><?= $locName ?></p>
                <?php if ($locAddress): ?><div class="loc-detail"><i class="ph ph-map-pin"></i><span><?= $locAddress ?></span></div><?php endif; ?>
                <?php if ($eventHour): ?><div class="loc-detail"><i class="ph ph-clock"></i><span>Cerimónia às <?= htmlspecialchars(substr($eventHour,0,5)) ?></span></div><?php endif; ?>
                <?php if ($locParking): ?><div class="loc-detail"><i class="ph ph-car"></i><span><?= $locParking ?></span></div><?php endif; ?>
                <?php if ($locMap): ?><a href="<?= htmlspecialchars($locMap) ?>" target="_blank" class="btn-el btn-el-fill" style="margin-top:1.5rem;"><i class="ph ph-navigation-arrow"></i> Abrir Mapa</a><?php endif; ?>
            </div>
            <div class="map-frame">
                <?php if ($locMap): ?><iframe src="<?= htmlspecialchars($locMap) ?>" allowfullscreen loading="lazy"></iframe>
                <?php else: ?><div class="map-empty"><i class="ph ph-map-trifold"></i><span>Mapa não configurado</span></div><?php endif; ?>
            </div>
        </div>
    </div>
</section>
<hr class="divider-thin" style="max-width:840px;margin:0 auto;">
<?php endif; ?>

<!-- RSVP -->
<section class="section rsvp-section" id="rsvp">
    <div class="sec-inner" style="text-align:center;">
        <span class="sec-mono">A Sua Resposta</span>
        <h2 class="sec-title">Vai Estar Presente?</h2>
        <p class="rsvp-subtitle">A sua confirmação é essencial para o planeamento deste momento especial.</p>
        <div class="rsvp-box">
            <div class="rsvp-btns-el">
                <button class="rsvp-ans rsvp-yes-el" onclick="submitRSVP('confirmado')"><i class="ph ph-check-fat"></i> Sim, Confirmo</button>
                <button class="rsvp-ans rsvp-no-el"  onclick="submitRSVP('recusado')"><i class="ph ph-x"></i> Não Poderei Ir</button>
            </div>
            <div class="rsvp-feedback" id="rsvp-fb"></div>
        </div>
    </div>
</section>

<footer>© <?= date('Y') ?> <em><?= $eventName ?></em> — Com carinho para <?= $guestDisplay ?: 'você' ?></footer>

<script>
async function submitRSVP(r){
    const el=document.getElementById('rsvp-fb');
    try{
        const res=await fetch('api/rsvp.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({resposta:r})});
        const d=await res.json();
        el.style.display='block';
        if(d.status==='ok'){el.className='rsvp-feedback ok';el.textContent=r==='confirmado'?'✦ Presença confirmada com elegância. Até breve.':'Resposta registada. Muito obrigado.';}
        else{el.className='rsvp-feedback err';el.textContent=d.msg||'Erro ao registar.';}
    }catch{el.style.display='block';el.className='rsvp-feedback err';el.textContent='Erro de ligação.';}
}
</script>
</body>
</html>
