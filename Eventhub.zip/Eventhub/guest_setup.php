<?php
/**
 * guest_setup.php
 *
 * Página pública que permite ao convidado definir a sua password
 * após receber um link de convite por email.
 *
 * Fluxo:
 *   1. GET  ?token=...  → valida token → mostra formulário
 *   2. POST ?token=...  → valida password → actualiza utilizador
 *                       → marca token como used → redireciona para login.php
 */

require_once __DIR__ . '/db.php';

// Não requer autenticação — esta página é pública por design.

$db    = getDB();
$token = trim($_GET['token'] ?? '');

// ── Validação inicial do token ────────────────────────────────────────────────
if ($token === '') {
    terminateWithError('Link de convite inválido. Por favor contacte o organizador do evento.');
}

$stmtToken = $db->prepare(
    'SELECT t.id_token,
            t.id_evento,
            t.email,
            t.expires,
            t.used,
            e.nome_evento
     FROM   guest_invite_tokens t
     JOIN   evento               e ON e.id_evento = t.id_evento
     WHERE  t.token = ?'
);
$stmtToken->execute([$token]);
$convite = $stmtToken->fetch(PDO::FETCH_ASSOC);

if (!$convite) {
    terminateWithError('Link de convite não encontrado. Verifique o email recebido.');
}

if ((int) $convite['used'] === 1) {
    terminateWithError('Este link de convite já foi utilizado. Se precisar de ajuda, contacte o organizador.');
}

if (new DateTime() > new DateTime($convite['expires'])) {
    terminateWithError('O link de convite expirou (válido 7 dias). Por favor contacte o organizador para receber um novo convite.');
}

// ── Processamento do formulário (POST) ───────────────────────────────────────
$erro    = '';
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password        = $_POST['password']        ?? '';
    $passwordConfirm = $_POST['password_confirm'] ?? '';

    if (strlen($password) < 6) {
        $erro = 'A password deve ter pelo menos 6 caracteres.';
    } elseif ($password !== $passwordConfirm) {
        $erro = 'As passwords não coincidem.';
    } else {
        $db->beginTransaction();
        try {
            $passwordHash = hash('sha256', $password);

            // Actualizar password do utilizador correspondente ao email do convite
            $stmtUpdate = $db->prepare(
                'UPDATE utilizador
                 SET    password = ?
                 WHERE  email    = ?'
            );
            $stmtUpdate->execute([$passwordHash, $convite['email']]);

            // Marcar token como utilizado
            $stmtUsed = $db->prepare(
                'UPDATE guest_invite_tokens
                 SET    used = 1
                 WHERE  id_token = ?'
            );
            $stmtUsed->execute([$convite['id_token']]);

            $db->commit();

            // Redirecionar para login com mensagem de sucesso na query string
            $loginUrl = 'login.php?msg=' . urlencode('Password definida com sucesso! Pode agora iniciar sessão.');
            header('Location: ' . $loginUrl);
            exit;

        } catch (Throwable $e) {
            $db->rollBack();
            error_log('[EventHub] Erro em guest_setup.php: ' . $e->getMessage());
            $erro = 'Ocorreu um erro interno. Por favor tente novamente.';
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Exibe uma página de erro simples e termina a execução.
 */
function terminateWithError(string $mensagem): never
{
    renderPage('Convite Inválido', '
        <div class="alert alert-error">
            <span class="alert-icon">✕</span>
            ' . htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8') . '
        </div>
        <p class="back-link">
            <a href="login.php">← Voltar ao login</a>
        </p>
    ');
    exit;
}

/**
 * Renderiza a página completa com o layout partilhado.
 */
function renderPage(string $titulo, string $conteudo): void
{
    echo <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{$titulo} — EventHub</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f3f4f6;
      font-family: Arial, sans-serif;
      color: #1f2937;
    }

    .card {
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,.1);
      padding: 48px 40px;
      width: 100%;
      max-width: 440px;
    }

    .logo {
      text-align: center;
      margin-bottom: 32px;
    }
    .logo h1 {
      font-size: 28px;
      color: #4f46e5;
      letter-spacing: 1px;
    }

    .card h2 {
      font-size: 20px;
      margin-bottom: 8px;
      color: #111827;
    }
    .card .subtitle {
      font-size: 14px;
      color: #6b7280;
      margin-bottom: 28px;
      line-height: 1.5;
    }

    .form-group { margin-bottom: 20px; }
    .form-group label {
      display: block;
      font-size: 14px;
      font-weight: 600;
      color: #374151;
      margin-bottom: 6px;
    }
    .form-group input {
      width: 100%;
      padding: 10px 14px;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 15px;
      transition: border-color .2s;
    }
    .form-group input:focus {
      outline: none;
      border-color: #4f46e5;
      box-shadow: 0 0 0 3px rgba(79,70,229,.15);
    }

    .hint {
      font-size: 12px;
      color: #9ca3af;
      margin-top: 4px;
    }

    .btn {
      display: block;
      width: 100%;
      padding: 12px;
      background: #4f46e5;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background .2s;
      margin-top: 8px;
    }
    .btn:hover { background: #4338ca; }

    .alert {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      padding: 14px 16px;
      border-radius: 6px;
      font-size: 14px;
      margin-bottom: 24px;
      line-height: 1.5;
    }
    .alert-error  { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; }
    .alert-icon   { flex-shrink: 0; font-weight: bold; }

    .back-link {
      text-align: center;
      margin-top: 24px;
      font-size: 14px;
    }
    .back-link a { color: #4f46e5; text-decoration: none; }
    .back-link a:hover { text-decoration: underline; }

    .event-badge {
      display: inline-block;
      background: #ede9fe;
      color: #5b21b6;
      font-size: 13px;
      padding: 4px 12px;
      border-radius: 999px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo"><h1>EventHub</h1></div>
    {$conteudo}
  </div>
</body>
</html>
HTML;
}

// ── Renderizar formulário ─────────────────────────────────────────────────────
$nomeEvento  = htmlspecialchars($convite['nome_evento'], ENT_QUOTES, 'UTF-8');
$safeToken   = htmlspecialchars($token,                 ENT_QUOTES, 'UTF-8');
$erroHtml    = '';

if ($erro !== '') {
    $erroHtml = '
        <div class="alert alert-error">
            <span class="alert-icon">✕</span>
            ' . htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') . '
        </div>';
}

$formHtml = <<<HTML
<h2>Bem-vindo ao EventHub!</h2>
<p class="subtitle">
    Foi convidado para o evento abaixo.<br>
    Defina a sua password para aceder à sua área de convidado.
</p>

<span class="event-badge">🎉 {$nomeEvento}</span>

{$erroHtml}

<form method="POST" action="guest_setup.php?token={$safeToken}" novalidate>

    <div class="form-group">
        <label for="password">Nova Password</label>
        <input
            type="password"
            id="password"
            name="password"
            placeholder="Mínimo 6 caracteres"
            required
            minlength="6"
            autocomplete="new-password"
        >
        <p class="hint">Mínimo de 6 caracteres.</p>
    </div>

    <div class="form-group">
        <label for="password_confirm">Confirmar Password</label>
        <input
            type="password"
            id="password_confirm"
            name="password_confirm"
            placeholder="Repita a password"
            required
            minlength="6"
            autocomplete="new-password"
        >
    </div>

    <button type="submit" class="btn">Definir Password e Entrar</button>
</form>

<p class="back-link">
    <a href="login.php">← Já tenho conta. Iniciar sessão</a>
</p>
HTML;

renderPage('Configurar Conta', $formHtml);
