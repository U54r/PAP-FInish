<?php
// admin_utilizadores.php — CRUD global de utilizadores (admin)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireRole(['administrador']);

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $stmt = $pdo->query("
        SELECT u.id_utilizador, u.nome, u.email, u.telefone, u.estado_conta, u.data_registo,
               r.nome_role, o.nome AS organizador_nome
        FROM utilizador u
        JOIN role r ON r.id_role = u.id_role
        LEFT JOIN utilizador o ON o.id_utilizador = u.id_organizador
        ORDER BY u.nome
    ");
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    $d        = getBody();
    $nome     = trim($d['nome']     ?? '');
    $email    = trim($d['email']    ?? '');
    $telefone = trim($d['telefone'] ?? '');
    $role     = trim($d['role']     ?? '');
    $password = $d['password'] ?? '';

    if (!$nome || !$email)               jsonErro('Nome e email são obrigatórios');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonErro('Email inválido');

    $stmtRole = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = ?");
    $stmtRole->execute([$role]);
    $roleRow = $stmtRole->fetch();
    if (!$roleRow) jsonErro('Role inválido');

    $check = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE email = ?");
    $check->execute([$email]);
    if ($check->fetch()) jsonErro('Já existe uma conta com este email');

    $passwordGerada = null;
    if (empty($password)) {
        $passwordGerada = bin2hex(random_bytes(4));
        $password       = $passwordGerada;
    }

    $pdo->prepare("
        INSERT INTO utilizador (nome, email, telefone, password, id_role, estado_conta, data_registo)
        VALUES (?, ?, ?, ?, ?, 'ativo', NOW())
    ")->execute([$nome, $email, $telefone ?: null, hash('sha256', $password), $roleRow['id_role']]);

    jsonOk([
        'id_utilizador' => (int)$pdo->lastInsertId(),
        'password'      => $passwordGerada,
    ], 'Utilizador criado com sucesso');
    break;

case 'PUT':
    if (!$id) jsonErro('ID obrigatório');
    $d = getBody();

    $chk = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ?");
    $chk->execute([$id]);
    if (!$chk->fetch()) jsonErro('Utilizador não encontrado', 404);

    $nome     = trim($d['nome']     ?? '');
    $telefone = trim($d['telefone'] ?? '');
    $role     = trim($d['role']     ?? '');
    $estado   = trim($d['estado_conta'] ?? 'ativo');

    if (!$nome) jsonErro('Nome é obrigatório');

    $stmtRole = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = ?");
    $stmtRole->execute([$role]);
    $roleRow = $stmtRole->fetch();
    if (!$roleRow) jsonErro('Role inválido');

    if (!empty($d['password'])) {
        $pdo->prepare("
            UPDATE utilizador SET nome=?, telefone=?, id_role=?, estado_conta=?, password=?
            WHERE id_utilizador=?
        ")->execute([$nome, $telefone ?: null, $roleRow['id_role'], $estado, hash('sha256', $d['password']), $id]);
    } else {
        $pdo->prepare("
            UPDATE utilizador SET nome=?, telefone=?, id_role=?, estado_conta=?
            WHERE id_utilizador=?
        ")->execute([$nome, $telefone ?: null, $roleRow['id_role'], $estado, $id]);
    }

    jsonOk([], 'Utilizador atualizado');
    break;

case 'DELETE':
    if (!$id) jsonErro('ID obrigatório');
    if ($id === (int)$_SESSION['id_utilizador']) jsonErro('Não pode eliminar a sua própria conta de administrador');

    $chk = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE id_utilizador = ?");
    $chk->execute([$id]);
    if (!$chk->fetch()) jsonErro('Utilizador não encontrado', 404);

    // Limpar referências noutras tabelas antes de eliminar (evita erros de FK)
    $pdo->prepare("DELETE FROM notificacoes WHERE id_utilizador = ?")->execute([$id]);
    $pdo->prepare("UPDATE presente SET id_responsavel = NULL WHERE id_responsavel = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM tarefas WHERE id_staff = ?")->execute([$id]);
    $pdo->prepare("UPDATE evento SET id_cliente = NULL WHERE id_cliente = ?")->execute([$id]);
    $pdo->prepare("UPDATE utilizador SET id_organizador = NULL WHERE id_organizador = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento WHERE id_organizador = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM utilizador WHERE id_utilizador = ?")->execute([$id]);

    jsonOk([], 'Utilizador eliminado');
    break;
}
