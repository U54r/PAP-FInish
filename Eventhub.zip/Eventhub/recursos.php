<?php
// recursos.php — CRUD Recursos
// DB: gestao_eventos
// Tables: recurso (id_recurso, nome, categoria, quantidade_total, quantidade_usada, id_fornecedor)
//         evento_recurso (id_evento, id_recurso, quantidade) — join table, NO id_evento on recurso
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $id_evento = (int)($_GET['id_evento'] ?? 0);
    if ($id_evento) {
        requireRole(['organizador']);
        // Verify event belongs to this organizer before exposing its resources
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
        $evChk->execute([$id_evento, $_SESSION['id_utilizador']]);
        if (!$evChk->fetch()) jsonErro('Sem permissão.', 403);
        $stmt = $pdo->prepare("
            SELECT r.*,
                   er.quantidade AS qtd_evento,
                   e.nome_evento,
                   f.nome AS fornecedor_nome
            FROM evento_recurso er
            JOIN recurso r ON r.id_recurso = er.id_recurso
            JOIN evento  e ON e.id_evento  = er.id_evento
            LEFT JOIN fornecedor f ON f.id_fornecedor = r.id_fornecedor
            WHERE er.id_evento = ?
            ORDER BY r.nome
        ");
        $stmt->execute([$id_evento]);
    } else {
        requireRole(['organizador']);
        $stmt = $pdo->prepare("
            SELECT r.*,
                   GROUP_CONCAT(DISTINCT e.nome_evento SEPARATOR ', ') AS nome_evento,
                   f.nome AS fornecedor_nome
            FROM recurso r
            LEFT JOIN evento_recurso er ON er.id_recurso = r.id_recurso
            LEFT JOIN evento         e  ON e.id_evento   = er.id_evento
            LEFT JOIN fornecedor     f  ON f.id_fornecedor = r.id_fornecedor
            WHERE r.id_organizador = ?
            GROUP BY r.id_recurso
            ORDER BY r.nome
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
    }
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador']);
    $d = getBody();
    if (empty($d['nome'])) jsonErro('Nome do recurso é obrigatório');

    if (!empty($d['id_evento'])) {
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
        $evChk->execute([(int)$d['id_evento'], $_SESSION['id_utilizador']]);
        if (!$evChk->fetch()) jsonErro('Sem permissão.', 403);
    }

    $pdo->prepare("
        INSERT INTO recurso (nome, categoria, quantidade_total, quantidade_usada, id_fornecedor, data_entrega, prazo_confirmacao, estado_entrega, id_organizador)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ")->execute([
        $d['nome'],
        $d['categoria'] ?? '',
        !empty($d['quantidade_total']) ? (int)$d['quantidade_total'] : 0,
        !empty($d['quantidade_usada']) ? (int)$d['quantidade_usada'] : 0,
        !empty($d['id_fornecedor'])     ? (int)$d['id_fornecedor']  : null,
        !empty($d['data_entrega'])       ? $d['data_entrega']       : null,
        !empty($d['prazo_confirmacao'])  ? $d['prazo_confirmacao']  : null,
        $d['estado_entrega'] ?? 'pendente',
        $_SESSION['id_utilizador'],
    ]);
    $id_recurso = (int)$pdo->lastInsertId();

    if (!empty($d['id_evento'])) {
        $qtd = !empty($d['quantidade_total']) ? (int)$d['quantidade_total'] : 1;
        $pdo->prepare("
            INSERT IGNORE INTO evento_recurso (id_evento, id_recurso, quantidade)
            VALUES (?, ?, ?)
        ")->execute([(int)$d['id_evento'], $id_recurso, $qtd]);
    }

    jsonOk(['id_recurso' => $id_recurso], 'Recurso criado');
    break;

case 'PUT':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $d = getBody();
    $putChk = $pdo->prepare('SELECT id_recurso FROM recurso WHERE id_recurso = ? AND id_organizador = ?');
    $putChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$putChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("
        UPDATE recurso
        SET nome=?, categoria=?, quantidade_total=?, quantidade_usada=?, id_fornecedor=?,
            data_entrega=?, prazo_confirmacao=?, estado_entrega=?
        WHERE id_recurso=?
    ")->execute([
        $d['nome'],
        $d['categoria'] ?? '',
        !empty($d['quantidade_total']) ? (int)$d['quantidade_total'] : 0,
        !empty($d['quantidade_usada']) ? (int)$d['quantidade_usada'] : 0,
        !empty($d['id_fornecedor'])     ? (int)$d['id_fornecedor']  : null,
        !empty($d['data_entrega'])      ? $d['data_entrega']      : null,
        !empty($d['prazo_confirmacao']) ? $d['prazo_confirmacao'] : null,
        $d['estado_entrega'] ?? 'pendente',
        $id,
    ]);
    jsonOk([], 'Recurso atualizado');
    break;

case 'DELETE':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $delChk = $pdo->prepare('SELECT id_recurso FROM recurso WHERE id_recurso = ? AND id_organizador = ?');
    $delChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("DELETE FROM evento_recurso WHERE id_recurso=?")->execute([$id]);
    $pdo->prepare("DELETE FROM recurso WHERE id_recurso=?")->execute([$id]);
    jsonOk([], 'Recurso eliminado');
    break;
}
