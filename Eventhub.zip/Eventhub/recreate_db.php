<?php
// clean_tables.php - Limpa apenas os dados, mantém a estrutura
// ATENÇÃO: Este script vai ELIMINAR TODOS OS DADOS das tabelas!

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

require_once __DIR__ . '/db.php';

try {
    $pdo = getDB();
    
    // Desativar verificações de chaves estrangeiras temporariamente
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    // Lista de tabelas para limpar
    $tables = [
        'event_guest', 'evento_mesa', 'evento_presente', 'evento_recurso',
        'notificacoes', 'qr_codes', 'tarefas', 'presente', 'recurso',
        'guest', 'mesa', 'evento', 'utilizador', 'role'
    ];
    
    foreach ($tables as $table) {
        $pdo->exec("TRUNCATE TABLE `$table`");
        echo "✅ Tabela '$table' limpa<br>";
    }
    
    // Reativar verificações
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    
    // Inserir dados iniciais novamente
    $sql = file_get_contents(__DIR__ . '/scripts_bd.sql');
    // Extrair apenas os INSERTs (ignorar CREATE TABLEs)
    $lines = explode("\n", $sql);
    $inserts = [];
    $inInsert = false;
    
    foreach ($lines as $line) {
        if (stripos($line, 'INSERT INTO') !== false) {
            $inInsert = true;
        }
        if ($inInsert) {
            $inserts[] = $line;
            if (strpos($line, ';') !== false) {
                $inInsert = false;
            }
        }
    }
    
    $insertSQL = implode("\n", $inserts);
    if ($insertSQL) {
        $pdo->exec($insertSQL);
        echo "✅ Dados de demonstração reinseridos!<br>";
    }
    
    echo "<hr>";
    echo "<p style='color:green;font-weight:bold'>🎉 Dados limpos e recarregados com sucesso!</p>";
    echo "<a href='login.php'>Ir para o login</a>";
    
} catch (PDOException $e) {
    echo "<p style='color:red'>Erro: " . $e->getMessage() . "</p>";
}
?>