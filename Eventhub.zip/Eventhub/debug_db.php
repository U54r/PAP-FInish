<?php
/**
 * debug_db.php
 * 
 * Diagnostic tool to test database connection and structure.
 * Access: http://localhost/Eventhub/debug_db.php
 * 
 * Shows:
 * - Database connection status
 * - Database existence
 * - All tables and row counts
 * - Last PHP errors
 * - Configuration details
 */

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

require_once __DIR__ . '/auth.php';
requireRole(['administrador']);

// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Import database config
require_once __DIR__ . '/db.php';

?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventHub — Database Debug</title>
    <style>
        body { font-family: Inter, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; }
        h1 { color: #6366f1; margin-bottom: 30px; }
        .section { background: white; padding: 20px; margin-bottom: 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .section h2 { color: #333; border-bottom: 2px solid #6366f1; padding-bottom: 10px; margin-bottom: 15px; }
        .status { padding: 10px 15px; border-radius: 8px; margin: 10px 0; }
        .status.ok { background: #d1fae5; color: #065f46; }
        .status.error { background: #fee2e2; color: #991b1b; }
        .status.warning { background: #fef3c7; color: #92400e; }
        .row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        table { width: 100%; border-collapse: collapse; }
        table th, table td { padding: 10px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        table th { background: #f3f4f6; font-weight: 600; }
        table tr:hover { background: #f9fafb; }
        .code { background: #f3f4f6; padding: 10px; border-radius: 6px; font-family: monospace; font-size: 12px; }
    </style>
</head>
<body>

<div class="container">
    <h1>🔍 EventHub — Database Diagnostic</h1>

    <!-- Configuration Section -->
    <div class="section">
        <h2>⚙️ Configuration</h2>
        <div class="row">
            <div><strong>DB_HOST:</strong> <code><?php echo DB_HOST; ?></code></div>
            <div><strong>DB_NAME:</strong> <code><?php echo DB_NAME; ?></code></div>
            <div><strong>DB_USER:</strong> <code><?php echo DB_USER; ?></code></div>
            <div><strong>DB_PASS:</strong> <code><?php echo empty(DB_PASS) ? '(empty)' : '***'; ?></code></div>
            <div><strong>DB_CHARSET:</strong> <code><?php echo DB_CHARSET; ?></code></div>
            <div><strong>PHP Version:</strong> <code><?php echo PHP_VERSION; ?></code></div>
        </div>
    </div>

    <!-- Connection Test -->
    <div class="section">
        <h2>🔗 Database Connection</h2>
        <?php
        try {
            $pdo = getDB();
            echo '<div class="status ok">✓ PDO Connection Successful</div>';
            
            // Test actual query
            $result = $pdo->query('SELECT 1');
            if ($result) {
                echo '<div class="status ok">✓ Query Execution Works</div>';
            }
        } catch (Exception $e) {
            echo '<div class="status error">✗ Connection Failed</div>';
            echo '<div class="code">' . htmlspecialchars($e->getMessage()) . '</div>';
            echo '<div style="color: red; margin-top: 10px;">Cannot continue without database connection.</div>';
            exit;
        }
        ?>
    </div>

    <!-- Database Status -->
    <div class="section">
        <h2>📊 Database Status</h2>
        <?php
        try {
            $databases = $pdo->query("SHOW DATABASES LIKE '" . DB_NAME . "'")->fetchAll();
            if (!empty($databases)) {
                echo '<div class="status ok">✓ Database "' . DB_NAME . '" exists</div>';
            } else {
                echo '<div class="status error">✗ Database "' . DB_NAME . '" NOT found</div>';
                echo '<p>Try running: <code>CREATE DATABASE IF NOT EXISTS ' . DB_NAME . ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;</code></p>';
            }
        } catch (Exception $e) {
            echo '<div class="status error">✗ Error checking database: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        ?>
    </div>

    <!-- Tables & Row Counts -->
    <div class="section">
        <h2>📋 Tables & Row Counts</h2>
        <?php
        try {
            // Get all tables
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            
            if (empty($tables)) {
                echo '<div class="status error">✗ No tables found in database</div>';
                echo '<p>Run the Base_de_dados_PAP_fixed.sql file to create tables.</p>';
            } else {
                echo '<div class="status ok">✓ Found ' . count($tables) . ' tables</div>';
                echo '<table>';
                echo '<tr><th>Table Name</th><th>Row Count</th><th>Status</th></tr>';
                
                $requiredTables = ['role', 'utilizador', 'evento', 'guest', 'event_guest', 'mesa', 'evento_mesa'];
                
                foreach ($tables as $table) {
                    $count = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
                    $isRequired = in_array($table, $requiredTables);
                    $status = ($isRequired ? '✓ Required' : '○ Additional');
                    echo "<tr><td>$table</td><td>$count</td><td>$status</td></tr>";
                }
                
                echo '</table>';
            }
        } catch (Exception $e) {
            echo '<div class="status error">✗ Error listing tables: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        ?>
    </div>

    <!-- Key Table Details -->
    <div class="section">
        <h2>🔎 Key Table Details</h2>
        
        <?php
        $keyTables = [
            'role' => 'Roles (organizador, staff, convidado)',
            'utilizador' => 'Users',
            'evento' => 'Events',
            'guest' => 'Guests (simple table)',
            'event_guest' => 'Event-Guest association',
            'mesa' => 'Seating tables',
            'evento_mesa' => 'Event-Mesa association'
        ];
        
        foreach ($keyTables as $table => $description) {
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
                $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $count = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
                
                echo '<div style="margin-bottom: 15px; padding: 15px; background: #f9fafb; border-radius: 8px;">';
                echo "<strong>$table</strong> <em>($description)</em> — <span style='color: #6366f1;'>$count rows</span>";
                echo '<div style="margin-top: 10px; font-size: 12px;">';
                
                foreach ($columns as $col) {
                    $type = $col['Type'];
                    $null = $col['Null'] === 'YES' ? 'NULL' : 'NOT NULL';
                    $key = $col['Key'] ? " [{$col['Key']}]" : '';
                    echo "• {$col['Field']} — <code>$type</code> $null$key<br>";
                }
                
                echo '</div></div>';
            } catch (Exception $e) {
                echo '<div class="status error">✗ Error reading ' . $table . ': ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
        ?>
    </div>

    <!-- Test Insert Operation -->
    <div class="section">
        <h2>✅ Test Insert Operation</h2>
        <?php
        try {
            // Test: Insert a test guest
            $testName = "Test Guest " . date('Y-m-d H:i:s');
            $testEmail = "test_" . time() . "@test.com";
            
            $stmt = $pdo->prepare("INSERT INTO guest (nome, email, telefone) VALUES (?, ?, ?)");
            $stmt->execute([$testName, $testEmail, "9611111111"]);
            $lastId = $pdo->lastInsertId();
            
            // Verify
            $check = $pdo->prepare("SELECT * FROM guest WHERE id_guest = ?")->execute([$lastId]);
            $guest = $pdo->query("SELECT * FROM guest WHERE id_guest = $lastId")->fetch();
            
            if ($guest) {
                echo '<div class="status ok">✓ Test guest inserted and verified successfully</div>';
                echo '<p><strong>Inserted:</strong></p>';
                echo '<div class="code">' . json_encode($guest, JSON_PRETTY_PRINT) . '</div>';
                
                // Clean up
                $pdo->query("DELETE FROM guest WHERE id_guest = $lastId");
                echo '<p style="color: #666; font-size: 12px;">Test record has been cleaned up.</p>';
            } else {
                echo '<div class="status error">✗ Insert worked but verification failed</div>';
            }
        } catch (Exception $e) {
            echo '<div class="status error">✗ Insert test failed: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        ?>
    </div>

    <!-- PHP Error Log -->
    <div class="section">
        <h2>📝 Recent Errors (PHP Error Log)</h2>
        <?php
        $errorLog = ini_get('error_log');
        if ($errorLog && file_exists($errorLog)) {
            $lines = file($errorLog, FILE_IGNORE_NEW_LINES);
            $recent = array_slice($lines, -10); // Last 10 lines
            
            if (!empty($recent)) {
                echo '<div class="code">' . htmlspecialchars(implode("\n", $recent)) . '</div>';
            } else {
                echo '<div class="status ok">✓ No recent errors</div>';
            }
        } else {
            echo '<div class="status warning">⚠ Error log not configured or not found</div>';
            echo '<p>Error log path: <code>' . ($errorLog ?: '(not set)') . '</code></p>';
        }
        ?>
    </div>

    <!-- Recommendations -->
    <div class="section" style="border-left: 4px solid #6366f1;">
        <h2>💡 Recommendations</h2>
        <ul>
            <li><strong>If database doesn't exist:</strong> Run Base_de_dados_PAP_fixed.sql via phpMyAdmin</li>
            <li><strong>If tables are missing:</strong> Import the SQL file again</li>
            <li><strong>If inserts fail:</strong> Check FOREIGN KEY constraints and column names</li>
            <li><strong>If connection fails:</strong> Verify XAMPP MySQL is running, credentials are correct</li>
            <li><strong>After fixing:</strong> Test with the form in dashboard.php</li>
        </ul>
    </div>

</div>

</body>
</html>
