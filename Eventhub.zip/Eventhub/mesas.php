<?php
// mesas.php — CRUD Mesas
// DB: gestao_eventos
// Tables: mesa (id_mesa, numero, capacidade, localizacao) — NO id_evento column
//         evento_mesa (id_evento, id_mesa) — join table
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $id_evento = (int)($_GET['id_evento'] ?? 0);
    if ($id_evento) {
        $stmt = $pdo->prepare("
            SELECT m.id_mesa, m.numero, m.capacidade, m.localizacao,
                   m.nome, m.pos_x, m.pos_y, m.forma,
                   m.cor_toalha, m.tamanho,
                   (SELECT COUNT(*) FROM event_guest eg
                    WHERE eg.id_mesa = m.id_mesa AND eg.id_evento = ?) AS ocupacao
            FROM evento_mesa em
            JOIN mesa m ON m.id_mesa = em.id_mesa
            WHERE em.id_evento = ?
            ORDER BY m.numero
        ");
        $stmt->execute([$id_evento, $id_evento]);
        jsonOk($stmt->fetchAll());
    } else {
        requireRole(['organizador']);
        $stmt = $pdo->prepare("
            SELECT m.*,
                   GROUP_CONCAT(e.nome_evento) AS nome_evento
            FROM mesa m
            LEFT JOIN evento_mesa em ON em.id_mesa = m.id_mesa
            LEFT JOIN evento e ON e.id_evento = em.id_evento
            WHERE e.id_organizador = ?
            GROUP BY m.id_mesa
            ORDER BY m.numero
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
        jsonOk($stmt->fetchAll());
    }
    break;

case 'POST':
    requireRole(['organizador', 'cliente']);
    $d = getBody();
    if (empty($d['numero']) || empty($d['capacidade']) || empty($d['id_evento'])) {
        jsonErro('Campos obrigatórios: numero, capacidade, id_evento');
    }
    if ($_SESSION['role'] === 'cliente') {
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
    } else {
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
    }
    $evChk->execute([$d['id_evento'], $_SESSION['id_utilizador']]);
    if (!$evChk->fetch()) jsonErro('Sem permissão.', 403);

    $pdo->prepare("INSERT INTO mesa (numero, capacidade, localizacao, nome, pos_x, pos_y, forma, cor_toalha, tamanho) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        ->execute([
            (int)$d['numero'],
            (int)$d['capacidade'],
            $d['localizacao'] ?? '',
            $d['nome'] ?? null,
            (int)($d['pos_x'] ?? 80),
            (int)($d['pos_y'] ?? 80),
            $d['forma'] ?? 'round',
            $d['cor_toalha'] ?? 'teal',
            (int)($d['tamanho'] ?? 2),
        ]);
    $id_mesa = (int)$pdo->lastInsertId();

    $pdo->prepare("INSERT IGNORE INTO evento_mesa (id_evento, id_mesa) VALUES (?, ?)")
        ->execute([(int)$d['id_evento'], $id_mesa]);

    jsonOk(['id_mesa' => $id_mesa], 'Mesa criada');
    break;

case 'PUT':
    requireRole(['organizador', 'cliente']);
    if (!$id) jsonErro('ID obrigatório');
    $d = getBody();
    $ownerCol = $_SESSION['role'] === 'cliente' ? 'id_cliente' : 'id_organizador';
    $putChk = $pdo->prepare("
        SELECT m.id_mesa FROM mesa m
        JOIN evento_mesa em ON em.id_mesa = m.id_mesa
        JOIN evento e ON e.id_evento = em.id_evento
        WHERE m.id_mesa = ? AND e.$ownerCol = ?
    ");
    $putChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$putChk->fetch()) jsonErro('Sem permissão.', 403);

    // Position-only update (from floor plan drag)
    if (isset($d['pos_x']) && count($d) <= 2) {
        $pdo->prepare("UPDATE mesa SET pos_x=?, pos_y=? WHERE id_mesa=?")
            ->execute([(int)$d['pos_x'], (int)($d['pos_y'] ?? 0), $id]);
        jsonOk([], 'Posição guardada');
        break;
    }

    // Panel update (nome, forma, capacidade, cor_toalha, tamanho — no pos change)
    if (isset($d['cor_toalha']) || isset($d['tamanho'])) {
        $pdo->prepare("UPDATE mesa SET nome=?, forma=?, capacidade=?, cor_toalha=?, tamanho=? WHERE id_mesa=?")
            ->execute([
                $d['nome'] ?? null,
                $d['forma'] ?? 'round',
                (int)($d['capacidade'] ?? 0),
                $d['cor_toalha'] ?? 'teal',
                (int)($d['tamanho'] ?? 2),
                $id,
            ]);
        jsonOk([], 'Mesa atualizada');
        break;
    }

    // Basic modal edit — only update the fields visible in the form; never overwrite
    // floor-plan position or visual settings (those are managed by guardarMesaPanel)
    $pdo->prepare("UPDATE mesa SET numero=?, capacidade=?, localizacao=?, nome=?, forma=? WHERE id_mesa=?")
        ->execute([
            (int)$d['numero'],
            (int)$d['capacidade'],
            $d['localizacao'] ?? '',
            $d['nome'] ?? null,
            $d['forma'] ?? 'round',
            $id,
        ]);
    jsonOk([], 'Mesa atualizada');
    break;

case 'DELETE':
    requireRole(['organizador', 'cliente']);
    if (!$id) jsonErro('ID obrigatório');
    $ownerColDel = $_SESSION['role'] === 'cliente' ? 'id_cliente' : 'id_organizador';
    $delChk = $pdo->prepare("
        SELECT m.id_mesa FROM mesa m
        JOIN evento_mesa em ON em.id_mesa = m.id_mesa
        JOIN evento e ON e.id_evento = em.id_evento
        WHERE m.id_mesa = ? AND e.$ownerColDel = ?
    ");
    $delChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    // Guests keep their event association — just clear their table assignment
    $pdo->prepare("UPDATE event_guest SET id_mesa = NULL WHERE id_mesa=?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_mesa WHERE id_mesa=?")->execute([$id]);
    $pdo->prepare("DELETE FROM mesa WHERE id_mesa=?")->execute([$id]);
    jsonOk([], 'Mesa eliminada');
    break;
}
