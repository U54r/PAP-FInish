<?php
// enviar_email_staff.php — Envia email de acesso ao portal do staff
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/email_helper.php';
apiHeaders();
requireRole(['organizador']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErro('Método não permitido', 405);

$d        = getBody();
$id_staff = (int)($d['id_staff'] ?? 0);
if (!$id_staff) jsonErro('id_staff obrigatório');

$pdo = getDB();

// Confirm this staff member belongs to this organizer
$stmtSt = $pdo->prepare("
    SELECT u.*, r.nome_role
    FROM utilizador u
    JOIN role r ON r.id_role = u.id_role
    WHERE u.id_utilizador = ? AND u.id_organizador = ? AND r.nome_role = 'staff'
");
$stmtSt->execute([$id_staff, $_SESSION['id_utilizador']]);
$staff = $stmtSt->fetch();
if (!$staff) jsonErro('Staff não encontrado ou sem permissão', 403);

// Get organizer name
$stmtOrg = $pdo->prepare("SELECT nome FROM utilizador WHERE id_utilizador = ?");
$stmtOrg->execute([$_SESSION['id_utilizador']]);
$org = $stmtOrg->fetch();
$orgName = $org['nome'] ?? 'o organizador';

// Generate a fresh temporary password
$plainPwd = bin2hex(random_bytes(4)); // 8 chars
$hash     = hash('sha256', $plainPwd);

$pdo->prepare("UPDATE utilizador SET password = ? WHERE id_utilizador = ?")
    ->execute([$hash, $id_staff]);

$ok = sendStaffDashboardEmail(
    $staff['email'],
    $staff['nome'],
    $orgName,
    $plainPwd
);

if ($ok) {
    jsonOk(['password' => $plainPwd], 'Email enviado com sucesso para ' . $staff['email']);
} else {
    jsonErro('Falha no envio do email. Verifique as configurações SMTP.');
}
