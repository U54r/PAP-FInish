<?php
// admin_eventos.php — Visão global de eventos de todos os organizadores (admin)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireRole(['administrador']);

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $stmt = $pdo->query("
        SELECT e.*, o.nome AS organizador_nome,
               (SELECT COUNT(*) FROM event_guest eg WHERE eg.id_evento = e.id_evento) AS total_convidados
        FROM evento e
        JOIN utilizador o ON o.id_utilizador = e.id_organizador
        ORDER BY e.data DESC
    ");
    jsonOk($stmt->fetchAll());
    break;

case 'DELETE':
    if (!$id) jsonErro('ID obrigatório');
    $chk = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento = ?");
    $chk->execute([$id]);
    if (!$chk->fetch()) jsonErro('Evento não encontrado', 404);

    $pdo->prepare("DELETE FROM qr_codes WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_recurso WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_presente WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM tarefas WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM notificacoes WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM evento_mesa WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM event_guest WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM guest_invite_tokens WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM event_page_settings WHERE id_evento = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM decoracao WHERE id_evento = ?")->execute([$id]); // já tem ON DELETE CASCADE, redundante mas seguro
    $pdo->prepare("DELETE FROM evento WHERE id_evento = ?")->execute([$id]);

    jsonOk([], 'Evento eliminado');
    break;
}
