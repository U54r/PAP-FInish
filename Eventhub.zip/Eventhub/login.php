<?php
// login.php — Autenticação real com base de dados
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/config_google.php';

// Se já está logado, redireciona imediatamente
if (isLoggedIn()) {
    $role = $_SESSION['role'];
    if ($role === 'organizador')     { header('Location: dashboard.php'); exit; }
    elseif ($role === 'staff')       { header('Location: staff-dashboard.php'); exit; }
    elseif ($role === 'cliente')     { header('Location: cliente-dashboard.php'); exit; }
    elseif ($role === 'administrador') { header('Location: admin-dashboard.php'); exit; }
    else                             { header('Location: guest.php'); exit; }
}

$erro = '';
$msg  = '';

// Mensagem de sucesso após registo / outras ações
if (isset($_GET['msg'])) {
    $msg = match($_GET['msg']) {
        'registado'    => 'Conta criada com sucesso! Pode agora iniciar sessão.',
        'saiu'         => 'Sessão terminada. Até breve!',
        'google_login' => 'Bem-vindo! Login com Google bem-sucedido.',
        default        => $_GET['msg'],
    };
}
if (isset($_GET['erro']) && $_GET['erro'] === 'acesso_negado') {
    $erro = 'Não tem permissão para aceder a essa página.';
}
if (isset($_GET['erro']) && strpos($_GET['erro'], 'google_') === 0) {
    $erro = 'Erro no login com Google. Por favor, tente novamente.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password =      $_POST['password'] ?? '';

    if (!$email || !$password) {
        $erro = 'Preencha o email e a palavra-passe.';
    } else {
        $user = login($email, $password);

        if ($user) {
            // Redireciona conforme o role vindo da BD
            $role = $user['nome_role'];
            if ($role === 'organizador')     { header('Location: dashboard.php'); exit; }
            elseif ($role === 'staff')       { header('Location: staff-dashboard.php'); exit; }
            elseif ($role === 'cliente')     { header('Location: cliente-dashboard.php'); exit; }
            elseif ($role === 'administrador') { header('Location: admin-dashboard.php'); exit; }
            else                             { header('Location: guest.php'); exit; }
        } else {
            $erro = 'Email ou palavra-passe incorretos.';
        }
    }
}

$v_email = htmlspecialchars($_POST['email'] ?? '');

// Generate Google OAuth URL
$googleAuthUrl = getGoogleAuthUrl();
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrar — Event Hub</title>
    <meta name="description" content="Inicie sessão no Event Hub para gerir o seu evento.">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%230d9488'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' fill='white' font-size='18' font-weight='700' font-family='sans-serif'%3EEH%3C/text%3E%3C/svg%3E">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <script src="lang.js" defer></script>
    <style>
        .alert {
            display: flex; align-items: center; gap: 10px;
            padding: 13px 16px; border-radius: 10px;
            font-size: 14px; margin-bottom: 18px; line-height: 1.4;
        }
        .alert i { font-size: 18px; flex-shrink: 0; }
        .alert-error   { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
        .alert-success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
        
        /* Google Login Styling */
        .divider-section {
            display: flex; align-items: center; gap: 12px;
            margin: 24px 0; color: #6b7280; font-size: 14px;
        }
        .divider-section::before,
        .divider-section::after {
            content: ''; flex: 1; height: 1px; background: #e5e7eb;
        }
        
        .btn-google {
            width: 100%; padding: 12px 16px;
            background: white; border: 1px solid #e5e7eb;
            border-radius: 12px; font-family: Inter, sans-serif;
            font-size: 15px; font-weight: 500; color: #1f2937;
            cursor: pointer; transition: all 0.2s ease;
            display: flex; align-items: center; justify-content: center;
            gap: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }
        .btn-google:hover {
            background: #f9fafb; border-color: #d1d5db;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .btn-google:active {
            transform: scale(0.98);
        }
        
        .google-logo {
            width: 20px; height: 20px; flex-shrink: 0;
        }
    </style>
</head>
<body class="auth-page">

    <!-- Floating language switcher -->
    <div class="lang-switcher lang-switcher-float" role="group">
        <button class="lang-btn" data-lang="pt" onclick="setLang('pt')">🇵🇹 PT</button>
        <button class="lang-btn" data-lang="en" onclick="setLang('en')">🇺🇸 EN</button>
    </div>

<div class="login-container">

    <div class="auth-logo">
        <i class="ph-fill ph-calendar-check"></i>
        <span>Event Hub</span>
    </div>

    <div class="auth-card">
        <div class="auth-header">
            <h2 data-i18n="login.title">Bem-vindo de volta</h2>
            <p data-i18n="login.subtitle">Entre na sua conta para gerir o seu evento</p>
        </div>

        <?php if ($erro): ?>
        <div class="alert alert-error">
            <i class="ph ph-warning-circle"></i>
            <span><?= htmlspecialchars($erro) ?></span>
        </div>
        <?php endif; ?>

        <?php if ($msg): ?>
        <div class="alert alert-success">
            <i class="ph ph-check-circle"></i>
            <span><?= htmlspecialchars($msg) ?></span>
        </div>
        <?php endif; ?>

        <form method="POST" action="login.php" class="auth-form">

            <div class="input-group">
                <label for="email">Email</label>
                <div class="input-wrapper">
                    <i class="ph ph-envelope"></i>
                    <input type="email" id="email" name="email"
                           placeholder="seu@email.com" required
                           value="<?= $v_email ?>" autofocus>
                </div>
            </div>

            <div class="input-group">
                <div class="label-row">
                    <label for="password" data-i18n="login.password">Palavra-passe</label>
                    <a href="#" class="forgot-link" data-i18n="login.forgot">Esqueceu-se?</a>
                </div>
                <div class="input-wrapper">
                    <i class="ph ph-lock"></i>
                    <input type="password" id="password" name="password"
                           placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" class="btn-primary-full" data-i18n="login.btn">Entrar</button>
        </form>

        <!-- Google Login Section -->
        <div class="divider-section" data-i18n="login.or">ou</div>
        
        <a href="<?= htmlspecialchars($googleAuthUrl) ?>" class="btn-google">
            <svg class="google-logo" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span data-i18n="login.google">Entrar com Google</span>
        </a>

        <div class="auth-footer">
            <p><span data-i18n="login.noAccount">Não tem uma conta?</span> <a href="registo.php" data-i18n="login.registerLink">Registe-se</a></p>
        </div>
    </div>

    <a href="index.html" class="back-to-site">
        <i class="ph ph-arrow-left"></i> <span data-i18n="login.back">Voltar ao início</span>
    </a>
</div>

<script>
    function togglePwd(inputId, iconId) {
        const input = document.getElementById(inputId);
        const icon  = document.getElementById(iconId);
        if (input.type === 'password') { input.type = 'text'; icon.className = 'ph ph-eye-slash'; }
        else { input.type = 'password'; icon.className = 'ph ph-eye'; }
    }
</script>
</body>
</html>
