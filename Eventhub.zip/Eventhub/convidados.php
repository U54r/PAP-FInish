<?php
/**
 * convidados.php — Gestão de convidados de um evento.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/email_helper.php';

apiHeaders();
requireLogin();

$db           = getDB();
$method       = $_SERVER['REQUEST_METHOD'];
$loggedUserId = (int) ($_SESSION['id_utilizador'] ?? 0);

match ($method) {
    'GET'    => handleGet($db),
    'POST'   => handlePost($db, $loggedUserId),
    'PUT'    => handlePut($db, $loggedUserId),
    'DELETE' => handleDelete($db),
    default  => jsonErro('Método não suportado.', 405),
};

// =============================================================================
// GET — lista convidados de um evento ou todos
// =============================================================================
function handleGet(PDO $db): void
{
    $idEvento = filter_input(INPUT_GET, 'id_evento', FILTER_VALIDATE_INT);

    if ($idEvento) {
        $role = $_SESSION['role'] ?? '';
        $uid  = (int)($_SESSION['id_utilizador'] ?? 0);
        if ($role === 'organizador') {
            $chk = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
        } elseif ($role === 'cliente') {
            $chk = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
        } else {
            jsonErro('Sem permissão.', 403); return;
        }
        $chk->execute([$idEvento, $uid]);
        if (!$chk->fetch()) { jsonErro('Sem permissão.', 403); return; }

        $stmt = $db->prepare(
            'SELECT
                 eg.id_guest,
                 eg.estado_rsvp,
                 eg.id_mesa,
                 eg.id_evento,
                 g.nome,
                 g.email,
                 g.telefone,
                 e.nome_evento,
                 m.numero as num_mesa
             FROM event_guest eg
             JOIN guest g ON g.id_guest = eg.id_guest
             JOIN evento e ON e.id_evento = eg.id_evento
             LEFT JOIN mesa m ON m.id_mesa = eg.id_mesa
             WHERE eg.id_evento = ?
             ORDER BY g.nome ASC'
        );
        $stmt->execute([$idEvento]);
        jsonOk($stmt->fetchAll(PDO::FETCH_ASSOC));
    } else {
        $stmt = $db->prepare(
            'SELECT
                 eg.id_guest,
                 eg.estado_rsvp,
                 eg.id_mesa,
                 eg.id_evento,
                 g.nome,
                 g.email,
                 g.telefone,
                 e.nome_evento,
                 m.numero as num_mesa
             FROM event_guest eg
             JOIN guest g ON g.id_guest = eg.id_guest
             JOIN evento e ON e.id_evento = eg.id_evento
             LEFT JOIN mesa m ON m.id_mesa = eg.id_mesa
             WHERE e.id_organizador = ?
             ORDER BY e.nome_evento, g.nome ASC'
        );
        $stmt->execute([$_SESSION['id_utilizador'] ?? 0]);
        jsonOk($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
}

// =============================================================================
// POST — adicionar convidado a um evento
// =============================================================================
function handlePost(PDO $db, int $loggedUserId): void
{
    $body     = getBody();
    $idEvento = isset($body['id_evento']) ? (int) $body['id_evento'] : 0;
    $nome     = trim($body['nome']     ?? '');
    $email    = trim($body['email']    ?? '');
    $telefone = trim($body['telefone'] ?? '');
    $idMesa   = (isset($body['id_mesa']) && $body['id_mesa'] !== '' && $body['id_mesa'] !== null)
                    ? (int) $body['id_mesa'] : null;

    if (!$idEvento || $nome === '') {
        jsonErro('id_evento e nome são obrigatórios.');
        return;
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonErro('Endereço de email inválido.');
        return;
    }

    // Fetch event details — organizers own events, clients are linked via id_cliente
    $role = $_SESSION['role'] ?? '';
    if ($role === 'cliente') {
        $stmtEvento = $db->prepare(
            'SELECT id_evento, nome_evento, data, local
             FROM evento
             WHERE id_evento = ? AND id_cliente = ?'
        );
    } else {
        $stmtEvento = $db->prepare(
            'SELECT id_evento, nome_evento, data, local
             FROM evento
             WHERE id_evento = ? AND id_organizador = ?'
        );
    }
    $stmtEvento->execute([$idEvento, $loggedUserId]);
    $evento = $stmtEvento->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        jsonErro('Evento não encontrado ou sem permissão.', 403);
        return;
    }

    $db->beginTransaction();

    try {
        // Insert guest record
        $stmtGuest = $db->prepare('INSERT INTO guest (nome, email, telefone) VALUES (?, ?, ?)');
        $stmtGuest->execute([$nome, $email ?: null, $telefone ?: null]);
        $idGuest = (int) $db->lastInsertId();

        // Associate guest to event
        $stmtAssoc = $db->prepare(
            'INSERT INTO event_guest (id_evento, id_guest, id_mesa, estado_rsvp)
             VALUES (?, ?, ?, \'pendente\')'
        );
        $stmtAssoc->execute([$idEvento, $idGuest, $idMesa]);

        $emailEnviado = false;

        if ($email !== '') {
            $loginUrl   = APP_BASE_URL . '/login.php';
            $rsvpUrl    = APP_BASE_URL . '/guest.php';
            $eventDate  = date('d/m/Y', strtotime($evento['data']));
            $eventLocal = $evento['local'] ?? '';

            // Generate a magic-link token for every guest invitation (new and existing)
            $token   = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+7 days'));
            $db->prepare(
                'INSERT INTO guest_invite_tokens (id_evento, email, token, expires, used) VALUES (?, ?, ?, ?, 0)'
            )->execute([$idEvento, $email, $token, $expires]);

            $stmtUser = $db->prepare('SELECT id_utilizador FROM utilizador WHERE email = ?');
            $stmtUser->execute([$email]);
            $utilizadorExistente = $stmtUser->fetch(PDO::FETCH_ASSOC);

            if (!$utilizadorExistente) {
                // New guest: generate 8-char password, create account, send welcome email
                $chars         = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                $plainPassword = substr(str_shuffle(str_repeat($chars, 3)), 0, 8);
                $passwordHash  = hash('sha256', $plainPassword);

                // Fetch the convidado role ID first (safer than INSERT...SELECT)
                $stmtRole = $db->prepare("SELECT id_role FROM role WHERE nome_role = 'convidado' LIMIT 1");
                $stmtRole->execute();
                $roleRow = $stmtRole->fetch(PDO::FETCH_ASSOC);
                $roleId  = $roleRow['id_role'] ?? 4;

                $stmtCriarUser = $db->prepare(
                    'INSERT INTO utilizador (nome, email, password, id_role, id_organizador, estado_conta)
                     VALUES (?, ?, ?, ?, ?, \'ativo\')'
                );
                $stmtCriarUser->execute([$nome, $email, $passwordHash, $roleId, $loggedUserId]);

                $emailEnviado = sendWelcomeEmail(
                    $email,
                    $nome,
                    $evento['nome_evento'],
                    $eventDate,
                    $eventLocal,
                    $plainPassword,
                    $loginUrl,
                    $rsvpUrl,
                    $token
                );
            } else {
                // Existing user: send reminder with magic link
                $emailEnviado = sendReminderEmail(
                    $email,
                    $nome,
                    $evento['nome_evento'],
                    $eventDate,
                    $eventLocal,
                    $loginUrl,
                    $rsvpUrl,
                    $token
                );
            }

            if (!$emailEnviado) {
                error_log("[EventHub] Email não enviado para {$email} (evento {$idEvento}).");
            }
        }

        $db->commit();

        jsonOk([
            'id_guest'      => $idGuest,
            'email_enviado' => $emailEnviado,
        ]);

    } catch (Throwable $e) {
        $db->rollBack();
        error_log('[EventHub] Erro em convidados.php POST: ' . $e->getMessage());
        jsonErro('Erro interno ao adicionar convidado.');
    }
}

// =============================================================================
// PUT — atualizar dados de um convidado
// =============================================================================
function handlePut(PDO $db, int $loggedUserId): void
{
    requireRole(['organizador', 'cliente']);

    $idGuest = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if (!$idGuest) { jsonErro('ID do convidado é obrigatório.'); return; }

    $body       = getBody();
    $nome       = trim($body['nome']        ?? '');
    $email      = trim($body['email']       ?? '');
    $telefone   = trim($body['telefone']    ?? '');
    $idEvento   = isset($body['id_evento']) ? (int) $body['id_evento'] : 0;
    $idMesa     = (isset($body['id_mesa']) && $body['id_mesa'] !== '' && $body['id_mesa'] !== null)
                      ? (int) $body['id_mesa'] : null;
    $estadoRsvp = trim($body['estado_rsvp'] ?? 'pendente');

    if ($nome === '') { jsonErro('Nome é obrigatório.'); return; }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonErro('Endereço de email inválido.'); return;
    }
    if (!$idEvento) { jsonErro('id_evento é obrigatório.'); return; }

    // Verify the event belongs to this organizer or client
    $role = $_SESSION['role'] ?? '';
    if ($role === 'cliente') {
        $stmtCheck = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
    } else {
        $stmtCheck = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
    }
    $stmtCheck->execute([$idEvento, $loggedUserId]);
    if (!$stmtCheck->fetch()) { jsonErro('Evento não encontrado ou sem permissão.', 403); return; }

    // Verify this guest is actually linked to this event
    $assocCheck = $db->prepare('SELECT id_guest FROM event_guest WHERE id_guest = ? AND id_evento = ?');
    $assocCheck->execute([$idGuest, $idEvento]);
    if (!$assocCheck->fetch()) { jsonErro('Convidado não associado a este evento.', 403); return; }

    try {
        $db->prepare('UPDATE guest SET nome = ?, email = ?, telefone = ? WHERE id_guest = ?')
           ->execute([$nome, $email ?: null, $telefone ?: null, $idGuest]);

        $db->prepare('UPDATE event_guest SET id_mesa = ?, estado_rsvp = ? WHERE id_guest = ? AND id_evento = ?')
           ->execute([$idMesa, $estadoRsvp, $idGuest, $idEvento]);

        jsonOk([], 'Convidado atualizado.');
    } catch (Throwable $e) {
        error_log('[EventHub] Erro em convidados.php PUT: ' . $e->getMessage());
        jsonErro('Erro interno ao atualizar convidado.');
    }
}

// =============================================================================
// DELETE — remover convidado de um evento
// =============================================================================
function handleDelete(PDO $db): void
{
    requireRole(['organizador', 'cliente']);

    $idEvento     = filter_input(INPUT_GET, 'id_evento', FILTER_VALIDATE_INT);
    $idGuest      = filter_input(INPUT_GET, 'id_guest',  FILTER_VALIDATE_INT);
    $loggedUserId = (int)($_SESSION['id_utilizador'] ?? 0);
    $role         = $_SESSION['role'] ?? '';

    if (!$idEvento || !$idGuest) {
        jsonErro('Parâmetros id_evento e id_guest são obrigatórios.');
        return;
    }

    // Verify the event belongs to this organizer or client
    if ($role === 'cliente') {
        $chk = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
    } else {
        $chk = $db->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
    }
    $chk->execute([$idEvento, $loggedUserId]);
    if (!$chk->fetch()) {
        jsonErro('Sem permissão.', 403);
        return;
    }

    $stmt = $db->prepare('DELETE FROM event_guest WHERE id_evento = ? AND id_guest = ?');
    $stmt->execute([$idEvento, $idGuest]);

    if ($stmt->rowCount() === 0) {
        jsonErro('Associação não encontrada.', 404);
        return;
    }

    jsonOk(['mensagem' => 'Convidado removido do evento.']);
}
