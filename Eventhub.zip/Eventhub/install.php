<?php
/**
 * install.php
 *
 * EventHub Installation & Setup Script
 *
 * This script:
 * 1. Checks if the database gestao_eventos exists
 * 2. If not, optionally creates it from Base_de_dados_PAP_fixed.sql
 * 3. Displays setup status and next steps
 *
 * Note: Normally, db.php handles auto-creation on first run.
 * Use this script if you want to manually reset the database.
 */

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

// Database credentials (must match db.php)
define('DB_HOST',  'localhost');
define('DB_USER',  'root');
define('DB_PASS',  '');
define('DB_NAME',  'gestao_eventos');
define('DB_CHARSET', 'utf8mb4');

// Get action from POST (if any)
$action = $_POST['action'] ?? '';
$sqlFile = __DIR__ . '/Base_de_dados_PAP_fixed.sql';

// Start output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventHub — Installation</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 28px;
            color: #1a202c;
            margin-bottom: 10px;
        }
        .header p {
            color: #718096;
            font-size: 14px;
        }
        .logo {
            font-size: 48px;
            margin-bottom: 15px;
        }
        .status {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }
        .status-icon {
            font-size: 24px;
            flex-shrink: 0;
        }
        .status.success {
            background: #f0fdf4;
            border: 1px solid #dcfce7;
            color: #166534;
        }
        .status.success .status-icon { color: #22c55e; }
        .status.warning {
            background: #fefce8;
            border: 1px solid #fef3c7;
            color: #92400e;
        }
        .status.warning .status-icon { color: #eab308; }
        .status.error {
            background: #fef2f2;
            border: 1px solid #fee2e2;
            color: #991b1b;
        }
        .status.error .status-icon { color: #ef4444; }
        .status h3 {
            font-size: 16px;
            margin-bottom: 4px;
        }
        .status p {
            font-size: 14px;
            line-height: 1.5;
        }
        .code {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 12px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            overflow-x: auto;
            margin-top: 8px;
            color: #2d3748;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-size: 14px;
            font-weight: 500;
            color: #2d3748;
            margin-bottom: 8px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #cbd5e0;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 6px;
            border: none;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-1px);
            box-shadow: 0 8px 16px rgba(102, 126, 234, 0.4);
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #2d3748;
        }
        .btn-secondary:hover {
            background: #cbd5e0;
        }
        .btn-danger {
            background: #ef4444;
            color: white;
        }
        .btn-danger:hover {
            background: #dc2626;
        }
        .actions {
            display: flex;
            gap: 10px;
            margin-top: 24px;
        }
        .actions .btn {
            flex: 1;
            text-align: center;
        }
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 8px;
            padding: 16px;
            margin: 20px 0;
            color: #1e40af;
            font-size: 14px;
            line-height: 1.6;
        }
        .info-box strong {
            display: block;
            margin-bottom: 8px;
        }
        .credentials {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
            margin-top: 10px;
            font-size: 13px;
            font-family: monospace;
        }
        .credentials div {
            margin-bottom: 6px;
        }
        .credentials span {
            color: #667eea;
            font-weight: 600;
        }
        a {
            color: #667eea;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="logo">📅</div>
        <h1>EventHub Installation</h1>
        <p>Event Management System Setup</p>
    </div>

    <?php
    // Try to connect to MySQL
    try {
        $mysqlConn = new PDO(
            'mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET,
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    } catch (PDOException $e) {
        ?>
        <div class="status error">
            <div class="status-icon">❌</div>
            <div>
                <h3>MySQL Connection Failed</h3>
                <p>Cannot connect to MySQL. Please ensure:</p>
                <ul style="margin-left: 20px; margin-top: 8px;">
                    <li>XAMPP is running (Apache + MySQL)</li>
                    <li>MySQL credentials are correct (user: <code>root</code>, password: empty)</li>
                </ul>
                <div class="code"><?= htmlspecialchars($e->getMessage()) ?></div>
                <p style="margin-top: 12px;">
                    <strong>To fix:</strong> Open XAMPP Control Panel → Click "Start" on MySQL → Refresh this page
                </p>
            </div>
        </div>
        <?php
        exit;
    }

    // Check if database exists
    $dbExists = false;
    try {
        $result = $mysqlConn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . DB_NAME . "'");
        $dbExists = (bool)$result->fetch();
    } catch (Exception $e) {}

    if ($dbExists && !$action) {
        // Database already exists
        ?>
        <div class="status success">
            <div class="status-icon">✅</div>
            <div>
                <h3>Database Already Installed</h3>
                <p>The database <code><?= DB_NAME ?></code> already exists and is ready to use.</p>
            </div>
        </div>

        <div class="info-box">
            <strong>Demo Credentials:</strong>
            <div class="credentials">
                <div><strong>Organizer:</strong> bruno.costa@email.com / org123</div>
                <div><strong>Staff:</strong> carla.mendes@email.com / staff123</div>
                <div><strong>Guest:</strong> (Set up via invitation link)</div>
            </div>
        </div>

        <div class="actions">
            <a href="login.php" class="btn btn-primary">Go to Login</a>
            <form method="POST" style="flex: 1;">
                <button type="submit" name="action" value="reset" class="btn btn-danger" style="width: 100%; margin: 0;">Reset Database</button>
            </form>
        </div>
        <?php

    } elseif ($action === 'reset' || !$dbExists) {
        // Need to create/reset database

        if (!file_exists($sqlFile)) {
            ?>
            <div class="status error">
                <div class="status-icon">❌</div>
                <div>
                    <h3>SQL File Not Found</h3>
                    <p>Cannot find <code><?= $sqlFile ?></code></p>
                    <p>Make sure the file exists in the EventHub root directory.</p>
                </div>
            </div>
            <?php
            exit;
        }

        // Read SQL file
        $sql = file_get_contents($sqlFile);
        if (!$sql) {
            ?>
            <div class="status error">
                <div class="status-icon">❌</div>
                <div>
                    <h3>Cannot Read SQL File</h3>
                    <p>The SQL file exists but cannot be read. Check file permissions.</p>
                </div>
            </div>
            <?php
            exit;
        }

        // Try to execute SQL
        try {
            // Split SQL into individual statements (naive but works for most cases)
            $statements = array_filter(
                explode(';', $sql),
                function ($stmt) {
                    return trim($stmt) !== '';
                }
            );

            foreach ($statements as $statement) {
                $stmt = trim($statement);
                if (!empty($stmt)) {
                    $mysqlConn->exec($stmt);
                }
            }

            ?>
            <div class="status success">
                <div class="status-icon">✅</div>
                <div>
                    <h3><?= $dbExists && $action === 'reset' ? 'Database Reset Successfully' : 'Database Created Successfully' ?></h3>
                    <p>The EventHub database has been <?= $dbExists && $action === 'reset' ? 'reset' : 'created' ?> with all tables and demo data.</p>
                </div>
            </div>

            <div class="info-box">
                <strong>What's included:</strong>
                <ul style="margin-left: 20px; margin-top: 8px;">
                    <li>Database: <code><?= DB_NAME ?></code></li>
                    <li>Tables: role, utilizador, evento, event_guest, mesa, etc.</li>
                    <li>Demo users for testing (see credentials below)</li>
                    <li>Sample events with guests</li>
                </ul>
            </div>

            <div class="info-box">
                <strong>Demo Credentials:</strong>
                <div class="credentials">
                    <div><strong>Admin:</strong> ana.silva@email.com / admin123</div>
                    <div><strong>Organizer 1:</strong> bruno.costa@email.com / org123</div>
                    <div><strong>Organizer 2:</strong> eva.nunes@email.com / org456</div>
                    <div><strong>Staff 1:</strong> carla.mendes@email.com / staff123</div>
                    <div><strong>Staff 2:</strong> david.lopes@email.com / staff456</div>
                </div>
            </div>

            <div class="actions">
                <a href="login.php" class="btn btn-primary">Go to Login</a>
            </div>

            <?php

        } catch (Exception $e) {
            ?>
            <div class="status error">
                <div class="status-icon">❌</div>
                <div>
                    <h3>Error Executing SQL</h3>
                    <p>Failed to execute the SQL file. This might indicate a syntax error or database issue.</p>
                    <div class="code"><?= htmlspecialchars($e->getMessage()) ?></div>
                </div>
            </div>
            <?php
            exit;
        }

    } else {
        // Show reset confirmation form
        ?>
        <div class="status warning">
            <div class="status-icon">⚠️</div>
            <div>
                <h3>Reset Database?</h3>
                <p>This will <strong>delete all data</strong> in the <code><?= DB_NAME ?></code> database and restore it to the default state.</p>
                <p>All events, guests, and custom settings will be lost.</p>
            </div>
        </div>

        <form method="POST">
            <div class="form-group">
                <label>
                    <input type="checkbox" name="confirm" value="yes" required>
                    Yes, I understand and want to reset the database
                </label>
            </div>
            <div class="actions">
                <a href="install.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" name="action" value="reset" class="btn btn-danger">Reset Now</button>
            </div>
        </form>
        <?php
    }
    ?>

</div>

</body>
</html>
