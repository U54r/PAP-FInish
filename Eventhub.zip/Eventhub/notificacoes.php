<?php
// notificacoes.php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT n.*, e.nome_evento
        FROM notificacoes n
        LEFT JOIN evento e ON e.id_evento = n.id_evento
        WHERE n.id_utilizador = ?
        ORDER BY n.data_hora DESC
        LIMIT 30
    ");
    $stmt->execute([$_SESSION['id_utilizador']]);
    jsonOk($stmt->fetchAll());
}

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id) {
        $pdo->prepare("DELETE FROM notificacoes WHERE id_notificacao=? AND id_utilizador=?")
            ->execute([$id, $_SESSION['id_utilizador']]);
    } else {
        $pdo->prepare("DELETE FROM notificacoes WHERE id_utilizador=?")
            ->execute([$_SESSION['id_utilizador']]);
    }
    jsonOk([], 'Notificação removida');
}
