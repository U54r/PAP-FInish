<?php
/**
 * email_helper.php
 *
 * Email helper functions using PHPMailer library.
 * Loads PHPMailer from PHPMailer-7.1.1/src/ (standalone, no Composer required).
 *
 * CONFIGURATION:
 * Modify the constants below (MAIL_HOST, MAIL_PORT, etc.) to match your SMTP settings.
 * For local development, you can use MailHog instead of a real SMTP server.
 *
 * LOCAL TESTING WITH MAILHOG:
 *   1. Download MailHog: https://github.com/mailhog/MailHog/releases
 *   2. Run: ./MailHog (starts SMTP on 127.0.0.1:1025, Web UI on 127.0.0.1:8025)
 *   3. Set MAIL_HOST = '127.0.0.1', MAIL_PORT = 1025
 *   4. Remove SMTP auth (set SMTPAuth = false) or leave empty credentials
 *   5. View sent emails at http://127.0.0.1:8025
 */

// ── Load PHPMailer directly (no Composer) ───────────────────────────────────
require_once __DIR__ . '/PHPMailer-7.1.1/src/Exception.php';
require_once __DIR__ . '/PHPMailer-7.1.1/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-7.1.1/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as MailerException;

// ─────────────────────────────────────────────────────────────────────────────
// SMTP CONFIGURATION — Edit these constants before deploying
// ─────────────────────────────────────────────────────────────────────────────
define('MAIL_HOST',       'smtp.gmail.com');           // SMTP server address
define('MAIL_PORT',       587);                        // 587 (TLS) or 465 (SSL)
define('MAIL_USERNAME',   'gabrielrooliveira12@gmail.com'); // Sender email
define('MAIL_PASSWORD',   'tsah ozjt qvnv fqxs');      // App Password or SMTP password
define('MAIL_ENCRYPTION', PHPMailer::ENCRYPTION_STARTTLS); // Use ENCRYPTION_SMTPS for port 465
define('MAIL_FROM_NAME',  'EventHub');                 // Display name in "From" field

// Application base URL — adjust to your domain
// Local:      'http://localhost/Eventhub'
// Production: 'https://www.yourdomain.com'
define('APP_BASE_URL', 'http://localhost/Eventhub');
// ─────────────────────────────────────────────────────────────────────────────


/**
 * Envia o email de convite ao convidado.
 *
 * @param  string $toEmail    Endereço de email do destinatário.
 * @param  string $eventName  Nome do evento.
 * @param  string $token      Token único gerado para este convite.
 * @param  int    $eventId    ID do evento (para contexto no email).
 * @return bool               true em caso de sucesso, false em caso de erro.
 */
/** Configura PHPMailer com as definições SMTP comuns (evita duplicar código). */
function _configurarMailer(PHPMailer $mail): void
{
    $mail->isSMTP();
    $mail->Host       = MAIL_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = MAIL_USERNAME;
    $mail->Password   = MAIL_PASSWORD;
    $mail->SMTPSecure = MAIL_ENCRYPTION;
    $mail->Port       = MAIL_PORT;
    $mail->CharSet    = 'UTF-8';
    // Bypass SSL peer verification — necessário em XAMPP/Windows local
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ],
    ];
}

function sendInvitationEmail(string $toEmail, string $eventName, string $token, int $eventId): bool
{
    $mail = new PHPMailer(true);

    try {
        _configurarMailer($mail);

        // ── Remetente / Destinatário ───────────────────────────
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

        // ── Conteúdo ───────────────────────────────────────────
        $setupLink = APP_BASE_URL . '/guest_setup.php?token=' . urlencode($token);

        $mail->isHTML(true);
        $mail->Subject = 'Convite para o evento: ' . $eventName;
        $mail->Body    = buildInviteHtml($toEmail, $eventName, $setupLink);
        $mail->AltBody = buildInviteText($toEmail, $eventName, $setupLink);

        $mail->send();
        return true;

    } catch (MailerException $e) {
        // Regista o erro sem expor detalhes ao utilizador
        error_log('[EventHub] Falha no envio de email para ' . $toEmail . ': ' . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Envia email de boas-vindas ao novo convidado com credenciais de acesso.
 */
function sendWelcomeEmail(
    string $toEmail,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): bool {
    $mail = new PHPMailer(true);
    try {
        _configurarMailer($mail);
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

        $mail->isHTML(true);
        $mail->Subject = 'Convite para ' . $eventName . ' — EventHub';
        $mail->Body    = buildWelcomeHtml($toEmail, $guestName, $eventName, $eventDate, $eventLocal, $plainPassword, $loginUrl, $rsvpUrl, $magicToken);
        $mail->AltBody = buildWelcomeText($toEmail, $guestName, $eventName, $eventDate, $eventLocal, $plainPassword, $loginUrl, $rsvpUrl, $magicToken);

        $mail->send();
        return true;
    } catch (MailerException $e) {
        error_log('[EventHub] Falha no envio de email para ' . $toEmail . ': ' . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Envia email de lembrete a convidado já registado.
 */
function sendReminderEmail(
    string $toEmail,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): bool {
    $mail = new PHPMailer(true);
    try {
        _configurarMailer($mail);
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

        $mail->isHTML(true);
        $mail->Subject = 'Convite para ' . $eventName . ' — EventHub';
        $mail->Body    = buildReminderHtml($toEmail, $guestName, $eventName, $eventDate, $eventLocal, $loginUrl, $rsvpUrl, $magicToken);
        $mail->AltBody = buildReminderText($toEmail, $guestName, $eventName, $eventDate, $eventLocal, $loginUrl, $rsvpUrl, $magicToken);

        $mail->send();
        return true;
    } catch (MailerException $e) {
        error_log('[EventHub] Falha no envio de email para ' . $toEmail . ': ' . $mail->ErrorInfo);
        return false;
    }
}

// ─── Helpers de template ─────────────────────────────────────────────────────

/**
 * Gera o corpo HTML do email de convite.
 */
function buildInviteHtml(string $email, string $eventName, string $link): string
{
    $safeEvent = htmlspecialchars($eventName, ENT_QUOTES, 'UTF-8');
    $safeEmail = htmlspecialchars($email,     ENT_QUOTES, 'UTF-8');
    $safeLink  = htmlspecialchars($link,      ENT_QUOTES, 'UTF-8');

    return <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Convite EventHub</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:30px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0"
               style="background:#ffffff;border-radius:8px;overflow:hidden;
                      box-shadow:0 2px 8px rgba(0,0,0,.1);">

          <!-- Cabeçalho -->
          <tr>
            <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);padding:32px;text-align:center;">
              <h1 style="margin:0;color:#ffffff;font-size:24px;letter-spacing:1px;">
                EventHub
              </h1>
            </td>
          </tr>

          <!-- Corpo -->
          <tr>
            <td style="padding:40px 40px 24px;">
              <h2 style="margin:0 0 16px;color:#1f2937;font-size:20px;">
                Foi convidado para um evento!
              </h2>
              <p style="margin:0 0 12px;color:#374151;line-height:1.6;">
                Olá,<br><br>
                Foi adicionado como convidado ao evento
                <strong>{$safeEvent}</strong>.
              </p>
              <p style="margin:0 0 24px;color:#374151;line-height:1.6;">
                Para aceder à sua área de convidado, clique no botão abaixo e
                defina a sua password. O link é válido durante <strong>7 dias</strong>
                e apenas pode ser utilizado uma vez.
              </p>

              <!-- Botão CTA -->
              <table cellpadding="0" cellspacing="0" style="margin:0 auto 32px;">
                <tr>
                  <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);border-radius:6px;text-align:center;">
                    <a href="{$safeLink}"
                       style="display:inline-block;padding:14px 32px;color:#ffffff;
                              font-size:16px;font-weight:bold;text-decoration:none;">
                      Definir Password &amp; Entrar
                    </a>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 8px;color:#6b7280;font-size:13px;">
                Se o botão não funcionar, copie e cole este link no seu browser:
              </p>
              <p style="margin:0 0 24px;word-break:break-all;">
                <a href="{$safeLink}" style="color:#0d9488;font-size:13px;">{$safeLink}</a>
              </p>

              <hr style="border:none;border-top:1px solid #e5e7eb;margin:0 0 24px;">

              <p style="margin:0;color:#9ca3af;font-size:12px;line-height:1.5;">
                Este email foi enviado para {$safeEmail} porque foi registado como
                convidado na plataforma EventHub. Se não reconhece este convite,
                pode ignorar este email em segurança.
              </p>
            </td>
          </tr>

          <!-- Rodapé -->
          <tr>
            <td style="background:#f9fafb;padding:20px 40px;text-align:center;">
              <p style="margin:0;color:#9ca3af;font-size:12px;">
                &copy; 2026 EventHub. Todos os direitos reservados.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;
}

/**
 * Gera a versão em texto simples do email (fallback).
 */
function buildInviteText(string $email, string $eventName, string $link): string
{
    return <<<TEXT
Foi convidado para o evento: {$eventName}

Para definir a sua password e aceder à sua área de convidado, aceda ao link abaixo.
O link é válido durante 7 dias e apenas pode ser utilizado uma vez.

{$link}

Se não reconhece este convite, pode ignorar este email.

-- EventHub
TEXT;
}

/**
 * HTML do email de boas-vindas com credenciais para novos convidados.
 */
function buildWelcomeHtml(
    string $email,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): string {
    $sName      = htmlspecialchars($guestName,     ENT_QUOTES, 'UTF-8');
    $sEvent     = htmlspecialchars($eventName,     ENT_QUOTES, 'UTF-8');
    $sDate      = htmlspecialchars($eventDate,     ENT_QUOTES, 'UTF-8');
    $sLocal     = htmlspecialchars($eventLocal ?: '—', ENT_QUOTES, 'UTF-8');
    $sEmail     = htmlspecialchars($email,         ENT_QUOTES, 'UTF-8');
    $sPass      = htmlspecialchars($plainPassword, ENT_QUOTES, 'UTF-8');
    $sLoginUrl  = htmlspecialchars($loginUrl,      ENT_QUOTES, 'UTF-8');
    $sRsvpUrl   = htmlspecialchars($rsvpUrl,       ENT_QUOTES, 'UTF-8');

    $magicBlock = '';
    if ($magicToken !== '') {
        $magicUrl   = htmlspecialchars(APP_BASE_URL . '/guest_access.php?token=' . urlencode($magicToken), ENT_QUOTES, 'UTF-8');
        $magicBlock = <<<MAGIC

            <!-- Magic link primary CTA -->
            <table cellpadding="0" cellspacing="0" style="margin:0 auto 8px;width:100%;">
              <tr>
                <td style="background:#16a34a;border-radius:8px;text-align:center;">
                  <a href="{$magicUrl}"
                     style="display:inline-block;padding:16px 32px;color:#fff;font-size:16px;font-weight:bold;text-decoration:none;">
                    Entrar Automaticamente →
                  </a>
                </td>
              </tr>
            </table>
            <p style="margin:0 0 24px;text-align:center;color:#6b7280;font-size:12px;">
              Um clique — sem precisar de escrever a password. Válido durante 7 dias.
            </p>

            <p style="margin:0 0 12px;color:#374151;font-size:13px;font-weight:600;">
              Ou aceda manualmente com os seus dados:
            </p>
MAGIC;
    }

    return <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Convite EventHub</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:30px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0"
             style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.1);">
        <tr>
          <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);padding:32px;text-align:center;">
            <h1 style="margin:0;color:#fff;font-size:24px;letter-spacing:1px;">EventHub</h1>
          </td>
        </tr>
        <tr>
          <td style="padding:40px 40px 24px;">
            <h2 style="margin:0 0 16px;color:#1f2937;font-size:20px;">Olá, {$sName}! 🎉</h2>
            <p style="margin:0 0 12px;color:#374151;line-height:1.6;">
              Foi convidado para o evento <strong>{$sEvent}</strong>.
            </p>

            <!-- Event details -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#f8fafc;border-radius:8px;padding:16px;margin:0 0 24px;">
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>📅 Data:</strong> {$sDate}
                </td>
              </tr>
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>📍 Local:</strong> {$sLocal}
                </td>
              </tr>
            </table>
{$magicBlock}
            <!-- Credentials box -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:16px;margin:0 0 24px;">
              <tr>
                <td style="padding:4px 0;color:#1e40af;font-size:14px;font-weight:700;">
                  🔑 Os seus dados de acesso:
                </td>
              </tr>
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>Email:</strong> {$sEmail}
                </td>
              </tr>
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>Password temporária:</strong>
                  <span style="font-family:monospace;background:#e0e7ff;padding:2px 8px;border-radius:4px;font-size:15px;">{$sPass}</span>
                </td>
              </tr>
            </table>

            <!-- Secondary CTA -->
            <table cellpadding="0" cellspacing="0" style="margin:0 0 16px;">
              <tr>
                <td style="background:#0ea5e9;border-radius:6px;text-align:center;">
                  <a href="{$sRsvpUrl}"
                     style="display:inline-block;padding:12px 24px;color:#fff;font-size:14px;font-weight:bold;text-decoration:none;">
                    Confirmar Presença
                  </a>
                </td>
              </tr>
            </table>

            <p style="margin:16px 0 0;color:#9ca3af;font-size:12px;line-height:1.5;">
              Altere a sua password após o primeiro acesso. Este email foi enviado para {$sEmail}.
            </p>
          </td>
        </tr>
        <tr>
          <td style="background:#f9fafb;padding:20px 40px;text-align:center;">
            <p style="margin:0;color:#9ca3af;font-size:12px;">&copy; 2026 EventHub. Todos os direitos reservados.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}

function buildWelcomeText(
    string $email,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): string {
    $magicLine = '';
    if ($magicToken !== '') {
        $magicUrl  = APP_BASE_URL . '/guest_access.php?token=' . urlencode($magicToken);
        $magicLine = "Entrar automaticamente (um clique, sem password):\n{$magicUrl}\n\nOu aceda manualmente:\n";
    }
    return <<<TEXT
Olá, {$guestName}!

Foi convidado para o evento: {$eventName}
Data: {$eventDate}
Local: {$eventLocal}

{$magicLine}Os seus dados de acesso:
  Email: {$email}
  Password: {$plainPassword}

Aceda manualmente: {$loginUrl}
Confirmar presença: {$rsvpUrl}

Altere a sua password após o primeiro acesso.

-- EventHub
TEXT;
}

/**
 * HTML do email de lembrete para convidados já registados.
 */
function buildReminderHtml(
    string $email,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): string {
    $sName     = htmlspecialchars($guestName,     ENT_QUOTES, 'UTF-8');
    $sEvent    = htmlspecialchars($eventName,     ENT_QUOTES, 'UTF-8');
    $sDate     = htmlspecialchars($eventDate,     ENT_QUOTES, 'UTF-8');
    $sLocal    = htmlspecialchars($eventLocal ?: '—', ENT_QUOTES, 'UTF-8');
    $sLoginUrl = htmlspecialchars($loginUrl,      ENT_QUOTES, 'UTF-8');
    $sRsvpUrl  = htmlspecialchars($rsvpUrl,       ENT_QUOTES, 'UTF-8');

    $primaryBlock = '';
    if ($magicToken !== '') {
        $magicUrl     = htmlspecialchars(APP_BASE_URL . '/guest_access.php?token=' . urlencode($magicToken), ENT_QUOTES, 'UTF-8');
        $primaryBlock = <<<MAGIC
            <!-- Magic link primary CTA -->
            <table cellpadding="0" cellspacing="0" style="margin:0 auto 8px;width:100%;">
              <tr>
                <td style="background:#16a34a;border-radius:8px;text-align:center;">
                  <a href="{$magicUrl}"
                     style="display:inline-block;padding:16px 32px;color:#fff;font-size:16px;font-weight:bold;text-decoration:none;">
                    Entrar Automaticamente →
                  </a>
                </td>
              </tr>
            </table>
            <p style="margin:0 0 24px;text-align:center;color:#6b7280;font-size:12px;">
              Um clique — sem precisar de escrever a password. Válido durante 7 dias.
            </p>
MAGIC;
    } else {
        $primaryBlock = <<<LOGIN
            <table cellpadding="0" cellspacing="0" style="margin:0 0 16px;">
              <tr>
                <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);border-radius:6px;text-align:center;">
                  <a href="{$sLoginUrl}"
                     style="display:inline-block;padding:14px 28px;color:#fff;font-size:15px;font-weight:bold;text-decoration:none;">
                    Entrar no EventHub
                  </a>
                </td>
              </tr>
            </table>
LOGIN;
    }

    return <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Convite EventHub</title></head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:30px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0"
             style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.1);">
        <tr>
          <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);padding:32px;text-align:center;">
            <h1 style="margin:0;color:#fff;font-size:24px;letter-spacing:1px;">EventHub</h1>
          </td>
        </tr>
        <tr>
          <td style="padding:40px 40px 24px;">
            <h2 style="margin:0 0 16px;color:#1f2937;font-size:20px;">Olá, {$sName}!</h2>
            <p style="margin:0 0 12px;color:#374151;line-height:1.6;">
              Foi adicionado como convidado ao evento <strong>{$sEvent}</strong>.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#f8fafc;border-radius:8px;padding:16px;margin:0 0 24px;">
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>📅 Data:</strong> {$sDate}
                </td>
              </tr>
              <tr>
                <td style="padding:6px 0;color:#374151;font-size:14px;">
                  <strong>📍 Local:</strong> {$sLocal}
                </td>
              </tr>
            </table>
{$primaryBlock}
            <table cellpadding="0" cellspacing="0" style="margin:0 0 16px;">
              <tr>
                <td style="background:#0ea5e9;border-radius:6px;text-align:center;">
                  <a href="{$sRsvpUrl}"
                     style="display:inline-block;padding:12px 24px;color:#fff;font-size:14px;font-weight:bold;text-decoration:none;">
                    Confirmar Presença
                  </a>
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="background:#f9fafb;padding:20px 40px;text-align:center;">
            <p style="margin:0;color:#9ca3af;font-size:12px;">&copy; 2026 EventHub. Todos os direitos reservados.</p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}

/**
 * Sends the client dashboard access email (portal invitation).
 */
function sendClientDashboardEmail(
    string $toEmail,
    string $clienteName,
    string $organizerName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword
): bool {
    $mail = new PHPMailer(true);
    try {
        _configurarMailer($mail);
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

        $mail->isHTML(true);
        $mail->Subject = 'Acesso ao seu Portal de Evento — EventHub';
        $mail->Body    = buildClientDashboardHtml($toEmail, $clienteName, $organizerName, $eventName, $eventDate, $eventLocal, $plainPassword);
        $mail->AltBody = buildClientDashboardText($toEmail, $clienteName, $organizerName, $eventName, $eventDate, $eventLocal, $plainPassword);

        $mail->send();
        return true;
    } catch (MailerException $e) {
        error_log('[EventHub] Falha no envio de email para ' . $toEmail . ': ' . $mail->ErrorInfo);
        return false;
    }
}

function buildClientDashboardHtml(
    string $email,
    string $clienteName,
    string $organizerName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword
): string {
    $sName      = htmlspecialchars($clienteName,   ENT_QUOTES, 'UTF-8');
    $sOrg       = htmlspecialchars($organizerName, ENT_QUOTES, 'UTF-8');
    $sEvent     = htmlspecialchars($eventName,     ENT_QUOTES, 'UTF-8');
    $sDate      = htmlspecialchars($eventDate,     ENT_QUOTES, 'UTF-8');
    $sLocal     = htmlspecialchars($eventLocal ?: '—', ENT_QUOTES, 'UTF-8');
    $sEmail     = htmlspecialchars($email,         ENT_QUOTES, 'UTF-8');
    $sPass      = htmlspecialchars($plainPassword, ENT_QUOTES, 'UTF-8');
    $loginUrl   = htmlspecialchars(APP_BASE_URL . '/login.php', ENT_QUOTES, 'UTF-8');
    $portalUrl  = htmlspecialchars(APP_BASE_URL . '/cliente-dashboard.php', ENT_QUOTES, 'UTF-8');

    return <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Acesso ao Portal — EventHub</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.10);">

        <!-- Header gradient -->
        <tr>
          <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);padding:40px 48px;text-align:center;">
            <div style="font-size:28px;font-weight:900;color:#fff;letter-spacing:-0.5px;">✦ EventHub</div>
            <div style="font-size:15px;color:rgba(255,255,255,0.85);margin-top:6px;font-weight:500;">Portal do Cliente</div>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding:40px 48px;">
            <h2 style="margin:0 0 8px;color:#0f172a;font-size:22px;font-weight:800;letter-spacing:-0.3px;">Olá, {$sName}!</h2>
            <p style="margin:0 0 24px;color:#64748b;font-size:15px;line-height:1.6;">
              O seu organizador, <strong style="color:#0f172a">{$sOrg}</strong>, criou um portal personalizado para si onde pode acompanhar o seu evento em tempo real.
            </p>

            <!-- Event details card -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0fdfa;border:1.5px solid #99f6e4;border-radius:14px;padding:20px;margin:0 0 28px;">
              <tr><td style="padding:0 20px 0;">
                <p style="margin:0 0 12px;color:#0f766e;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;">O Seu Evento</p>
                <p style="margin:0 0 8px;color:#0f172a;font-size:18px;font-weight:800;">{$sEvent}</p>
                <p style="margin:0 0 6px;color:#0f172a;font-size:14px;">📅 {$sDate}</p>
                <p style="margin:0;color:#0f172a;font-size:14px;">📍 {$sLocal}</p>
              </td></tr>
            </table>

            <!-- What they can do -->
            <p style="margin:0 0 14px;color:#0f172a;font-size:14px;font-weight:700;">No seu portal pode:</p>
            <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 28px;">
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">👥 &nbsp;Convidar e gerir os seus convidados</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">🎁 &nbsp;Acompanhar a lista de presentes</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">📱 &nbsp;Descarregar QR Codes dos convidados</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">🪑 &nbsp;Ver a planta visual das mesas</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">👁️ &nbsp;Pré-visualizar a página do evento</td></tr>
            </table>

            <!-- Credentials -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:14px;padding:20px;margin:0 0 28px;">
              <tr><td style="padding:0 20px 12px;">
                <p style="margin:0;color:#1e40af;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;">As suas credenciais</p>
              </td></tr>
              <tr><td style="padding:0 20px 8px;color:#374151;font-size:14px;">
                <strong>Email:</strong> {$sEmail}
              </td></tr>
              <tr><td style="padding:0 20px;color:#374151;font-size:14px;">
                <strong>Password temporária:</strong>
                <span style="font-family:monospace;background:#dbeafe;padding:3px 10px;border-radius:6px;font-size:15px;font-weight:700;">{$sPass}</span>
              </td></tr>
            </table>

            <!-- CTA -->
            <table cellpadding="0" cellspacing="0" style="width:100%;margin:0 0 16px;">
              <tr>
                <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);border-radius:12px;text-align:center;">
                  <a href="{$portalUrl}" style="display:block;padding:16px 32px;color:#fff;font-size:16px;font-weight:800;text-decoration:none;letter-spacing:-0.2px;">
                    Entrar no Portal do Evento →
                  </a>
                </td>
              </tr>
            </table>

            <p style="margin:0 0 4px;color:#94a3b8;font-size:12px;text-align:center;">
              Ou aceda manualmente em <a href="{$loginUrl}" style="color:#0d9488">{$loginUrl}</a>
            </p>

            <p style="margin:24px 0 0;color:#94a3b8;font-size:12px;line-height:1.6;">
              Por segurança, altere a sua password após o primeiro acesso. Este email foi enviado para {$sEmail} por ser o cliente registado no EventHub.
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 48px;text-align:center;">
            <p style="margin:0;color:#94a3b8;font-size:12px;">&copy; 2026 EventHub &mdash; Plataforma de Gestão de Eventos. Todos os direitos reservados.</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}

function buildClientDashboardText(
    string $email,
    string $clienteName,
    string $organizerName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $plainPassword
): string {
    $loginUrl = APP_BASE_URL . '/login.php';
    return <<<TEXT
Olá, {$clienteName}!

O seu organizador {$organizerName} criou um portal de evento para si no EventHub.

Evento: {$eventName}
Data: {$eventDate}
Local: {$eventLocal}

As suas credenciais:
  Email: {$email}
  Password temporária: {$plainPassword}

Aceder ao portal: {$loginUrl}

Altere a sua password após o primeiro acesso.

-- EventHub
TEXT;
}

function sendStaffDashboardEmail(
    string $toEmail,
    string $staffName,
    string $organizerName,
    string $plainPassword
): bool {
    $mail = new PHPMailer(true);
    try {
        _configurarMailer($mail);
        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail);
        $mail->addReplyTo(MAIL_USERNAME, MAIL_FROM_NAME);

        $mail->isHTML(true);
        $mail->Subject = 'Acesso ao seu Portal de Staff — EventHub';
        $mail->Body    = buildStaffDashboardHtml($toEmail, $staffName, $organizerName, $plainPassword);
        $mail->AltBody = buildStaffDashboardText($toEmail, $staffName, $organizerName, $plainPassword);

        $mail->send();
        return true;
    } catch (MailerException $e) {
        error_log('[EventHub] Falha no envio de email para ' . $toEmail . ': ' . $mail->ErrorInfo);
        return false;
    }
}

function buildStaffDashboardHtml(
    string $email,
    string $staffName,
    string $organizerName,
    string $plainPassword
): string {
    $sName     = htmlspecialchars($staffName,      ENT_QUOTES, 'UTF-8');
    $sOrg      = htmlspecialchars($organizerName,  ENT_QUOTES, 'UTF-8');
    $sEmail    = htmlspecialchars($email,          ENT_QUOTES, 'UTF-8');
    $sPass     = htmlspecialchars($plainPassword,  ENT_QUOTES, 'UTF-8');
    $loginUrl  = htmlspecialchars(APP_BASE_URL . '/login.php', ENT_QUOTES, 'UTF-8');
    $portalUrl = htmlspecialchars(APP_BASE_URL . '/staff-dashboard.php', ENT_QUOTES, 'UTF-8');

    return <<<HTML
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Acesso ao Portal — EventHub</title></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.10);">

        <!-- Header gradient -->
        <tr>
          <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);padding:40px 48px;text-align:center;">
            <div style="font-size:28px;font-weight:900;color:#fff;letter-spacing:-0.5px;">✦ EventHub</div>
            <div style="font-size:15px;color:rgba(255,255,255,0.85);margin-top:6px;font-weight:500;">Portal do Staff</div>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding:40px 48px;">
            <h2 style="margin:0 0 8px;color:#0f172a;font-size:22px;font-weight:800;letter-spacing:-0.3px;">Olá, {$sName}!</h2>
            <p style="margin:0 0 24px;color:#64748b;font-size:15px;line-height:1.6;">
              O organizador <strong style="color:#0f172a">{$sOrg}</strong> deu-lhe acesso ao portal de staff, onde pode ver as tarefas e eventos atribuídos.
            </p>

            <!-- What they can do -->
            <p style="margin:0 0 14px;color:#0f172a;font-size:14px;font-weight:700;">No seu portal pode:</p>
            <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 28px;">
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">✅ &nbsp;Ver e atualizar o estado das suas tarefas</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">📅 &nbsp;Consultar os eventos em que está a colaborar</td></tr>
              <tr><td style="padding:6px 0;color:#374151;font-size:14px;">👤 &nbsp;Gerir o seu perfil e palavra-passe</td></tr>
            </table>

            <!-- Credentials -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:14px;padding:20px;margin:0 0 28px;">
              <tr><td style="padding:0 20px 12px;">
                <p style="margin:0;color:#1e40af;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;">As suas credenciais</p>
              </td></tr>
              <tr><td style="padding:0 20px 8px;color:#374151;font-size:14px;">
                <strong>Email:</strong> {$sEmail}
              </td></tr>
              <tr><td style="padding:0 20px;color:#374151;font-size:14px;">
                <strong>Password temporária:</strong>
                <span style="font-family:monospace;background:#dbeafe;padding:3px 10px;border-radius:6px;font-size:15px;font-weight:700;">{$sPass}</span>
              </td></tr>
            </table>

            <!-- CTA -->
            <table cellpadding="0" cellspacing="0" style="width:100%;margin:0 0 16px;">
              <tr>
                <td style="background:linear-gradient(135deg,#0d9488,#14b8a6);border-radius:12px;text-align:center;">
                  <a href="{$portalUrl}" style="display:block;padding:16px 32px;color:#fff;font-size:16px;font-weight:800;text-decoration:none;letter-spacing:-0.2px;">
                    Entrar no Portal do Staff →
                  </a>
                </td>
              </tr>
            </table>

            <p style="margin:0 0 4px;color:#94a3b8;font-size:12px;text-align:center;">
              Ou aceda manualmente em <a href="{$loginUrl}" style="color:#0d9488">{$loginUrl}</a>
            </p>

            <p style="margin:24px 0 0;color:#94a3b8;font-size:12px;line-height:1.6;">
              Por segurança, altere a sua password após o primeiro acesso. Este email foi enviado para {$sEmail} por ser staff registado no EventHub.
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f8fafc;border-top:1px solid #e2e8f0;padding:20px 48px;text-align:center;">
            <p style="margin:0;color:#94a3b8;font-size:12px;">&copy; 2026 EventHub &mdash; Plataforma de Gestão de Eventos. Todos os direitos reservados.</p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}

function buildStaffDashboardText(
    string $email,
    string $staffName,
    string $organizerName,
    string $plainPassword
): string {
    $loginUrl = APP_BASE_URL . '/login.php';
    return <<<TEXT
Olá, {$staffName}!

O organizador {$organizerName} deu-lhe acesso ao portal de staff no EventHub.

As suas credenciais:
  Email: {$email}
  Password temporária: {$plainPassword}

Aceder ao portal: {$loginUrl}

Altere a sua password após o primeiro acesso.

-- EventHub
TEXT;
}

function buildReminderText(
    string $email,
    string $guestName,
    string $eventName,
    string $eventDate,
    string $eventLocal,
    string $loginUrl,
    string $rsvpUrl,
    string $magicToken = ''
): string {
    $magicLine = '';
    if ($magicToken !== '') {
        $magicUrl  = APP_BASE_URL . '/guest_access.php?token=' . urlencode($magicToken);
        $magicLine = "Entrar automaticamente (um clique, sem password):\n{$magicUrl}\n\n";
    }
    return <<<TEXT
Olá, {$guestName}!

Foi adicionado como convidado ao evento: {$eventName}
Data: {$eventDate}
Local: {$eventLocal}

{$magicLine}Aceda à sua área: {$loginUrl}
Confirmar presença: {$rsvpUrl}

-- EventHub
TEXT;
}
