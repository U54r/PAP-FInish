<?php
// guest.php – Página do convidado + modo de pré-visualização para organizadores
require_once __DIR__ . '/auth.php';
requireLogin();

$user     = getCurrentUser();
$pdo      = getDB();
$role     = $_SESSION['role'] ?? '';
$idEvento = (int) ($_GET['id_evento'] ?? 0);
$isOrganizerPreview = false;

if (in_array($role, ['organizador', 'administrador']) && $idEvento) {
    // ── Modo pré-visualização (organizador) ──────────────────────────────────
    $stmt = $pdo->prepare(
        'SELECT * FROM evento WHERE id_evento = ? AND id_organizador = ?'
    );
    $stmt->execute([$idEvento, $_SESSION['id_utilizador']]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        http_response_code(403);
        die('Evento não encontrado ou sem permissão.');
    }

    $isOrganizerPreview = true;
    $editorBackUrl      = 'dashboard.php';
    $editorBackLabel    = '← Dashboard';
    $editorBannerLabel  = 'Pré-visualização';
    $guestName          = 'Nome do Convidado';
    $guestQrCode        = null;

} elseif (in_array($role, ['organizador', 'administrador']) && !$idEvento) {
    // Organizador sem id_evento → redireciona para o dashboard
    header('Location: dashboard.php');
    exit;

} elseif ($role === 'cliente') {
    // ── Modo cliente: vê a página de convite do seu próprio evento ──────────
    if ($idEvento) {
        $stmt = $pdo->prepare('SELECT * FROM evento WHERE id_evento = ? AND id_cliente = ?');
        $stmt->execute([$idEvento, $_SESSION['id_utilizador']]);
    } else {
        $stmt = $pdo->prepare('SELECT * FROM evento WHERE id_cliente = ? ORDER BY data ASC LIMIT 1');
        $stmt->execute([$_SESSION['id_utilizador']]);
    }
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        http_response_code(404);
        die('<!DOCTYPE html><html lang="pt-PT"><head><meta charset="UTF-8">
        <title>Sem convite</title>
        <style>
            body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;
                 min-height:100vh;background:#faf7f2;color:#2c2416;margin:0}
            .box{text-align:center;padding:3rem}
            h2{font-size:1.5rem;margin-bottom:1rem}
            p{color:#8a7560;margin-bottom:2rem}
            a{display:inline-block;background:#c9a96e;color:#1a1209;padding:.7rem 1.8rem;
              border-radius:6px;text-decoration:none;font-weight:600;font-size:.9rem}
        </style></head>
        <body><div class="box">
            <h2>Convite não encontrado</h2>
            <p>Não foi encontrado nenhum evento associado à sua conta.</p>
            <a href="cliente-dashboard.php">Voltar ao Painel</a>
        </div></body></html>');
    }

    $isOrganizerPreview = true;
    $editorBackUrl      = 'cliente-dashboard.php';
    $editorBackLabel    = '← Painel';
    $editorBannerLabel  = 'A editar o seu convite';
    $guestName   = $user['nome'] ?? '';
    $guestQrCode = null;

} else {
    // ── Modo convidado ───────────────────────────────────────────────────────
    $stmt = $pdo->prepare("
        SELECT e.*, eg.id_guest, eg.qr_code AS guest_qr_code
        FROM event_guest eg
        JOIN guest g  ON g.id_guest  = eg.id_guest
        JOIN evento e ON e.id_evento = eg.id_evento
        WHERE g.email = ?
        ORDER BY e.data ASC
        LIMIT 1
    ");
    $stmt->execute([$user['email'] ?? '']);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        http_response_code(404);
        die('<!DOCTYPE html><html lang="pt-PT"><head><meta charset="UTF-8">
        <title>Sem convite</title>
        <style>
            body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;
                 min-height:100vh;background:#faf7f2;color:#2c2416;margin:0}
            .box{text-align:center;padding:3rem}
            h2{font-size:1.5rem;margin-bottom:1rem}
            p{color:#8a7560;margin-bottom:2rem}
            a{display:inline-block;background:#c9a96e;color:#1a1209;padding:.7rem 1.8rem;
              border-radius:6px;text-decoration:none;font-weight:600;font-size:.9rem}
        </style></head>
        <body><div class="box">
            <h2>Convite não encontrado</h2>
            <p>Não foi encontrado nenhum evento associado à sua conta.</p>
            <a href="login.php">Voltar ao Login</a>
        </div></body></html>');
    }

    $guestName   = $user['nome'] ?? '';
    $guestQrCode = $event['guest_qr_code'] ?? null;
}

// ── Carregar definições da página ────────────────────────────────────────────
$stmtSet = $pdo->prepare('SELECT * FROM event_page_settings WHERE id_evento = ?');
$stmtSet->execute([$event['id_evento']]);
$settings = $stmtSet->fetch(PDO::FETCH_ASSOC);

if (!$settings) {
    $settings = [
        'layout_template'       => 'classic',
        'bg_color'              => '#faf7f2',
        'primary_color'         => '#c9a96e',
        'text_color'            => '#2c2416',
        'dresscode_title'       => 'Formal',
        'dresscode_suggested'   => 'Fato (azul, cinza, preto), vestido longo ou midi, sapatos clássicos, acessórios discretos e elegantes.',
        'dresscode_avoid'       => 'Jeans, ténis, t-shirts casuais, branco ou bege (reservado para a noiva), padrões chamativos.',
        'dresscode_palette'     => 'Tons de azul marinho, verde esmeralda, vinho, dourado e neutros escuros.',
        'dresscode_image1'      => null,
        'dresscode_image2'      => null,
        'dresscode_image3'      => null,
        'location_name'         => $event['local'] ?? '',
        'location_address'      => '',
        'location_map_url'      => '',
        'location_parking_info' => '',
        'ceremony_time'         => $event['hora'] ?? null,
        'reception_time'        => null,
    ];
}

// ── Helpers de cor ───────────────────────────────────────────────────────────
function lightenColor(string $hex, int $percent): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    [$r,$g,$b] = [hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2))];
    return sprintf('#%02x%02x%02x',
        min(255,(int)($r+(255-$r)*($percent/100))),
        min(255,(int)($g+(255-$g)*($percent/100))),
        min(255,(int)($b+(255-$b)*($percent/100))));
}

function darkenColor(string $hex, int $percent): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    [$r,$g,$b] = [hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2))];
    return sprintf('#%02x%02x%02x',
        max(0,(int)($r*(1-$percent/100))),
        max(0,(int)($g*(1-$percent/100))),
        max(0,(int)($b*(1-$percent/100))));
}

// ── Carregar layout ──────────────────────────────────────────────────────────
$allowedLayouts = ['classic', 'modern', 'elegant', 'rustic'];
$layoutName     = in_array($settings['layout_template'], $allowedLayouts)
    ? $settings['layout_template'] : 'classic';
$layoutFile     = __DIR__ . '/layouts/' . $layoutName . '.php';
if (!file_exists($layoutFile)) $layoutFile = __DIR__ . '/layouts/classic.php';

// Painel do organizador antes do layout
if ($isOrganizerPreview) {
    include __DIR__ . '/layouts/organizer_panel.php';
}

include $layoutFile;
