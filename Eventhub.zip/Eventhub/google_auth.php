<?php
/**
 * google_auth.php
 * 
 * Google OAuth 2.0 Handler Functions
 * Uses raw HTTP calls (no Composer required)
 */

require_once __DIR__ . '/config_google.php';

/**
 * Exchange authorization code for access token
 * 
 * @param string $code The authorization code from Google
 * @return array|false Token response or false on failure
 */
function exchangeCodeForToken(string $code): array|false {
    $params = [
        'client_id'     => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'code'          => $code,
        'grant_type'    => 'authorization_code',
        'redirect_uri'  => GOOGLE_REDIRECT_URI,
    ];

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($params),
            'timeout' => 10,
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents(GOOGLE_TOKEN_URL, false, $context);

    if ($response === false) {
        error_log('[EventHub Google OAuth] Token exchange failed for code: ' . substr($code, 0, 10));
        return false;
    }

    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('[EventHub Google OAuth] Invalid JSON in token response: ' . json_last_error_msg());
        return false;
    }

    if (isset($data['error'])) {
        error_log('[EventHub Google OAuth] Token error: ' . ($data['error_description'] ?? $data['error']));
        return false;
    }

    return $data;
}

/**
 * Get user information from Google using access token
 * 
 * @param string $accessToken The Google access token
 * @return array|false User info (id, email, name, picture) or false on failure
 */
function getGoogleUserInfo(string $accessToken): array|false {
    $url = GOOGLE_USER_INFO_URL . '?access_token=' . urlencode($accessToken);

    $options = [
        'http' => [
            'method'  => 'GET',
            'header'  => 'User-Agent: EventHub/1.0',
            'timeout' => 10,
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        error_log('[EventHub Google OAuth] User info request failed');
        return false;
    }

    $user = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('[EventHub Google OAuth] Invalid JSON in user info response: ' . json_last_error_msg());
        return false;
    }

    if (isset($user['error'])) {
        error_log('[EventHub Google OAuth] User info error: ' . $user['error']['message']);
        return false;
    }

    return $user;
}

/**
 * Validate state parameter for CSRF protection
 * 
 * @param string $state The state parameter from Google callback
 * @return bool True if state is valid
 */
function validateState(string $state): bool {
    if (!isset($_SESSION['oauth_state'])) {
        return false;
    }
    
    $valid = hash_equals($_SESSION['oauth_state'], $state);
    unset($_SESSION['oauth_state']);
    return $valid;
}

/**
 * Generate and store a state parameter for CSRF protection
 * 
 * @return string The generated state
 */
function generateState(): string {
    $state = bin2hex(random_bytes(32));
    $_SESSION['oauth_state'] = $state;
    return $state;
}
