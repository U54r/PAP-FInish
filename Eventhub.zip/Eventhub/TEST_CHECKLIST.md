# EventHub — Testing Checklist

Before the final presentation, verify that all features work end-to-end. Use this checklist to systematically test each component.

---

## 1. Email Invitation Testing

### Prerequisites
- XAMPP running (Apache + MySQL)
- PHPMailer configured (see `email_helper.php`)
- **For local testing**: MailHog running on `127.0.0.1:1025`

### 1.1 Setup MailHog (Local Testing)

1. Download MailHog: https://github.com/mailhog/MailHog/releases
2. Extract and run the executable:
   ```bash
   ./MailHog
   ```
   - SMTP server listens on: `127.0.0.1:1025`
   - Web UI available at: `http://127.0.0.1:8025`

3. Update `email_helper.php` to use MailHog:
   ```php
   define('MAIL_HOST',       '127.0.0.1');
   define('MAIL_PORT',       1025);
   define('MAIL_USERNAME',   '');  // MailHog needs no auth
   define('MAIL_PASSWORD',   '');
   // Keep SMTPAuth = true in the code, MailHog will ignore it
   ```

### 1.2 Test Email Sending

1. Navigate to the **organizer dashboard** (login as `bruno.costa@email.com`, password `org123`)
2. Go to **Convidados** (Guests) section
3. Click **Adicionar Convidado** (Add Guest)
4. Fill in guest details:
   - **Nome**: Test Guest
   - **Email**: `test.guest@local.test`
   - **Telefone**: 961000000
5. Click **Convidar** (Invite) — this sends the email
6. Open MailHog Web UI: http://127.0.0.1:8025
7. **Verify** the email appears in the inbox with:
   - ✓ Subject: "Convite para o evento: [Event Name]"
   - ✓ HTML body is rendered correctly
   - ✓ Setup link contains the correct token
   - ✓ Link format: `http://localhost/Eventhub/guest_setup.php?token=...`

### 1.3 Test Email with Real SMTP (Gmail)

1. Generate a Gmail App Password:
   - Enable 2FA on your Google account
   - Visit: https://myaccount.google.com/apppasswords
   - Create password for "Mail" on "Windows Computer"
   - Copy the 16-character password

2. Update `email_helper.php`:
   ```php
   define('MAIL_HOST',       'smtp.gmail.com');
   define('MAIL_PORT',       587);
   define('MAIL_USERNAME',   'your-email@gmail.com');
   define('MAIL_PASSWORD',   'xxxx xxxx xxxx xxxx');
   define('MAIL_ENCRYPTION', PHPMailer::ENCRYPTION_STARTTLS);
   ```

3. Repeat steps 1.2.1–1.2.5
4. Check the real email inbox at Gmail
5. **Verify** the email arrives within 2 minutes

---

## 2. Guest Setup & Login Testing

### 2.1 Guest Account Creation

1. Open the setup link from the invitation email (or manually visit):
   ```
   http://localhost/Eventhub/guest_setup.php?token=<TOKEN_FROM_EMAIL>
   ```

2. Fill in the guest setup form:
   - **Nome**: Test Guest
   - **Password**: testpass123
   - **Confirmar Password**: testpass123

3. Click **Definir Password e Entrar** (Set Password & Login)

4. **Verify** you are redirected to `guest.php` and see:
   - ✓ Guest name displayed ("Bem-vindo, Test Guest!")
   - ✓ Event details loaded (name, date, location)
   - ✓ Layout renders correctly (classic, modern, elegant, or rustic)
   - ✓ Navigation bar present and smooth scrolling works

---

## 3. RSVP Testing

### Prerequisites
- Guest must be logged in (see section 2.1)

### 3.1 Test RSVP Confirmation

1. On the guest page, scroll to the **RSVP** section
2. Click the button: **Sim, Confirmo!** (Yes, I Confirm!)
3. **Verify** the response:
   - ✓ Status message appears: "Presença confirmada com sucesso!"
   - ✓ Message displays in green (success style)
   - ✓ No page reload (AJAX call)

4. Check the database (phpMyAdmin or Adminer):
   - Table: `event_guest`
   - **Verify**: `estado_rsvp` column changed to `'confirmado'` for this guest

### 3.2 Test RSVP Decline

1. Log out and re-login as a different test guest
2. On the guest page, click: **Não Poderei Ir** (I Cannot Attend)
3. **Verify** the response:
   - ✓ Status message appears: "Resposta registada. Obrigado pela comunicação."
   - ✓ Message displays in neutral style
   - ✓ No page reload

4. Check the database:
   - **Verify**: `estado_rsvp` changed to `'recusado'`

### 3.3 Test RSVP Notification

1. Ensure RSVP was just submitted (section 3.1)
2. Log out
3. Log in as the **organizer** (`bruno.costa@email.com`, password `org123`)
4. Go to **Dashboard**
5. **Verify** a notification appears in the notification popup:
   - ✓ Notification type: "rsvp_confirmado" or "rsvp_recusado"
   - ✓ Message contains: "[Guest Name] confirmou presença no evento [Event Name]"
   - ✓ Notification popups show (check `.notif-attention-popup` styling in dashboard)

---

## 4. Guest Page Customization Testing

### Prerequisites
- Logged in as organizer
- At least one event and guest exist

### 4.1 Test Layout Selection

1. Go to **Dashboard → Configurar Página de Convidado** (Configure Guest Page)
2. Modal opens: "Configurações da Página de Convidado"
3. Select each layout from dropdown:
   - **classic** — elegant serif fonts, warm colors
   - **modern** — clean sans-serif, minimalist
   - **elegant** — sophisticated, refined
   - **rustic** — rustic charm, earthy tones

4. For each layout:
   - Click **Guardar Configurações** (Save)
   - **Verify**: Success message appears
   - Log out, log in as guest, visit `guest.php`
   - **Verify**: Layout matches the selected template

### 4.2 Test Color Customization

1. Open the modal again: **Configurar Página de Convidado**
2. Change colors:
   - **Cor de Fundo** (Background): `#e8d5c4`
   - **Cor Primária** (Primary): `#8b6f47`
   - **Cor de Texto** (Text): `#3d2817`

3. Click **Guardar Configurações**
4. **Verify**: Success message
5. Refresh the guest page (logout/login if needed)
6. **Verify** the guest page uses the new colors throughout

### 4.3 Test Dress Code Customization

1. Open the modal: **Configurar Página de Convidado**
2. Fill in dress code fields:
   - **Título**: "Semi-Formal"
   - **Sugerido**: "Dark blazer, dress pants, formal shoes"
   - **Evitar**: "Jeans, sneakers, t-shirts"
   - **Paleta de Cores**: "Navy, gray, black, gold accents"

3. Upload 3 dress code reference images (JPG/PNG)
4. Click **Guardar Configurações**
5. **Verify**: Success message
6. View the guest page
7. **Verify** the guest page displays:
   - ✓ Dress code section with title "Semi-Formal"
   - ✓ Suggested items displayed
   - ✓ Avoid items displayed
   - ✓ Color palette displayed
   - ✓ 3 images rendered in grid layout
   - ✓ Images load correctly (no 404 errors in browser console)

### 4.4 Test Location Information

1. Open the modal: **Configurar Página de Convidado**
2. Fill in location details:
   - **Nome do Local**: "Quinta da Noiva, Sintra"
   - **Endereço**: "Rua Principal, 123\n2710-000 Sintra, Portugal"
   - **URL do Mapa**: Google Maps embed URL or link
   - **Info de Estacionamento**: "Free parking available at rear entrance"

3. Click **Guardar Configurações**
4. View the guest page
5. **Verify**:
   - ✓ Location section shows "Quinta da Noiva, Sintra"
   - ✓ Address displays correctly (with line breaks)
   - ✓ Map displays in the right column (either embed or placeholder)
   - ✓ Parking info shows below address
   - ✓ "Abrir no Google Maps" link works (opens in new tab)

### 4.5 Test Ceremony & Reception Times

1. Open the modal: **Configurar Página de Convidado**
2. Set times:
   - **Hora da Cerimónia**: 17:00
   - **Hora da Receção**: 19:30

3. Click **Guardar Configurações**
4. View the guest page
5. **Verify**:
   - ✓ Countdown section displays (if event date is in future)
   - ✓ Schedule section shows both ceremony and reception times
   - ✓ Times are formatted correctly (HH:MM)

---

## 5. Organizer Isolation Testing

**Goal**: Verify that one organizer cannot access another organizer's events, staff, or guests.

### Prerequisites
- At least 2 organizers with different events
- Example: `bruno.costa@email.com` (Organizer 1) and `eva.nunes@email.com` (Organizer 2)

### 5.1 Test Event Isolation

1. Log in as **Organizer 1** (`bruno.costa@email.com`)
2. Go to **Dashboard**
3. **Verify**: Only events created by Organizer 1 are visible
4. Log out
5. Log in as **Organizer 2** (`eva.nunes@email.com`)
6. Go to **Dashboard**
7. **Verify**: Only events created by Organizer 2 are visible
8. **Verify**: No events from Organizer 1 appear

### 5.2 Test Guest List Isolation

1. Log in as **Organizer 1**
2. Go to **Convidados** (Guests)
3. **Verify**: Only guests invited to Organizer 1's events are listed
4. Note a guest ID
5. Log out
6. Log in as **Organizer 2**
7. Go to **Convidados** (Guests)
8. **Verify**: The guest from step 4 is NOT visible
9. **Verify**: Only guests for Organizer 2's events appear

### 5.3 Test Staff Isolation

1. Log in as **Organizer 1**
2. Go to **Staff** (if available in dashboard)
3. **Verify**: Only staff assigned by Organizer 1 are listed
4. Note a staff member ID
5. Log out
6. Log in as **Organizer 2**
7. Go to **Staff**
8. **Verify**: The staff member from step 4 is NOT visible

### 5.4 Test API Isolation (api/guest_page_settings.php)

1. Log in as **Organizer 1**
2. Open browser **Developer Tools → Network** tab
3. Call the API manually:
   ```
   GET http://localhost/Eventhub/api/guest_page_settings.php?id_evento=<EVENT_ID_FROM_ORG2>
   ```
   (Replace with an event ID owned by Organizer 2)

4. **Verify**: API returns error 403 (Forbidden):
   ```json
   {"status": "erro", "msg": "Evento não encontrado ou sem permissão"}
   ```

5. **Verify**: Organizer 1 cannot access or modify Organizer 2's events via API

### 5.5 Test RSVP Isolation

1. Ensure guest is assigned to **Organizer 1's event**
2. Log in as that guest and submit RSVP (confirm or decline)
3. Log in as **Organizer 2**
4. Go to **Dashboard**
5. **Verify**: The RSVP notification from Organizer 1's guest does NOT appear
6. **Verify**: Notifications are isolated by organizer

---

## 6. Browser Compatibility & Responsiveness

### Desktop (1920×1080)
- [ ] Guest page layouts render correctly (all 4 templates)
- [ ] Navigation bar is sticky and responsive
- [ ] All sections are readable with good spacing
- [ ] Images load and display at correct size
- [ ] Forms are aligned properly

### Tablet (768×1024)
- [ ] Guest page layouts adapt correctly (mobile-friendly grid)
- [ ] Navigation bar collapses/adjusts if needed
- [ ] RSVP buttons remain clickable
- [ ] Dress code images resize appropriately (e.g., 2-column layout)

### Mobile (375×812)
- [ ] Hero section is readable and centered
- [ ] RSVP buttons stack vertically
- [ ] Countdown grid shows on multiple rows
- [ ] Images are responsive (1 or 2 columns)
- [ ] Text is legible without zoom

### Browsers Tested
- [ ] Chrome/Chromium (Latest)
- [ ] Firefox (Latest)
- [ ] Safari (if available)
- [ ] Edge (if available)

---

## 7. Performance & Security Checks

### 7.1 Performance

- [ ] Guest page loads in < 2 seconds (on 3G throttle)
- [ ] RSVP submission responds in < 500ms
- [ ] No console errors or warnings
- [ ] Images are optimized (< 1MB each)

### 7.2 Security

- [ ] XSS Prevention: Test with guest name `<img src=x onerror=alert('xss')>`
  - **Verify**: Name is escaped in HTML, alert does not fire
- [ ] SQL Injection: Not testable in UI, but code uses prepared statements ✓
- [ ] CSRF: Forms should use token (if implemented)
- [ ] Authentication: Non-logged-in users cannot access `/guest.php`
- [ ] Authorization: Guests cannot access organizer dashboard

---

## 8. Final Checks Before Presentation

- [ ] All database credentials match XAMPP defaults (root, no password)
- [ ] All file paths are relative (no hardcoded `C:\` paths)
- [ ] Email configuration is set to MailHog (local) or verified SMTP (production)
- [ ] No sensitive data in code (API keys, passwords)
- [ ] All error messages are user-friendly (no raw PHP errors)
- [ ] Notification system works reliably
- [ ] Guest page is fully customizable
- [ ] Organizer isolation is enforced everywhere
- [ ] Code follows consistent style (4-space indent, snake_case)
- [ ] No console errors or warnings in browser DevTools

---

## Troubleshooting

### Email not sending
- ✓ Verify MailHog is running (`MailHog` command in terminal)
- ✓ Check SMTP credentials in `email_helper.php`
- ✓ Review PHP error logs: `php_errors.log` in XAMPP folder
- ✓ Ensure `PHPMailer-7.1.1/src/` folder exists with all 3 files

### RSVP not updating
- ✓ Check browser Network tab for 404 or 500 errors
- ✓ Verify `api/rsvp.php` exists at correct path
- ✓ Ensure guest is logged in (session exists)
- ✓ Check database: `event_guest` table has this guest

### Guest page not loading
- ✓ Verify guest is logged in (not redirected to `login.php`)
- ✓ Check guest is in `event_guest` table
- ✓ Verify layout file exists: `layouts/classic.php` (or other template)
- ✓ Check PHP error logs

### Notification not appearing
- ✓ Verify organizer is logged in
- ✓ Check `notificacoes` table: new row should exist
- ✓ Verify notification popup CSS (`.notif-attention-popup`)
- ✓ Check browser console for JavaScript errors

---

## Sign-off

**Tester Name**: ___________________  
**Date**: ___________________  
**All Tests Passed**: ☐ Yes ☐ No  

**Notes / Issues Found**:
```
[Space for notes]
```

---

**EventHub — Ready for Presentation** ✓
