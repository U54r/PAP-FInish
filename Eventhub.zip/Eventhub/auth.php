<?php
// auth.php — Sessões, login e controlo de acessos
// Compatível com gestao_eventos: tabela role separada, id_role como FK

require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ── Verificações de sessão ─────────────────────────── */
function isLoggedIn(): bool {
    return isset($_SESSION['id_utilizador']);
}

function requireLogin(string $redirect = 'login.php'): void {
    if (!isLoggedIn()) {
        header("Location: $redirect");
        exit;
    }
}

function requireRole(array $roles): void {
    requireLogin();
    if (!in_array($_SESSION['role'], $roles)) {
        header('Location: login.php?erro=acesso_negado');
        exit;
    }
}

function getCurrentUser(): array {
    return $_SESSION['user'] ?? [];
}

/* ── Login ──────────────────────────────────────────── */
function login(string $email, string $password): array|false {
    $pdo = getDB();

    // JOIN com tabela role para obter o nome do role
    $stmt = $pdo->prepare("
    SELECT u.*, r.nome_role
    FROM utilizador u
    INNER JOIN role r ON r.id_role = u.id_role
    WHERE u.email = ? AND u.estado_conta = 'ativo'
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Verifica password com SHA2 (igual ao SQL de inserção)
    if ($user && $user['password'] === hash('sha256', $password)) {
        session_regenerate_id(true);
        // Guarda tudo na sessão
        $_SESSION['id_utilizador'] = $user['id_utilizador'];
        $_SESSION['nome']          = $user['nome'];
        $_SESSION['email']         = $user['email'];
        $_SESSION['role']          = $user['nome_role'];   // organizador | staff | convidado
        $_SESSION['id_role']       = $user['id_role'];
        $_SESSION['user']          = $user;
        return $user;
    }

    return false;
}

/* ── Logout ─────────────────────────────────────────── */
function logout(): void {
    session_unset();
    session_destroy();
    header('Location: login.php?msg=saiu');
    exit;
}

/* ── Notificação automática (silenciosa) ────────────── */
function criarNotificacao(int $id_evento, int $id_utilizador, string $mensagem, string $tipo): void {
    try {
        $pdo = getDB();
        $pdo->prepare("
            INSERT INTO notificacoes (id_evento, id_utilizador, mensagem, tipo, data_hora)
            VALUES (?, ?, ?, ?, NOW())
        ")->execute([$id_evento, $id_utilizador, $mensagem, $tipo]);
    } catch (Exception $e) {
        // Silencioso — não deve interromper o fluxo principal
    }
}
