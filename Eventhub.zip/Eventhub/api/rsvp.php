<?php
// api/rsvp.php — Handle guest RSVP responses (confirmado/recusado)
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../response.php';

apiHeaders();
requireLogin();

// Only guests can RSVP
if ($_SESSION['role'] !== 'convidado') {
    jsonErro('Apenas convidados podem responder ao RSVP', 403);
}

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST') {
    jsonErro('Método não permitido', 405);
}

$data = getBody();
$resposta = $data['resposta'] ?? null;

if (!in_array($resposta, ['confirmado', 'recusado'])) {
    jsonErro('Resposta inválida. Use "confirmado" ou "recusado".');
}

$emailSessao = $_SESSION['email'] ?? '';

// event_guest.id_guest links to the guest table (separate from utilizador).
// Look up the guest record by the session email, then find their event.
$stmt = $pdo->prepare("
    SELECT eg.id_guest, eg.id_evento, e.id_organizador, e.nome_evento
    FROM guest g
    JOIN event_guest eg ON eg.id_guest = g.id_guest
    JOIN evento e ON e.id_evento = eg.id_evento
    WHERE g.email = ?
    ORDER BY e.data ASC
    LIMIT 1
");
$stmt->execute([$emailSessao]);
$eventRow = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$eventRow) {
    jsonErro('Nenhum evento associado a este convidado.');
}

$id_guest   = $eventRow['id_guest'];
$id_evento  = $eventRow['id_evento'];
$id_organizador = $eventRow['id_organizador'];
$nome_evento    = $eventRow['nome_evento'];

// Update the RSVP status
$updateStmt = $pdo->prepare("
    UPDATE event_guest
    SET estado_rsvp = ?
    WHERE id_evento = ? AND id_guest = ?
");
$updateStmt->execute([$resposta, $id_evento, $id_guest]);

// Notify the organizer
$guestName = $_SESSION['nome'] ?? 'Convidado';
if ($resposta === 'confirmado') {
    $mensagem = "$guestName confirmou presença no evento $nome_evento.";
    $tipo = 'rsvp_confirmado';
} else {
    $mensagem = "$guestName recusou presença no evento $nome_evento.";
    $tipo = 'rsvp_recusado';
}

criarNotificacao($id_evento, $id_organizador, $mensagem, $tipo);

$statusMsg = $resposta === 'confirmado'
    ? 'Presença confirmada com sucesso!'
    : 'Resposta registada. Obrigado pela comunicação.';

jsonOk([], $statusMsg);
?>
