<?php
// api/guest_page_settings.php
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../response.php';
apiHeaders();
requireRole(['organizador', 'cliente']);

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id_evento = (int)($_GET['id_evento'] ?? 0);

if (!$id_evento) {
    jsonErro('Parâmetro id_evento obrigatório');
}

// Verificar que o evento pertence ao organizador ou ao cliente associado
if ($_SESSION['role'] === 'cliente') {
    $check = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?");
} else {
    $check = $pdo->prepare("SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?");
}
$check->execute([$id_evento, $_SESSION['id_utilizador']]);
if (!$check->fetch()) {
    jsonErro('Evento não encontrado ou sem permissão', 403);
}

$defaults = [
    'id_evento'            => $id_evento,
    'layout_template'      => 'classic',
    'bg_color'             => '#faf7f2',
    'primary_color'        => '#c9a96e',
    'text_color'           => '#2c2416',
    'dresscode_title'      => 'Formal',
    'dresscode_suggested'  => 'Fato (azul, cinza, preto), vestido longo ou midi, sapatos clássicos, acessórios discretos e elegantes.',
    'dresscode_avoid'      => 'Jeans, ténis, t-shirts casuais, branco ou bege (reservado para a noiva), padrões chamativos.',
    'dresscode_palette'    => 'Tons de azul marinho, verde esmeralda, vinho, dourado e neutros escuros.',
    'dresscode_image1'     => null,
    'dresscode_image2'     => null,
    'dresscode_image3'     => null,
    'location_name'        => '',
    'location_address'     => '',
    'location_map_url'     => '',
    'location_parking_info'=> '',
    'ceremony_time'        => null,
    'reception_time'       => null,
];

switch ($method) {
    case 'GET':
        $stmt = $pdo->prepare("SELECT * FROM event_page_settings WHERE id_evento = ?");
        $stmt->execute([$id_evento]);
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);
        jsonOk($settings ?: $defaults);
        break;

    case 'PUT':
        $d = getBody();
        $allowedTemplates = ['classic', 'modern', 'elegant', 'rustic'];
        $template = in_array($d['layout_template'] ?? '', $allowedTemplates)
            ? $d['layout_template'] : 'classic';

        // Validate hex colors to prevent CSS injection via </style><script> payloads
        $safeColor = function(?string $c, string $default): string {
            $c = trim($c ?? '');
            return preg_match('/^#[0-9a-fA-F]{3,6}$/', $c) ? $c : $default;
        };
        $bgColor      = $safeColor($d['bg_color']      ?? null, '#faf7f2');
        $primaryColor = $safeColor($d['primary_color'] ?? null, '#c9a96e');
        $textColor    = $safeColor($d['text_color']    ?? null, '#2c2416');

        $stmt = $pdo->prepare("
            INSERT INTO event_page_settings (
                id_evento, layout_template, bg_color, primary_color, text_color,
                dresscode_title, dresscode_suggested, dresscode_avoid, dresscode_palette,
                dresscode_image1, dresscode_image2, dresscode_image3,
                location_name, location_address, location_map_url, location_parking_info,
                ceremony_time, reception_time
            ) VALUES (
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?
            ) ON DUPLICATE KEY UPDATE
                layout_template      = VALUES(layout_template),
                bg_color             = VALUES(bg_color),
                primary_color        = VALUES(primary_color),
                text_color           = VALUES(text_color),
                dresscode_title      = VALUES(dresscode_title),
                dresscode_suggested  = VALUES(dresscode_suggested),
                dresscode_avoid      = VALUES(dresscode_avoid),
                dresscode_palette    = VALUES(dresscode_palette),
                dresscode_image1     = VALUES(dresscode_image1),
                dresscode_image2     = VALUES(dresscode_image2),
                dresscode_image3     = VALUES(dresscode_image3),
                location_name        = VALUES(location_name),
                location_address     = VALUES(location_address),
                location_map_url     = VALUES(location_map_url),
                location_parking_info= VALUES(location_parking_info),
                ceremony_time        = VALUES(ceremony_time),
                reception_time       = VALUES(reception_time)
        ");
        $stmt->execute([
            $id_evento,
            $template,
            $bgColor,
            $primaryColor,
            $textColor,
            $d['dresscode_title']       ?? 'Formal',
            $d['dresscode_suggested']   ?? '',
            $d['dresscode_avoid']       ?? '',
            $d['dresscode_palette']     ?? '',
            $d['dresscode_image1']      ?? null,
            $d['dresscode_image2']      ?? null,
            $d['dresscode_image3']      ?? null,
            $d['location_name']         ?? '',
            $d['location_address']      ?? '',
            $d['location_map_url']      ?? '',
            $d['location_parking_info'] ?? '',
            ($d['ceremony_time']  !== '' ? $d['ceremony_time']  : null)  ?? null,
            ($d['reception_time'] !== '' ? $d['reception_time'] : null)  ?? null,
        ]);
        jsonOk([], 'Configurações da página guardadas');
        break;

    default:
        jsonErro('Método não permitido', 405);
}
