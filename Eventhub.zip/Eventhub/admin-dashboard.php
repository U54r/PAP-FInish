<?php
require_once __DIR__ . '/auth.php';
requireRole(['administrador']);
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Administração — EventHub</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%230d9488'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='central' text-anchor='middle' fill='white' font-size='18' font-weight='700' font-family='sans-serif'%3EEH%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__.'/style.css') ?>">
    <script src="lang.js"></script>
    <style>
        .admin-badge { background:#7c3aed; color:#fff; font-size:10px; font-weight:700; padding:2px 8px; border-radius:99px; margin-left:6px; vertical-align:middle; }
        .td-empty { text-align:center; color:var(--text-muted); padding:24px; font-size:14px; }
        .danger-zone { border:1px solid #fecaca; background:#fef2f2; border-radius:14px; padding:20px; margin-bottom:16px; }
        .danger-zone h3 { color:#b91c1c; font-size:15px; margin-bottom:6px; }
        .danger-zone p { color:#7f1d1d; font-size:13px; margin-bottom:12px; }
        .btn-danger { background:#dc2626; color:#fff; border:none; padding:10px 16px; border-radius:10px; font-weight:600; font-size:13px; cursor:pointer; }
        .btn-danger:hover { background:#b91c1c; }
    </style>
</head>
<body class="dashboard-body">
<div class="dashboard-container">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-logo">
                <i class="ph-fill ph-shield-check"></i><span>Event Hub<span class="admin-badge">ADMIN</span></span>
            </div>
            <nav class="sidebar-nav">
                <a href="#" class="nav-link active" data-section="inicio"><i class="ph ph-gauge"></i> <span>Início</span></a>
                <a href="#" class="nav-link" data-section="utilizadores"><i class="ph ph-users-three"></i> <span>Utilizadores</span></a>
                <a href="#" class="nav-link" data-section="eventos"><i class="ph ph-calendar-check"></i> <span>Eventos</span></a>
                <a href="#" class="nav-link" data-section="basedados"><i class="ph ph-database"></i> <span>Base de Dados</span></a>
            </nav>
        </div>
        <div class="sidebar-footer">
            <a href="#" class="sidebar-user">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=<?= urlencode($user['nome']) ?>"
                     alt="Avatar" class="sidebar-avatar">
                <div class="sidebar-user-info">
                    <span class="sidebar-user-name"><?= htmlspecialchars($user['nome']) ?></span>
                    <span class="sidebar-user-role">Administrador</span>
                </div>
            </a>
            <a href="logout.php" class="logout-link"><i class="ph ph-sign-out"></i> <span>Sair</span></a>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="main-content">
        <header class="dashboard-header">
            <div class="welcome" id="page-title">
                <h1>Painel de Administração</h1>
                <p>Visão global do sistema EventHub.</p>
            </div>
        </header>

        <!-- INÍCIO -->
        <div id="section-inicio" class="page-section active">
            <section class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue"><i class="ph ph-users"></i></div>
                    <div class="stat-info"><h3 id="adm-stat-utilizadores">—</h3><p>Total de Utilizadores</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon orange"><i class="ph ph-calendar-star"></i></div>
                    <div class="stat-info"><h3 id="adm-stat-eventos">—</h3><p>Total de Eventos</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon green"><i class="ph ph-calendar-check"></i></div>
                    <div class="stat-info"><h3 id="adm-stat-eventos-proximos">—</h3><p>Eventos Futuros</p></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon red"><i class="ph ph-user-minus"></i></div>
                    <div class="stat-info"><h3 id="adm-stat-inativos">—</h3><p>Contas Inativas</p></div>
                </div>
            </section>
            <section class="content-section">
                <div class="section-header"><h2>Utilizadores por Tipo</h2></div>
                <div class="table-wrapper">
                    <table>
                        <thead><tr><th>Role</th><th>Total</th></tr></thead>
                        <tbody id="adm-stat-roles-tbody"><tr><td colspan="2" class="td-empty">A carregar...</td></tr></tbody>
                    </table>
                </div>
            </section>
        </div>

        <!-- UTILIZADORES -->
        <div id="section-utilizadores" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">Utilizadores</h2><p class="section-subtitle">Todas as contas do sistema, de todos os roles</p></div>
                <button class="btn-primary-sm" onclick="abrirNovoUtilizadorAdmin()"><i class="ph ph-plus"></i> Novo Utilizador</button>
            </div>
            <div class="filter-bar">
                <button class="adm-role-filter-btn filter-btn active" data-role="">Todos</button>
                <button class="adm-role-filter-btn filter-btn" data-role="administrador">Administradores</button>
                <button class="adm-role-filter-btn filter-btn" data-role="organizador">Organizadores</button>
                <button class="adm-role-filter-btn filter-btn" data-role="staff">Staff</button>
                <button class="adm-role-filter-btn filter-btn" data-role="cliente">Clientes</button>
                <button class="adm-role-filter-btn filter-btn" data-role="convidado">Convidados</button>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table>
                <thead><tr><th>Nome</th><th>Email</th><th>Telefone</th><th>Role</th><th>Estado</th><th>Organizador</th><th>Ações</th></tr></thead>
                <tbody id="adm-utilizadores-tbody"><tr><td colspan="7" class="td-empty">A carregar...</td></tr></tbody>
            </table></div></div>
        </div>

        <!-- EVENTOS -->
        <div id="section-eventos" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">Eventos</h2><p class="section-subtitle">Todos os eventos de todos os organizadores</p></div>
            </div>
            <div class="content-section"><div class="table-wrapper scroll-area"><table>
                <thead><tr><th>Evento</th><th>Organizador</th><th>Data</th><th>Local</th><th>Convidados</th><th>Ações</th></tr></thead>
                <tbody id="adm-eventos-tbody"><tr><td colspan="6" class="td-empty">A carregar...</td></tr></tbody>
            </table></div></div>
        </div>

        <!-- BASE DE DADOS -->
        <div id="section-basedados" class="page-section">
            <div class="section-header mb-24">
                <div><h2 class="section-title">Base de Dados</h2><p class="section-subtitle">Ferramentas de manutenção — apenas a partir do servidor local</p></div>
            </div>
            <div class="danger-zone">
                <h3><i class="ph ph-warning"></i> Diagnóstico da Base de Dados</h3>
                <p>Mostra a estrutura das tabelas e contagem de registos. Operação só de leitura.</p>
                <button class="btn-danger" style="background:#0d9488" onclick="window.open('debug_db.php','_blank')">Abrir Diagnóstico</button>
            </div>
            <div class="danger-zone">
                <h3><i class="ph ph-warning"></i> Recriar Base de Dados</h3>
                <p>Elimina e recria a base de dados <strong>gestao_eventos</strong> a partir do zero, com os dados de demonstração. Esta ação é irreversível.</p>
                <button class="btn-danger" onclick="confirmarAcaoBD('reset_db.php', 'Isto vai ELIMINAR TODOS os dados atuais e recriar a base de dados do zero. Tem a certeza?')">Recriar Base de Dados</button>
            </div>
            <div class="danger-zone">
                <h3><i class="ph ph-warning"></i> Limpar Tabelas</h3>
                <p>Versão alternativa de recriação da base de dados. Esta ação é irreversível.</p>
                <button class="btn-danger" onclick="confirmarAcaoBD('clean_tables.php', 'Isto vai limpar as tabelas da base de dados. Tem a certeza?')">Limpar Tabelas</button>
            </div>
        </div>

    </main>
</div>

<!-- MODAL: Utilizador (Admin) -->
<div class="modal-overlay" id="modal-adm-utilizador">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="ph ph-user-gear"></i> <span id="modal-adm-utilizador-titulo">Novo Utilizador</span></h3>
            <button class="modal-close" onclick="fecharModal('modal-adm-utilizador')"><i class="ph ph-x"></i></button>
        </div>
        <form onsubmit="salvarUtilizadorAdmin(event)">
            <input type="hidden" id="adm-id">
            <div class="modal-body">
                <div class="form-grid-2">
                    <div class="form-group full"><label>Nome Completo *</label><input type="text" id="adm-nome" required placeholder="Nome do utilizador"></div>
                    <div class="form-group full"><label>Email *</label><input type="email" id="adm-email" required placeholder="email@exemplo.com"></div>
                    <div class="form-group"><label>Telefone</label><input type="text" id="adm-telefone" placeholder="+351 9xx xxx xxx"></div>
                    <div class="form-group"><label>Role *</label>
                        <select id="adm-role" required>
                            <option value="administrador">Administrador</option>
                            <option value="organizador">Organizador</option>
                            <option value="staff">Staff</option>
                            <option value="cliente">Cliente</option>
                            <option value="convidado">Convidado</option>
                        </select>
                    </div>
                    <div class="form-group"><label>Estado</label>
                        <select id="adm-estado">
                            <option value="ativo">Ativo</option>
                            <option value="inativo">Inativo</option>
                        </select>
                    </div>
                    <div class="form-group full"><label>Palavra-passe</label><input type="password" id="adm-password" placeholder="Deixar vazio para gerar automática (criação) ou manter atual (edição)"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="fecharModal('modal-adm-utilizador')">Cancelar</button>
                <button type="submit" class="btn-primary-sm">Guardar</button>
            </div>
        </form>
    </div>
</div>

<script src="app.js?v=<?= filemtime(__DIR__.'/app.js') ?>"></script>
<script src="admin.js?v=<?= filemtime(__DIR__.'/admin.js') ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    carregarStatsAdmin();
    carregarUtilizadoresAdmin();
    carregarEventosAdmin();
});

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        goToSection(this.dataset.section);
    });
});

function goToSection(section) {
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector(`.nav-link[data-section="${section}"]`)?.classList.add('active');
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${section}`)?.classList.add('active');

    const actions = {
        inicio:        carregarStatsAdmin,
        utilizadores:  carregarUtilizadoresAdmin,
        eventos:       carregarEventosAdmin,
    };
    if (actions[section]) actions[section]();
}

document.querySelectorAll('.adm-role-filter-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        document.querySelectorAll('.adm-role-filter-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        carregarUtilizadoresAdmin(this.dataset.role);
    });
});
</script>
</body>
</html>
