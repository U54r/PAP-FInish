<?php
// enviar_email_convidado.php — (Re)envia o acesso/convite a um convidado existente
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/email_helper.php';
apiHeaders();
requireRole(['organizador']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonErro('Método não permitido', 405);

$d        = getBody();
$idGuest  = (int)($d['id_guest']  ?? 0);
$idEvento = (int)($d['id_evento'] ?? 0);
if (!$idGuest || !$idEvento) jsonErro('id_guest e id_evento obrigatórios');

$pdo = getDB();

// Confirm this guest belongs to an event owned by this organizer
$stmt = $pdo->prepare("
    SELECT g.id_guest, g.nome, g.email, e.nome_evento, e.data, e.local
    FROM event_guest eg
    JOIN guest g  ON g.id_guest  = eg.id_guest
    JOIN evento e ON e.id_evento = eg.id_evento
    WHERE eg.id_evento = ? AND eg.id_guest = ? AND e.id_organizador = ?
");
$stmt->execute([$idEvento, $idGuest, $_SESSION['id_utilizador']]);
$row = $stmt->fetch();
if (!$row) jsonErro('Convidado não encontrado ou sem permissão', 403);
if (empty($row['email'])) jsonErro('Este convidado não tem email registado.');

$loginUrl   = APP_BASE_URL . '/login.php';
$rsvpUrl    = APP_BASE_URL . '/guest.php';
$eventDate  = date('d/m/Y', strtotime($row['data']));
$eventLocal = $row['local'] ?? '';

// Gera um novo magic-link token para este convite
$token   = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', strtotime('+7 days'));
$pdo->prepare("INSERT INTO guest_invite_tokens (id_evento, email, token, expires, used) VALUES (?, ?, ?, ?, 0)")
    ->execute([$idEvento, $row['email'], $token, $expires]);

$stmtUser = $pdo->prepare("SELECT id_utilizador FROM utilizador WHERE email = ?");
$stmtUser->execute([$row['email']]);
$existente = $stmtUser->fetch();

$plainPassword = null;

if (!$existente) {
    // Convidado sem conta ainda — cria uma e envia password
    $chars         = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $plainPassword = substr(str_shuffle(str_repeat($chars, 3)), 0, 8);
    $hash          = hash('sha256', $plainPassword);

    $stmtRole = $pdo->prepare("SELECT id_role FROM role WHERE nome_role = 'convidado' LIMIT 1");
    $stmtRole->execute();
    $roleId = $stmtRole->fetch()['id_role'] ?? 4;

    $pdo->prepare("
        INSERT INTO utilizador (nome, email, password, id_role, id_organizador, estado_conta)
        VALUES (?, ?, ?, ?, ?, 'ativo')
    ")->execute([$row['nome'], $row['email'], $hash, $roleId, $_SESSION['id_utilizador']]);

    $ok = sendWelcomeEmail(
        $row['email'], $row['nome'], $row['nome_evento'], $eventDate, $eventLocal,
        $plainPassword, $loginUrl, $rsvpUrl, $token
    );
} else {
    // Já tem conta — envia lembrete com magic-link (sem alterar a password)
    $ok = sendReminderEmail(
        $row['email'], $row['nome'], $row['nome_evento'], $eventDate, $eventLocal,
        $loginUrl, $rsvpUrl, $token
    );
}

if ($ok) {
    jsonOk(['password' => $plainPassword], 'Email enviado com sucesso para ' . $row['email']);
} else {
    jsonErro('Falha no envio do email. Verifique as configurações SMTP.');
}
