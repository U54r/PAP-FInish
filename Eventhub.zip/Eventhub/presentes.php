<?php
// presentes.php — CRUD Presentes
// DB: gestao_eventos
// Tables: presente (id_presente, nome_item, categoria, preco_estimado, estado, id_responsavel)
//         evento_presente (id_evento, id_presente) — join table, NO id_evento on presente
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $id_evento  = (int)($_GET['id_evento'] ?? 0);
    $role       = $_SESSION['role'] ?? '';
    $guestSafe  = in_array($role, ['convidado', 'cliente']);

    if ($id_evento) {
        if ($guestSafe) {
            if ($role === 'cliente') {
                $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
                $evChk->execute([$id_evento, $_SESSION['id_utilizador']]);
                if (!$evChk->fetch()) jsonErro('Sem permissão', 403);
            } elseif ($role === 'convidado') {
                $evChk = $pdo->prepare('
                    SELECT 1 FROM event_guest eg
                    JOIN guest g ON g.id_guest = eg.id_guest AND g.email = ?
                    WHERE eg.id_evento = ?
                ');
                $evChk->execute([$_SESSION['email'] ?? '', $id_evento]);
                if (!$evChk->fetch()) jsonErro('Sem permissão', 403);
            }
            // Guests/clients: only available items, no names of who reserved
            $stmt = $pdo->prepare("
                SELECT p.id_presente, p.nome_item, p.categoria, p.preco_estimado,
                       p.estado, e.nome_evento
                FROM evento_presente ep
                JOIN presente  p ON p.id_presente = ep.id_presente
                JOIN evento    e ON e.id_evento   = ep.id_evento
                WHERE ep.id_evento = ?
                ORDER BY p.nome_item
            ");
            $stmt->execute([$id_evento]);
        } else {
            requireRole(['organizador']);
            $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
            $evChk->execute([$id_evento, $_SESSION['id_utilizador']]);
            if (!$evChk->fetch()) jsonErro('Sem permissão', 403);
            $stmt = $pdo->prepare("
                SELECT p.*,
                       u.nome AS nome_responsavel,
                       e.nome_evento
                FROM evento_presente ep
                JOIN presente  p ON p.id_presente = ep.id_presente
                JOIN evento    e ON e.id_evento   = ep.id_evento
                LEFT JOIN utilizador u ON u.id_utilizador = p.id_responsavel
                WHERE ep.id_evento = ?
                ORDER BY p.nome_item
            ");
            $stmt->execute([$id_evento]);
        }
    } else {
        requireRole(['organizador']);
        $stmt = $pdo->prepare("
            SELECT p.*,
                   u.nome AS nome_responsavel,
                   GROUP_CONCAT(e.nome_evento SEPARATOR ', ') AS nome_evento
            FROM presente p
            LEFT JOIN evento_presente ep ON ep.id_presente = p.id_presente
            LEFT JOIN evento          e  ON e.id_evento    = ep.id_evento
            LEFT JOIN utilizador      u  ON u.id_utilizador = p.id_responsavel
            WHERE e.id_organizador = ?
            GROUP BY p.id_presente
            ORDER BY p.nome_item
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
    }
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador', 'cliente']);
    $d = getBody();
    if (empty($d['nome_item']) || empty($d['id_evento'])) {
        jsonErro('Campos obrigatórios: nome_item, id_evento');
    }
    if ($_SESSION['role'] === 'cliente') {
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_cliente = ?');
    } else {
        $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
    }
    $evChk->execute([(int)$d['id_evento'], $_SESSION['id_utilizador']]);
    if (!$evChk->fetch()) jsonErro('Sem permissão', 403);

    // Insert into presente (no id_evento here)
    $pdo->prepare("
        INSERT INTO presente (nome_item, categoria, preco_estimado, estado, id_responsavel)
        VALUES (?, ?, ?, ?, ?)
    ")->execute([
        $d['nome_item'],
        $d['categoria'] ?? '',
        !empty($d['preco_estimado']) ? (float)$d['preco_estimado'] : 0,
        $d['estado'] ?? 'pendente',
        null
    ]);
    $id_presente = (int)$pdo->lastInsertId();

    // Link to event
    $pdo->prepare("INSERT IGNORE INTO evento_presente (id_evento, id_presente) VALUES (?, ?)")
        ->execute([(int)$d['id_evento'], $id_presente]);

    jsonOk(['id_presente' => $id_presente], 'Presente adicionado');
    break;

case 'PUT':
    if (!$id) jsonErro('ID obrigatório');
    $d    = getBody();
    $role = $_SESSION['role'];

    if (in_array($role, ['convidado', 'cliente'])) {
        // Verify the present belongs to an event this user has access to
        if ($role === 'convidado') {
            $accChk = $pdo->prepare('
                SELECT 1 FROM evento_presente ep
                JOIN event_guest eg ON eg.id_evento = ep.id_evento
                JOIN guest g ON g.id_guest = eg.id_guest AND g.email = ?
                WHERE ep.id_presente = ?
            ');
            $accChk->execute([$_SESSION['email'] ?? '', $id]);
        } else {
            $accChk = $pdo->prepare('
                SELECT 1 FROM evento_presente ep
                JOIN evento e ON e.id_evento = ep.id_evento AND e.id_cliente = ?
                WHERE ep.id_presente = ?
            ');
            $accChk->execute([$_SESSION['id_utilizador'], $id]);
        }
        if (!$accChk->fetch()) jsonErro('Sem permissão', 403);
        // Guest/client can only reserve an available item
        $chk = $pdo->prepare("SELECT estado FROM presente WHERE id_presente=?");
        $chk->execute([$id]);
        $p = $chk->fetch();
        if (!$p || $p['estado'] !== 'pendente') {
            jsonErro('Este presente não está disponível para reserva.');
        }
        $pdo->prepare("UPDATE presente SET estado='confirmado', id_responsavel=? WHERE id_presente=?")
            ->execute([$_SESSION['id_utilizador'], $id]);
        jsonOk([], 'Presente reservado com sucesso!');
    } else {
        requireRole(['organizador']);
        $ownerChk = $pdo->prepare('
            SELECT 1 FROM evento_presente ep
            JOIN evento e ON e.id_evento = ep.id_evento
            WHERE ep.id_presente = ? AND e.id_organizador = ?
        ');
        $ownerChk->execute([$id, $_SESSION['id_utilizador']]);
        if (!$ownerChk->fetch()) jsonErro('Sem permissão', 403);
        $pdo->prepare("
            UPDATE presente SET nome_item=?, categoria=?, preco_estimado=?, estado=?, id_responsavel=?
            WHERE id_presente=?
        ")->execute([
            $d['nome_item'],
            $d['categoria'] ?? '',
            !empty($d['preco_estimado']) ? (float)$d['preco_estimado'] : 0,
            $d['estado'] ?? 'pendente',
            !empty($d['id_responsavel']) ? (int)$d['id_responsavel'] : null,
            $id
        ]);
        jsonOk([], 'Presente atualizado');
    }
    break;

case 'DELETE':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $delChk = $pdo->prepare('
        SELECT ep.id_presente FROM evento_presente ep
        JOIN evento e ON e.id_evento = ep.id_evento
        WHERE ep.id_presente = ? AND e.id_organizador = ?
    ');
    $delChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("DELETE FROM evento_presente WHERE id_presente=?")->execute([$id]);
    $pdo->prepare("DELETE FROM presente WHERE id_presente=?")->execute([$id]);
    jsonOk([], 'Presente eliminado');
    break;
}
