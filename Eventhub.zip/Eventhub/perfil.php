<?php
// perfil.php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT u.id_utilizador, u.nome, u.email, u.telefone, u.estado_conta, u.data_registo,
               r.nome_role
        FROM utilizador u
        JOIN role r ON r.id_role = u.id_role
        WHERE u.id_utilizador = ?
    ");
    $stmt->execute([$_SESSION['id_utilizador']]);
    $u = $stmt->fetch();
    jsonOk($u);
}

if ($method === 'PUT') {
    $d        = getBody();
    $nome     = trim($d['nome'] ?? '');
    $telefone = trim($d['telefone'] ?? '');
    $password = $d['password'] ?? '';
    $nova_pw  = $d['nova_password'] ?? '';

    if (!$nome) jsonErro('Nome obrigatório');

    if ($nova_pw) {
        $check = $pdo->prepare("SELECT password FROM utilizador WHERE id_utilizador=?");
        $check->execute([$_SESSION['id_utilizador']]);
        $u = $check->fetch();
        if (!$u || $u['password'] !== hash('sha256', $password)) {
            jsonErro('Palavra-passe atual incorreta');
        }
        $pdo->prepare("UPDATE utilizador SET nome=?, telefone=?, password=? WHERE id_utilizador=?")
            ->execute([$nome, $telefone, hash('sha256', $nova_pw), $_SESSION['id_utilizador']]);
    } else {
        $pdo->prepare("UPDATE utilizador SET nome=?, telefone=? WHERE id_utilizador=?")
            ->execute([$nome, $telefone, $_SESSION['id_utilizador']]);
    }
    $_SESSION['nome'] = $nome;
    $_SESSION['user']['nome'] = $nome;
    jsonOk([], 'Perfil atualizado com sucesso');
}
