<?php
// tarefas.php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/response.php';
apiHeaders();
requireLogin();

$pdo    = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

case 'GET':
    $role = $_SESSION['role'];
    if ($role === 'staff') {
        $stmt = $pdo->prepare("
            SELECT t.*, e.nome_evento, u.nome AS nome_staff
            FROM tarefas t
            JOIN evento e ON e.id_evento = t.id_evento
            LEFT JOIN utilizador u ON u.id_utilizador = t.id_staff
            WHERE t.id_staff = ?
            ORDER BY t.hora_inicio ASC
        ");
        $stmt->execute([$_SESSION['id_utilizador']]);
    } elseif ($role === 'organizador') {
        $id_evento = (int)($_GET['id_evento'] ?? 0);
        $id_staff_filtro = (int)($_GET['id_staff'] ?? 0);
        if ($id_evento) {
            $stmt = $pdo->prepare("
                SELECT t.*, e.nome_evento, u.nome AS nome_staff
                FROM tarefas t
                JOIN evento e ON e.id_evento = t.id_evento
                LEFT JOIN utilizador u ON u.id_utilizador = t.id_staff
                WHERE t.id_evento = ? AND e.id_organizador = ?
                ORDER BY t.hora_inicio ASC
            ");
            $stmt->execute([$id_evento, $_SESSION['id_utilizador']]);
        } elseif ($id_staff_filtro) {
            // Pré-visualização: tarefas de um staff específico, dentro dos eventos deste organizador
            $stmt = $pdo->prepare("
                SELECT t.*, e.nome_evento, u.nome AS nome_staff
                FROM tarefas t
                JOIN evento e ON e.id_evento = t.id_evento
                LEFT JOIN utilizador u ON u.id_utilizador = t.id_staff
                WHERE t.id_staff = ? AND e.id_organizador = ?
                ORDER BY t.hora_inicio ASC
            ");
            $stmt->execute([$id_staff_filtro, $_SESSION['id_utilizador']]);
        } else {
            $stmt = $pdo->prepare("
                SELECT t.*, e.nome_evento, u.nome AS nome_staff
                FROM tarefas t
                JOIN evento e ON e.id_evento = t.id_evento
                LEFT JOIN utilizador u ON u.id_utilizador = t.id_staff
                WHERE e.id_organizador = ?
                ORDER BY t.hora_inicio ASC
            ");
            $stmt->execute([$_SESSION['id_utilizador']]);
        }
    } else {
        jsonErro('Sem permissão', 403);
    }
    jsonOk($stmt->fetchAll());
    break;

case 'POST':
    requireRole(['organizador']);
    $d = getBody();
    if (empty($d['id_evento']) || empty($d['id_staff']) || empty($d['descricao'])) {
        jsonErro('Campos obrigatórios: id_evento, id_staff, descricao');
    }
    $evChk = $pdo->prepare('SELECT id_evento FROM evento WHERE id_evento = ? AND id_organizador = ?');
    $evChk->execute([$d['id_evento'], $_SESSION['id_utilizador']]);
    if (!$evChk->fetch()) jsonErro('Evento não encontrado ou sem permissão.', 403);
    $stmt = $pdo->prepare("
        INSERT INTO tarefas (id_evento, id_staff, descricao, hora_inicio, hora_fim, prioridade, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $d['id_evento'], $d['id_staff'], $d['descricao'],
        $d['hora_inicio'] ?? null, $d['hora_fim'] ?? null,
        $d['prioridade'] ?? 'media', $d['estado'] ?? 'pendente'
    ]);
    criarNotificacao((int)$d['id_evento'], (int)$d['id_staff'],
        "Nova tarefa atribuída: {$d['descricao']}", 'tarefa');
    jsonOk(['id_tarefa' => $pdo->lastInsertId()], 'Tarefa criada');
    break;

case 'PUT':
    if (!$id) jsonErro('ID obrigatório');
    $d    = getBody();
    $role = $_SESSION['role'];

    if ($role === 'staff') {
        $check = $pdo->prepare("SELECT id_tarefa FROM tarefas WHERE id_tarefa=? AND id_staff=?");
        $check->execute([$id, $_SESSION['id_utilizador']]);
        if (!$check->fetch()) jsonErro('Sem permissão', 403);

        $pdo->prepare("UPDATE tarefas SET estado=? WHERE id_tarefa=?")
            ->execute([$d['estado'], $id]);

        // Notifica organizador se tarefa foi concluída
        if ($d['estado'] === 'concluida') {
            $t = $pdo->prepare("
                SELECT t.id_evento, e.id_organizador, e.nome_evento, t.descricao
                FROM tarefas t JOIN evento e ON e.id_evento = t.id_evento
                WHERE t.id_tarefa = ?
            ");
            $t->execute([$id]);
            $tarefa = $t->fetch();
            if ($tarefa) {
                criarNotificacao($tarefa['id_evento'], $tarefa['id_organizador'],
                    "✅ Tarefa concluída: '{$tarefa['descricao']}' ({$tarefa['nome_evento']})", 'conclusao');
            }
        }
    } elseif ($role === 'organizador') {
        $ownerChk = $pdo->prepare('
            SELECT t.id_tarefa FROM tarefas t
            JOIN evento e ON e.id_evento = t.id_evento
            WHERE t.id_tarefa = ? AND e.id_organizador = ?
        ');
        $ownerChk->execute([$id, $_SESSION['id_utilizador']]);
        if (!$ownerChk->fetch()) jsonErro('Sem permissão.', 403);
        $pdo->prepare("
            UPDATE tarefas SET id_staff=?, descricao=?, hora_inicio=?, hora_fim=?, prioridade=?, estado=?
            WHERE id_tarefa=?
        ")->execute([
            $d['id_staff'], $d['descricao'],
            $d['hora_inicio'] ?? null, $d['hora_fim'] ?? null,
            $d['prioridade'] ?? 'media', $d['estado'] ?? 'pendente',
            $id
        ]);
    } else {
        jsonErro('Sem permissão', 403);
    }
    jsonOk([], 'Tarefa atualizada');
    break;

case 'DELETE':
    requireRole(['organizador']);
    if (!$id) jsonErro('ID obrigatório');
    $delChk = $pdo->prepare('
        SELECT t.id_tarefa FROM tarefas t
        JOIN evento e ON e.id_evento = t.id_evento
        WHERE t.id_tarefa = ? AND e.id_organizador = ?
    ');
    $delChk->execute([$id, $_SESSION['id_utilizador']]);
    if (!$delChk->fetch()) jsonErro('Sem permissão.', 403);
    $pdo->prepare("DELETE FROM tarefas WHERE id_tarefa=?")->execute([$id]);
    jsonOk([], 'Tarefa eliminada');
    break;
}
