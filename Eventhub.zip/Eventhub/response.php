<?php
// response.php — Helpers para respostas JSON da API
function jsonOk(mixed $data, string $msg = 'ok'): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'ok', 'msg' => $msg, 'data' => $data]);
    exit;
}

function jsonErro(string $msg, int $code = 400): void {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($code);
    echo json_encode(['status' => 'erro', 'msg' => $msg]);
    exit;
}

function apiHeaders(): void {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
}

function getBody(): array {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    return $json ?? $_POST;
}
