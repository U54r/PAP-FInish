<?php
// recreate_db.php - Versão alternativa mais segura

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'])) {
    http_response_code(403);
    exit('Acesso negado. Este script só pode ser executado localmente.');
}

require_once __DIR__ . '/auth.php';
requireRole(['administrador']);

require_once __DIR__ . '/db.php';

try {
    $pdo = new PDO(
        'mysql:host=localhost;charset=utf8mb4',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // Verificar se a base de dados existe
    $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'gestao_eventos'");
    $exists = $stmt->fetch();
    
    if ($exists) {
        echo "⚠️ A base de dados 'gestao_eventos' já existe.<br>";
        echo "Para recriar, primeiro elimine-a no phpMyAdmin:<br>";
        echo "1. Abra phpMyAdmin<br>";
        echo "2. Clique em 'gestao_eventos'<br>";
        echo "3. Clique em 'Operações'<br>";
        echo "4. Clique em 'Eliminar base de dados (DROP)'<br>";
        echo "5. Depois volte a correr este script<br>";
    } else {
        // Criar a base de dados
        $pdo->exec("CREATE DATABASE gestao_eventos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "✅ Base de dados 'gestao_eventos' criada!<br>";
        
        // Usar a base de dados
        $pdo->exec("USE gestao_eventos");
        
        // Executar o script SQL
        $sql = file_get_contents(__DIR__ . '/scripts_bd.sql');
        $pdo->exec($sql);
        echo "✅ Tabelas e dados criados com sucesso!<br>";
        
        echo "<hr><a href='login.php'>Ir para o login</a>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color:red'>Erro: " . $e->getMessage() . "</p>";
    echo "<p>Verifique se o MySQL está ligado no XAMPP.</p>";
}
?>