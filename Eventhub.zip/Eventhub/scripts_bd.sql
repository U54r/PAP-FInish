CREATE DATABASE IF NOT EXISTS gestao_eventos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gestao_eventos;

CREATE TABLE IF NOT EXISTS role (
    id_role    INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome_role  VARCHAR(50) NOT NULL
);
 
CREATE TABLE IF NOT EXISTS utilizador (
    id_utilizador  INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome           VARCHAR(100) NOT NULL,
    email          VARCHAR(120) NOT NULL UNIQUE,
    telefone       VARCHAR(20),
    password       VARCHAR(255) NOT NULL,
    id_role        INTEGER NOT NULL,
    estado_conta   VARCHAR(20) DEFAULT 'ativo',
    data_registo   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_role) REFERENCES role(id_role)
);
 
CREATE TABLE IF NOT EXISTS evento (
    id_evento      INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_organizador INTEGER NOT NULL,
    nome_evento    VARCHAR(150) NOT NULL,
    local          VARCHAR(200),
    data           DATE NOT NULL,
    hora           TIME NOT NULL,
    dresscode      VARCHAR(50),
    descricao      TEXT,
    FOREIGN KEY (id_organizador) REFERENCES utilizador(id_utilizador)
);
 
CREATE TABLE IF NOT EXISTS qr_codes (
    id_qr          INTEGER PRIMARY KEY AUTO_INCREMENT,
    codigo         VARCHAR(255) NOT NULL UNIQUE,
    id_utilizador  INTEGER NOT NULL,
    id_evento      INTEGER NOT NULL,
    estado         VARCHAR(30) DEFAULT 'ativo',
    FOREIGN KEY (id_utilizador) REFERENCES utilizador(id_utilizador),
    FOREIGN KEY (id_evento)     REFERENCES evento(id_evento)
);
 
CREATE TABLE IF NOT EXISTS recurso (
    id_recurso        INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome              VARCHAR(150) NOT NULL,
    categoria         VARCHAR(100),
    quantidade_total  INTEGER NOT NULL DEFAULT 0,
    quantidade_usada  INTEGER NOT NULL DEFAULT 0,
    fornecedor        VARCHAR(150)
);
 
CREATE TABLE IF NOT EXISTS evento_recurso (
    id_evento    INTEGER NOT NULL,
    id_recurso   INTEGER NOT NULL,
    quantidade   INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (id_evento, id_recurso),
    FOREIGN KEY (id_evento)  REFERENCES evento(id_evento),
    FOREIGN KEY (id_recurso) REFERENCES recurso(id_recurso)
);
 
CREATE TABLE IF NOT EXISTS presente (
    id_presente      INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome_item        VARCHAR(150) NOT NULL,
    categoria        VARCHAR(100),
    preco_estimado   DECIMAL(10,2),
    estado           VARCHAR(30) DEFAULT 'pendente',
    id_responsavel   INTEGER,
    FOREIGN KEY (id_responsavel) REFERENCES utilizador(id_utilizador)
);
 
CREATE TABLE IF NOT EXISTS evento_presente (
    id_evento   INTEGER NOT NULL,
    id_presente INTEGER NOT NULL,
    PRIMARY KEY (id_evento, id_presente),
    FOREIGN KEY (id_evento)   REFERENCES evento(id_evento),
    FOREIGN KEY (id_presente) REFERENCES presente(id_presente)
);
 
CREATE TABLE IF NOT EXISTS tarefas (
    id_tarefa    INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_evento    INTEGER NOT NULL,
    id_staff     INTEGER NOT NULL,
    descricao    TEXT,
    hora_inicio  DATETIME,
    hora_fim     DATETIME,
    prioridade   VARCHAR(20) DEFAULT 'media',
    estado       VARCHAR(20) DEFAULT 'pendente',
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_staff)  REFERENCES utilizador(id_utilizador)
);
 
CREATE TABLE IF NOT EXISTS notificacoes (
    id_notificacao  INTEGER PRIMARY KEY AUTO_INCREMENT,
    id_evento       INTEGER NOT NULL,
    id_utilizador   INTEGER NOT NULL,
    mensagem        TEXT,
    tipo            VARCHAR(100),
    data_hora       DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_evento)     REFERENCES evento(id_evento),
    FOREIGN KEY (id_utilizador) REFERENCES utilizador(id_utilizador)
);
 
CREATE TABLE IF NOT EXISTS guest (
    id_guest   INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(120),
    telefone   VARCHAR(20)
);
 
CREATE TABLE IF NOT EXISTS mesa (
    id_mesa      INTEGER PRIMARY KEY AUTO_INCREMENT,
    numero       INTEGER NOT NULL,
    capacidade   INTEGER NOT NULL,
    localizacao  VARCHAR(100)
);
 
CREATE TABLE IF NOT EXISTS evento_mesa (
    id_evento  INTEGER NOT NULL,
    id_mesa    INTEGER NOT NULL,
    PRIMARY KEY (id_evento, id_mesa),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_mesa)   REFERENCES mesa(id_mesa)
);
 
CREATE TABLE IF NOT EXISTS event_guest (
    id_evento    INTEGER NOT NULL,
    id_guest     INTEGER NOT NULL,
    id_mesa      INTEGER,
    estado_rsvp  VARCHAR(20) DEFAULT 'pendente',
    PRIMARY KEY (id_evento, id_guest),
    FOREIGN KEY (id_evento) REFERENCES evento(id_evento),
    FOREIGN KEY (id_guest)  REFERENCES guest(id_guest),
    FOREIGN KEY (id_mesa)   REFERENCES mesa(id_mesa)
);
 
INSERT INTO role (nome_role) VALUES
    ('administrador'),
    ('organizador'),
    ('staff'),
    ('convidado');
 
INSERT INTO utilizador (nome, email, telefone, password, id_role, estado_conta) VALUES
    ('Ana Silva',    'ana.silva@email.com',    '912000001', SHA2('admin123', 256), 1, 'ativo'),
    ('Bruno Costa',  'bruno.costa@email.com',  '912000002', SHA2('org123',   256), 2, 'ativo'),
    ('Carla Mendes', 'carla.mendes@email.com', '912000003', SHA2('staff123', 256), 3, 'ativo'),
    ('David Lopes',  'david.lopes@email.com',  '912000004', SHA2('staff456', 256), 3, 'ativo'),
    ('Eva Nunes',    'eva.nunes@email.com',     '912000005', SHA2('org456',   256), 2, 'ativo');
 
INSERT INTO evento (id_organizador, nome_evento, local, data, hora, dresscode, descricao) VALUES
    (2, 'Gala de Aniversario 2026', 'Hotel Ritz, Lisboa',         '2026-06-15', '20:00:00', 'Black Tie', 'Gala de celebracao dos 10 anos da empresa.'),
    (5, 'Casamento Silva & Costa',  'Quinta das Flores, Setubal', '2026-07-20', '17:00:00', 'Formal',    'Cerimonia e jantar de casamento.'),
    (2, 'Conferencia Tech 2026',    'Centro de Congressos, Porto','2026-09-05', '09:00:00', 'Business',  'Conferencia anual de tecnologia e inovacao.');
 
INSERT INTO qr_codes (codigo, id_utilizador, id_evento, estado) VALUES
    ('QR-EVT1-USR1-001', 1, 1, 'ativo'),
    ('QR-EVT1-USR3-002', 3, 1, 'ativo'),
    ('QR-EVT2-USR2-003', 2, 2, 'ativo'),
    ('QR-EVT3-USR4-004', 4, 3, 'ativo');
 
INSERT INTO recurso (nome, categoria, quantidade_total, quantidade_usada, fornecedor) VALUES
    ('Cadeiras',           'Mobiliario',  200, 150, 'Mobirent Lda'),
    ('Mesas redondas',     'Mobiliario',   30,  20, 'Mobirent Lda'),
    ('Projetor HD',        'Audiovisual',   5,   2, 'AV Solutions'),
    ('Microfones sem fio', 'Audiovisual',  10,   4, 'AV Solutions'),
    ('Arranjos florais',   'Decoracao',    25,  10, 'Flores & Arte');
 
INSERT INTO evento_recurso (id_evento, id_recurso, quantidade) VALUES
    (1, 1, 150),
    (1, 2,  20),
    (1, 5,  15),
    (2, 1, 100),
    (2, 2,  12),
    (2, 5,  10),
    (3, 3,   2),
    (3, 4,   4);
 
INSERT INTO presente (nome_item, categoria, preco_estimado, estado, id_responsavel) VALUES
    ('Quadro decorativo',    'Arte',        80.00, 'confirmado', 3),
    ('Vale presente Spa',    'Bem-estar',  120.00, 'confirmado', 4),
    ('Conjunto de vinhos',   'Gastronomia', 60.00, 'pendente',   3),
    ('Livro de fotografias', 'Memorias',    45.00, 'pendente',   NULL);
 
INSERT INTO evento_presente (id_evento, id_presente) VALUES
    (2, 1),
    (2, 2),
    (2, 3),
    (1, 4);
 
INSERT INTO tarefas (id_evento, id_staff, descricao, hora_inicio, hora_fim, prioridade, estado) VALUES
    (1, 3, 'Coordenar rececao de convidados',    '2026-06-15 19:00:00', '2026-06-15 21:00:00', 'alta',  'pendente'),
    (1, 4, 'Gerir servico de mesa',              '2026-06-15 20:00:00', '2026-06-15 23:00:00', 'alta',  'pendente'),
    (2, 3, 'Organizar flores e decoracao',       '2026-07-20 14:00:00', '2026-07-20 17:00:00', 'media', 'pendente'),
    (3, 4, 'Configurar equipamento audiovisual', '2026-09-05 07:00:00', '2026-09-05 09:00:00', 'alta',  'pendente'),
    (3, 3, 'Registo e credenciacao de entradas', '2026-09-05 08:30:00', '2026-09-05 10:00:00', 'media', 'pendente');
 
INSERT INTO notificacoes (id_evento, id_utilizador, mensagem, tipo, data_hora) VALUES
    (1, 2, 'O evento Gala de Aniversario foi confirmado.',  'confirmacao', '2026-05-01 10:00:00'),
    (1, 3, 'Tens uma nova tarefa atribuida na Gala.',       'tarefa',      '2026-05-02 09:00:00'),
    (2, 5, 'O casamento foi registado com sucesso.',        'confirmacao', '2026-05-03 11:00:00'),
    (3, 2, 'Lembrete: Conferencia Tech em 3 meses.',        'lembrete',    '2026-06-05 08:00:00');
 
INSERT INTO guest (nome, email, telefone) VALUES
    ('Mariana Ferreira', 'mariana.f@email.com', '961000001'),
    ('Joao Rodrigues',   'joao.r@email.com',    '961000002'),
    ('Sofia Pinto',      'sofia.p@email.com',   '961000003'),
    ('Miguel Alves',     'miguel.a@email.com',  '961000004'),
    ('Ines Carvalho',    'ines.c@email.com',     '961000005');
 
INSERT INTO mesa (numero, capacidade, localizacao) VALUES
    (1, 10, 'Sala Principal - Zona A'),
    (2, 10, 'Sala Principal - Zona A'),
    (3,  8, 'Sala Principal - Zona B'),
    (4,  6, 'Terraco'),
    (5,  6, 'Terraco');
 
INSERT INTO evento_mesa (id_evento, id_mesa) VALUES
    (1, 1), (1, 2), (1, 3),
    (2, 1), (2, 2), (2, 4), (2, 5),
    (3, 3), (3, 4);
 
INSERT INTO event_guest (id_evento, id_guest, id_mesa, estado_rsvp) VALUES
    (1, 1, 1, 'confirmado'),
    (1, 2, 1, 'confirmado'),
    (1, 3, 2, 'pendente'),
    (2, 4, 4, 'confirmado'),
    (2, 5, 4, 'confirmado'),
    (3, 1, 3, 'pendente'),
    (3, 2, 3, 'confirmado');
